/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import Mathlib.AlgebraicTopology.SimplicialSet.Homology.Relative
public import Mathlib.Topology.Category.TopCat.EpiMono
public import Mathlib.Topology.Category.TopPair
public import TauCeti.AlgebraicTopology.SimplicialSet.Homology.Relative.Basic
public import TauCeti.AlgebraicTopology.SimplicialSet.Restrict
public import TauCeti.AlgebraicTopology.SimplicialSet.TopAdj
public import TauCeti.AlgebraicTopology.Singular.Basic

/-!
# Relative singular chains

This file sends a topological pair to the corresponding pair of singular simplicial sets and
defines its relative singular chain complex.  The complex is the cokernel of the inclusion of the
singular chains of the subspace into those of the ambient space.  In an abelian coefficient
category this gives the short exact sequence of chain complexes used to construct the connecting
morphisms in relative singular homology.  A simplex of the singular pair restricted to a subcomplex
of the ambient simplicial set comes from the subspace exactly when its image lies in the subspace
(`TopPair.mem_range_restrict_hom_app_iff`).

The quotient map on zeroth homology is an epimorphism already for preadditive coefficients with
coproducts and homology.

The construction follows the quotient-chain presentation in Eilenberg--Steenrod, *Foundations of
Algebraic Topology*, Chapters I--III, and is implemented using Mathlib's `SSetPair` relative-chain
functor.
-/

@[expose] public section

noncomputable section

open CategoryTheory Limits

universe w v u

namespace TopPair

/-- The ambient component of the identity map of a topological pair is the identity. -/
@[simp]
lemma Hom.fst_id (P : TopPair.{w}) : Hom.fst (𝟙 P) = 𝟙 P.fst := rfl

/-- The ambient component of a composite map of topological pairs is the composite of the
ambient components. -/
@[simp]
lemma Hom.fst_comp {P Q S : TopPair.{w}} (f : P ⟶ Q) (g : Q ⟶ S) :
    Hom.fst (f ≫ g) = Hom.fst f ≫ Hom.fst g := rfl

/-- The inclusion of the subspace of a topological pair is a monomorphism, since an embedding is
injective. -/
instance (P : TopPair.{w}) : Mono P.map :=
  (TopCat.mono_iff_injective _).mpr P.isEmbedding_map.injective

/-- An embedding of topological spaces induces a monomorphism of singular simplicial sets. -/
instance (P : TopPair.{w}) : Mono (TopCat.toSSet.map P.map) := Functor.map_mono _ _

/-- The singular simplicial-set pair associated to a topological pair. -/
def toSSetPair : TopPair.{w} ⥤ SSetPair.{w} :=
  MorphismProperty.Comma.lift
    (MorphismProperty.Arrow.forget TopCat.isEmbedding ⊤ ⊤ ⋙ TopCat.toSSet.mapArrow)
    (fun P ↦ inferInstanceAs (Mono (TopCat.toSSet.map P.map)))
    (fun _ ↦ trivial) (fun _ ↦ trivial)

@[simp]
lemma toSSetPair_obj_left (P : TopPair.{w}) :
    (toSSetPair.obj P).left = TopCat.toSSet.obj P.snd := rfl

@[simp]
lemma toSSetPair_obj_right (P : TopPair.{w}) :
    (toSSetPair.obj P).right = TopCat.toSSet.obj P.fst := rfl

@[simp]
lemma toSSetPair_obj_hom (P : TopPair.{w}) :
    (toSSetPair.obj P).hom = TopCat.toSSet.map P.map := rfl

@[simp]
lemma toSSetPair_map_left {P P' : TopPair.{w}} (f : P ⟶ P') :
    (toSSetPair.map f).left = TopCat.toSSet.map (Hom.snd f) := rfl

@[simp]
lemma toSSetPair_map_right {P P' : TopPair.{w}} (f : P ⟶ P') :
    (toSSetPair.map f).right = TopCat.toSSet.map (Hom.fst f) := rfl

/-- A simplex of the singular pair of `P` restricted to a subcomplex `S` comes from the subspace
exactly when its image lies in the subspace. -/
lemma mem_range_restrict_hom_app_iff (P : TopPair.{w}) (S : (toSSetPair.obj P).right.Subcomplex)
    {n : SimplexCategoryᵒᵖ} (x : ((toSSetPair.obj P).restrict S).right.obj n) :
    x ∈ Set.range (((toSSetPair.obj P).restrict S).hom.app n) ↔
      Set.range (P.fst.toSSetObjEquiv n x.1) ⊆ Set.range P.map :=
  (SSetPair.mem_range_restrict_hom_app_iff _ _ x).trans
    (P.isEmbedding_map.isInducing.mem_range_toSSet_map_app_iff n x.1)

variable (C : Type u) [Category.{v} C] [HasCoproducts.{w} C] [Preadditive C]

/-- The relative singular chain complex functor on topological pairs. -/
@[no_expose]
noncomputable def singularChainComplexFunctor :
    C ⥤ TopPair.{w} ⥤ ChainComplex C ℕ :=
  SSetPair.chainComplexFunctor C ⋙
    (Functor.whiskeringLeft _ _ _).obj toSSetPair

variable {C} (P P' : TopPair.{w}) (f : P ⟶ P') (R : C)

/-- The relative singular chain complex of a topological pair. -/
noncomputable abbrev singularChainComplex : ChainComplex C ℕ :=
  (toSSetPair.obj P).chainComplex R

@[simp]
lemma singularChainComplexFunctor_obj_obj :
    ((singularChainComplexFunctor C).obj R).obj P = P.singularChainComplex R := by
  rw [singularChainComplexFunctor.eq_def, singularChainComplex.eq_def,
    SSetPair.chainComplex.eq_def, Functor.comp_obj, Functor.whiskeringLeft_obj_obj,
    Functor.comp_obj]

@[simp]
lemma singularChainComplexFunctor_map_app {R R' : C} (g : R ⟶ R') :
    ((singularChainComplexFunctor C).map g).app P =
      eqToHom (singularChainComplexFunctor_obj_obj (C := C) P R) ≫
        ((SSetPair.chainComplexFunctor C).map g).app (toSSetPair.obj P) ≫
          eqToHom (singularChainComplexFunctor_obj_obj (C := C) P R').symm := by
  apply (conj_eqToHom_iff_heq _ _ (singularChainComplexFunctor_obj_obj (C := C) P R)
    (singularChainComplexFunctor_obj_obj (C := C) P R')).2
  rw [singularChainComplexFunctor.eq_def, Functor.comp_map,
    Functor.whiskeringLeft_obj_map, Functor.whiskerLeft_app]

/-- The relative singular chain complex functor is the relative chain complex functor of the
singular simplicial-set pair. -/
lemma singularChainComplexFunctor_obj_eq_toSSetPair_comp :
    (singularChainComplexFunctor C).obj R =
      toSSetPair ⋙ (SSetPair.chainComplexFunctor C).obj R := by
  rw [singularChainComplexFunctor.eq_def]
  rfl

variable {P P'} in
/-- The chain map on relative singular chains induced by a map of topological pairs. -/
noncomputable abbrev singularChainComplexMap :
    P.singularChainComplex R ⟶ P'.singularChainComplex R :=
  SSetPair.chainComplexMap (toSSetPair.map f) R

@[simp]
lemma singularChainComplexFunctor_obj_map :
    ((singularChainComplexFunctor C).obj R).map f =
      eqToHom (singularChainComplexFunctor_obj_obj (C := C) P R) ≫
        singularChainComplexMap f R ≫
          eqToHom (singularChainComplexFunctor_obj_obj (C := C) P' R).symm := by
  apply (conj_eqToHom_iff_heq _ _ (singularChainComplexFunctor_obj_obj (C := C) P R)
    (singularChainComplexFunctor_obj_obj (C := C) P' R)).2
  rw [singularChainComplexFunctor.eq_def, Functor.comp_obj,
    Functor.whiskeringLeft_obj_obj, Functor.comp_map, singularChainComplexMap.eq_def]

/-- The quotient map from ambient singular chains to relative singular chains. -/
noncomputable abbrev singularChainComplexπ :
    (toSSetPair.obj P).right.chainComplex R ⟶ P.singularChainComplex R :=
  (toSSetPair.obj P).chainComplexπ R

/-- The quotient map from ambient to relative singular chains is natural in maps of pairs. -/
@[simp, reassoc]
lemma singularChainComplexπ_pair_naturality
    {P Q : TopPair.{w}} (f : P ⟶ Q) (M : C) :
    SSet.chainComplexMap (TopCat.toSSet.map (TopPair.Hom.fst f)) M ≫
        Q.singularChainComplexπ M =
      P.singularChainComplexπ M ≫ TopPair.singularChainComplexMap f M := by
  have h : SSet.chainComplexMap (TopPair.toSSetPair.map f).right M ≫
      Q.singularChainComplexπ M =
        P.singularChainComplexπ M ≫ TopPair.singularChainComplexMap f M :=
    ((SSetPair.chainComplexFunctorπ C).app M).naturality (TopPair.toSSetPair.map f)
  rwa [TopPair.toSSetPair_map_right] at h

/-- The quotient map from ambient to relative singular chains is natural in the coefficient
object. -/
@[reassoc]
lemma singularChainComplexπ_coefficient_naturality
    (P : TopPair.{w}) {M N : C} (φ : M ⟶ N) :
    ((AlgebraicTopology.singularChainComplexFunctor C).map φ).app P.fst ≫
        P.singularChainComplexπ N =
      P.singularChainComplexπ M ≫
        ((SSetPair.chainComplexFunctor C).map φ).app (TopPair.toSSetPair.obj P) := by
  rw [TauCeti.singularChainComplexFunctor_map_app]
  have h : ((SSet.chainComplexFunctor C).map φ).app (TopPair.toSSetPair.obj P).right ≫
      P.singularChainComplexπ N = P.singularChainComplexπ M ≫
        ((SSetPair.chainComplexFunctor C).map φ).app (TopPair.toSSetPair.obj P) :=
    congrArg (fun η ↦ η.app (TopPair.toSSetPair.obj P))
      ((SSetPair.chainComplexFunctorπ C).naturality φ)
  simp only [TopPair.toSSetPair_obj_right] at h
  exact h

@[simp]
lemma chainComplexMap_comp_singularChainComplexπ :
    SSet.chainComplexMap (TopCat.toSSet.map P.map) R ≫ P.singularChainComplexπ R = 0 := by
  rw [← toSSetPair_obj_hom]
  exact (toSSetPair.obj P).chainComplex_condition R

variable {P P'} in
/-- A map of pairs `f : (X, A) ⟶ (X', A')` whose map of ambient spaces factors through the
subspace `A'` induces the zero map on relative singular chains. -/
lemma singularChainComplexMap_eq_zero_of_fac (g : P.fst ⟶ P'.snd) (hg : g ≫ P'.map = Hom.fst f) :
    singularChainComplexMap f R = 0 := by
  have h : SSet.chainComplexMap (TopCat.toSSet.map (Hom.fst f)) R =
      SSet.chainComplexMap (TopCat.toSSet.map g) R ≫
        SSet.chainComplexMap (TopCat.toSSet.map P'.map) R := by
    rw [← hg, Functor.map_comp]
    exact Functor.map_comp _ _ _
  rw [← cancel_epi (P.singularChainComplexπ R), comp_zero,
    ← singularChainComplexπ_pair_naturality, h]
  -- `rw [Category.assoc]` fails here: the ambient chain complex of `P'` appears both as
  -- `(toSSetPair.obj P').right.chainComplex R` and as `(TopCat.toSSet.obj P'.fst).chainComplex R`.
  exact (Category.assoc _ _ _).trans
    ((congrArg (_ ≫ ·) (chainComplexMap_comp_singularChainComplexπ P' R)).trans comp_zero)

/-- The cokernel cofork presenting the relative singular chain complex as the quotient of the
ambient singular chains by the subspace singular chains. -/
noncomputable abbrev cokernelCoforkSingularChainComplex :
    CokernelCofork (SSet.chainComplexMap (toSSetPair.obj P).hom R) :=
  (toSSetPair.obj P).cokernelCoforkChainComplex R

/-- The relative singular chain complex is the cokernel of the map from the singular chains of
the subspace to those of the ambient space. -/
@[no_expose]
noncomputable def isColimitCokernelCoforkSingularChainComplex :
    IsColimit (P.cokernelCoforkSingularChainComplex R) :=
  (toSSetPair.obj P).isColimitCokernelCoforkChainComplex R

/-- The chain complex sequence of a topological pair: subspace chains, ambient chains, and
relative chains. -/
noncomputable abbrev singularChainComplexShortComplex : ShortComplex (ChainComplex C ℕ) :=
  (toSSetPair.obj P).chainComplexShortComplex R

section

variable {A : Type u} [Category.{v} A] [HasCoproducts.{w} A] [Abelian A]
  (P : TopPair.{w}) (R : A)

/-- The singular chain sequence of a topological pair is short exact. -/
lemma shortExact_singularChainComplexShortComplex :
    (P.singularChainComplexShortComplex R).ShortExact :=
  (toSSetPair.obj P).shortExact_chainComplexShortComplex R

end

section Homology

variable [CategoryWithHomology C]

/-- The relative singular homology of a topological pair in degree `n`. -/
protected noncomputable abbrev singularHomology (n : ℕ) : C :=
  (toSSetPair.obj P).homology R n

variable {P P'} in
/-- The map on relative singular homology induced by a map of topological pairs. -/
protected noncomputable abbrev singularHomologyMap (n : ℕ) :
    P.singularHomology R n ⟶ P'.singularHomology R n :=
  SSetPair.homologyMap (toSSetPair.map f) R n

/-- Relative singular homology sends the identity map of a pair to the identity. -/
@[simp]
lemma singularHomologyMap_id (n : ℕ) : P.singularHomologyMap (𝟙 P) R n = 𝟙 _ := by
  rw [TopPair.singularHomologyMap, CategoryTheory.Functor.map_id, SSetPair.homologyMap_id]

variable {P P'} in
/-- Relative singular homology sends a composite of maps of pairs to the composite of the induced
maps. -/
@[reassoc]
lemma singularHomologyMap_comp {P'' : TopPair.{w}} (g : P' ⟶ P'') (n : ℕ) :
    P.singularHomologyMap (f ≫ g) R n =
      P.singularHomologyMap f R n ≫ P'.singularHomologyMap g R n := by
  rw [TopPair.singularHomologyMap, Functor.map_comp, SSetPair.homologyMap_comp]

variable {P P'} in
/-- A map of pairs `f : (X, A) ⟶ (X', A')` whose map of ambient spaces factors through the
subspace `A'` induces the zero map on relative singular homology. -/
lemma singularHomologyMap_eq_zero_of_fac (g : P.fst ⟶ P'.snd) (hg : g ≫ P'.map = Hom.fst f)
    (n : ℕ) : P.singularHomologyMap f R n = 0 := by
  rw [TopPair.singularHomologyMap, SSetPair.homologyMap,
    ← singularChainComplexMap, singularChainComplexMap_eq_zero_of_fac f R g hg,
    HomologicalComplex.homologyMap_zero]

/-- Relative singular homology as a functor on topological pairs. -/
@[no_expose]
noncomputable def singularHomologyFunctor (n : ℕ) : TopPair.{w} ⥤ C :=
  toSSetPair ⋙ SSetPair.homologyFunctor R n

@[simp]
lemma singularHomologyFunctor_obj (n : ℕ) :
    (singularHomologyFunctor R n).obj P = P.singularHomology R n := by
  rw [singularHomologyFunctor.eq_def, singularHomology.eq_def, Functor.comp_obj,
    SSetPair.homologyFunctor_obj]

@[simp]
lemma singularHomologyFunctor_map (n : ℕ) :
    (singularHomologyFunctor R n).map f =
      eqToHom (singularHomologyFunctor_obj P R n) ≫
        P.singularHomologyMap f R n ≫
          eqToHom (singularHomologyFunctor_obj P' R n).symm := by
  apply (conj_eqToHom_iff_heq _ _ (singularHomologyFunctor_obj P R n)
    (singularHomologyFunctor_obj P' R n)).2
  rw [singularHomologyFunctor.eq_def, Functor.comp_map, singularHomologyMap.eq_def,
    SSetPair.homologyFunctor_map]

/-- Relative singular homology is the relative homology of the singular simplicial-set pair. -/
lemma singularHomologyFunctor_eq_toSSetPair_comp (n : ℕ) :
    singularHomologyFunctor R n = toSSetPair ⋙ SSetPair.homologyFunctor R n := by
  rw [singularHomologyFunctor.eq_def]

/-- The singular homology of the subspace of a topological pair is the homology of the source of
its singular simplicial-set pair. -/
lemma proj₂_comp_singularHomologyFunctor_obj_eq_toSSetPair_comp (n : ℕ) :
    proj₂ ⋙ (AlgebraicTopology.singularHomologyFunctor C n).obj R =
      toSSetPair.{w} ⋙ (SSetPair.forget ⋙ Arrow.leftFunc) ⋙ SSet.homologyFunctor R n :=
  rfl

/-- Relative singular homology is obtained by applying homology to the relative singular chain
complex functor. -/
lemma singularHomologyFunctor_eq_chainComplexFunctor (n : ℕ) :
    singularHomologyFunctor R n =
      (singularChainComplexFunctor C).obj R ⋙
        HomologicalComplex.homologyFunctor C (ComplexShape.down ℕ) n := by
  apply CategoryTheory.Functor.ext
  · intro Q Q' g
    simp only [Functor.comp_map]
    rw [singularChainComplexFunctor_obj_map]
    rw [Functor.map_comp, Functor.map_comp, eqToHom_map, eqToHom_map]
    simp only [HomologicalComplex.homologyFunctor_map]
    rw [singularHomologyFunctor_map]
    simp only [← Category.assoc, eqToHom_trans]
    apply eq_of_heq
    simp only [singularHomologyMap.eq_def, eqToHom_comp_heq_iff,
      comp_eqToHom_heq_iff, heq_eqToHom_comp_iff, heq_comp_eqToHom_iff]
    exact (comp_eqToHom_heq _ _).symm
  · intro Q
    exact (singularHomologyFunctor_obj Q R n).trans <|
      (congrArg (fun K : ChainComplex C ℕ ↦ K.homology n)
        (singularChainComplexFunctor_obj_obj (C := C) Q R)).symm

/-- The map from ambient singular homology to relative singular homology. -/
noncomputable abbrev singularHomologyπ (n : ℕ) :
    (toSSetPair.obj P).right.homology R n ⟶ P.singularHomology R n :=
  (toSSetPair.obj P).homologyπ R n

/-- The map from ambient zeroth homology to relative zeroth homology is an epimorphism. -/
instance : Epi (P.singularHomologyπ R 0) :=
  HomologicalComplex.epi_homologyMap_of_epi_of_not_rel (P.singularChainComplexπ R) 0 (by simp)

@[simp]
lemma homologyMap_comp_singularHomologyπ (n : ℕ) :
    SSet.homologyMap (TopCat.toSSet.map P.map) R n ≫ P.singularHomologyπ R n = 0 := by
  rw [← toSSetPair_obj_hom]
  exact (toSSetPair.obj P).homologyMap_hom_homologyπ R n

variable {P P'} in
/-- The map from ambient to relative singular homology is natural in maps of pairs. -/
@[simp, reassoc]
lemma singularHomologyπ_naturality (n : ℕ) :
    SSet.homologyMap (TopCat.toSSet.map (Hom.fst f)) R n ≫ P'.singularHomologyπ R n =
      P.singularHomologyπ R n ≫ TopPair.singularHomologyMap f R n :=
  SSetPair.homologyπ_naturality (toSSetPair.map f) R n

variable {P P'} in
/-- If `f` is a map of pairs which is an isomorphism on the ambient spaces, the map from ambient to
relative singular homology of its target is an isomorphism as soon as its composite with the map
induced by `f` on relative homology is. -/
lemma isIso_singularHomologyπ_of_isIso_comp [IsIso (Hom.fst f)] {n : ℕ}
    (h : IsIso (P.singularHomologyπ R n ≫ TopPair.singularHomologyMap f R n)) :
    IsIso (P'.singularHomologyπ R n) := by
  have : IsIso (SSet.homologyMap (TopCat.toSSet.map (Hom.fst f)) R n) := by
    rw [← TauCeti.singularHomologyFunctor_obj_map]
    exact Functor.map_isIso _ (Hom.fst f)
  have : IsIso (SSet.homologyMap (TopCat.toSSet.map (Hom.fst f)) R n ≫
      P'.singularHomologyπ R n) := by
    rw [singularHomologyπ_naturality]
    exact h
  exact IsIso.of_isIso_comp_left (SSet.homologyMap (TopCat.toSSet.map (Hom.fst f)) R n) _

end Homology

section LongExactSequence

variable {A : Type u} [Category.{v} A] [HasCoproducts.{w} A] [Abelian A]
  (P : TopPair.{w}) (R : A)

/-- The connecting morphism from relative singular homology in degree `n` to the singular homology
of the subspace in degree `m`, where `m + 1 = n`. -/
noncomputable abbrev singularHomologyδ (n m : ℕ) (h : m + 1 = n := by lia) :
    P.singularHomology R n ⟶ (toSSetPair.obj P).left.homology R m :=
  (toSSetPair.obj P).homologyδ R n m h

@[simp]
lemma singularHomologyδ_comp (n m : ℕ) (h : m + 1 = n := by lia) :
    P.singularHomologyδ R n m h ≫ SSet.homologyMap (TopCat.toSSet.map P.map) R m = 0 := by
  rw [← toSSetPair_obj_hom]
  exact (toSSetPair.obj P).homologyδ_comp R n m h

@[simp]
lemma singularHomologyπ_comp_singularHomologyδ
    (n m : ℕ) (h : m + 1 = n := by lia) :
    P.singularHomologyπ R n ≫ P.singularHomologyδ R n m h = 0 :=
  (toSSetPair.obj P).comp_homologyδ R n m h

/-- Exactness at subspace homology in the long exact sequence of a topological pair. -/
lemma singularHomology_exact_subspace (n m : ℕ) (h : m + 1 = n := by lia) :
    (ShortComplex.mk _ _ (P.singularHomologyδ_comp R n m h)).Exact :=
  (toSSetPair.obj P).homology_exact₁ R n m h

/-- Exactness at ambient homology in the long exact sequence of a topological pair. -/
lemma singularHomology_exact_space (n : ℕ) :
    (ShortComplex.mk _ _ (P.homologyMap_comp_singularHomologyπ R n)).Exact :=
  (toSSetPair.obj P).homology_exact₂ R n

/-- Exactness at relative homology in the long exact sequence of a topological pair. -/
lemma singularHomology_exact_relative (n m : ℕ) (h : m + 1 = n := by lia) :
    (ShortComplex.mk _ _ (P.singularHomologyπ_comp_singularHomologyδ R n m h)).Exact :=
  (toSSetPair.obj P).homology_exact₃ R n m h

/-- If `Hₙ₊₁(X, A)` vanishes, the inclusion of the subspace induces a monomorphism
`Hₙ(A) ⟶ Hₙ(X)`. -/
lemma mono_homologyMap_map_of_isZero {n : ℕ} (h : IsZero (P.singularHomology R (n + 1))) :
    Mono (SSet.homologyMap (TopCat.toSSet.map P.map) R n) :=
  (P.singularHomology_exact_subspace R (n + 1) n).mono_g (h.eq_of_src _ _)

/-- If `Hₙ(X, A)` vanishes, the inclusion of the subspace induces an epimorphism
`Hₙ(A) ⟶ Hₙ(X)`. -/
lemma epi_homologyMap_map_of_isZero {n : ℕ} (h : IsZero (P.singularHomology R n)) :
    Epi (SSet.homologyMap (TopCat.toSSet.map P.map) R n) :=
  (P.singularHomology_exact_space R n).epi_f (h.eq_of_tgt _ _)

/-- If `Hₙ₊₁(X, A)` and `Hₙ(X, A)` vanish, the inclusion of the subspace induces an isomorphism
`Hₙ(A) ≅ Hₙ(X)`. -/
lemma isIso_homologyMap_map_of_isZero {n : ℕ} (h₁ : IsZero (P.singularHomology R (n + 1)))
    (h₀ : IsZero (P.singularHomology R n)) :
    IsIso (SSet.homologyMap (TopCat.toSSet.map P.map) R n) :=
  have := P.mono_homologyMap_map_of_isZero R h₁
  have := P.epi_homologyMap_map_of_isZero R h₀
  isIso_of_mono_of_epi _

/-- The connecting morphism of the long exact sequence of a topological pair is natural: for a
map of pairs `f : (X, A) ⟶ (X', A')`, following `Hₙ(X, A) ⟶ Hₘ(A)` by the map induced by `f` on
`Hₘ(A)` agrees with following the map induced by `f` on `Hₙ(X, A)` by `Hₙ(X', A') ⟶ Hₘ(A')`. -/
@[reassoc]
lemma singularHomologyδ_naturality {P P' : TopPair.{w}} (f : P ⟶ P') (n m : ℕ)
    (h : m + 1 = n := by lia) :
    P.singularHomologyδ R n m h ≫ SSet.homologyMap (TopCat.toSSet.map (Hom.snd f)) R m =
      TopPair.singularHomologyMap f R n ≫ P'.singularHomologyδ R n m h :=
  SSetPair.homologyδ_naturality (toSSetPair.map f) R n m h

/-- **The five lemma for relative singular homology.** A map of pairs `f : (X, A) ⟶ (X', A')`
inducing isomorphisms `Hₙ(X) ≅ Hₙ(X')` and `Hₙ(A) ≅ Hₙ(A')`, and also `Hₘ(X) ≅ Hₘ(X')` and
`Hₘ(A) ≅ Hₘ(A')` for `m + 1 = n`, induces an isomorphism `Hₙ(X, A) ≅ Hₙ(X', A')`. -/
lemma isIso_singularHomologyMap_of_isIso {P P' : TopPair.{w}} (f : P ⟶ P') (n : ℕ)
    (hfst : IsIso (SSet.homologyMap (TopCat.toSSet.map (Hom.fst f)) R n))
    (hsnd : IsIso (SSet.homologyMap (TopCat.toSSet.map (Hom.snd f)) R n))
    (hfst' : ∀ m, m + 1 = n → IsIso (SSet.homologyMap (TopCat.toSSet.map (Hom.fst f)) R m))
    (hsnd' : ∀ m, m + 1 = n → IsIso (SSet.homologyMap (TopCat.toSSet.map (Hom.snd f)) R m)) :
    IsIso (TopPair.singularHomologyMap f R n) := by
  have := HomologicalComplex.HomologySequence.isIso_homologyMap_τ₃
    (SSetPair.chainComplexShortComplexMap (toSSetPair.map f) R)
    ((toSSetPair.obj P).shortExact_chainComplexShortComplex R)
    ((toSSetPair.obj P').shortExact_chainComplexShortComplex R) n
  simp only [SSetPair.chainComplexShortComplexMap_τ₁, SSetPair.chainComplexShortComplexMap_τ₂,
    SSetPair.chainComplexShortComplexMap_τ₃, ComplexShape.down_Rel] at this
  -- The homology maps of these chain maps are `SSet.homologyMap` and
  -- `TopPair.singularHomologyMap` by definition.
  have h₁ : IsIso (HomologicalComplex.homologyMap
      (SSet.chainComplexMap (toSSetPair.map f).left R) n) := hsnd
  exact this inferInstance hfst hsnd' fun m hm ↦
    have : IsIso (HomologicalComplex.homologyMap
        (SSet.chainComplexMap (toSSetPair.map f).right R) m) := hfst' m hm
    inferInstance

end LongExactSequence

end TopPair
