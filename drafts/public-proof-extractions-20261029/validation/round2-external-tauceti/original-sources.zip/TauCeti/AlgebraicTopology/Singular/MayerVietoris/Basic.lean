/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import Mathlib.AlgebraicTopology.SimplicialSet.SubcomplexColimits
public import TauCeti.AlgebraicTopology.SimplicialSet.Homology.MayerVietoris
public import TauCeti.AlgebraicTopology.Singular.Subspace

public import TauCeti.AlgebraicTopology.Singular.Subdivision.Small.Equiv
public import TauCeti.Topology.Category.TopCat.Subspace
public import TauCeti.Topology.Sets.FinTwo

/-!
# The Mayer–Vietoris sequence in singular homology

Let `U` and `V` be open subsets of a topological space `X` with `U ∪ V = X`, and let `R` be an
object of an abelian category with coproducts. This file constructs the Mayer–Vietoris long exact
sequence of singular homology with coefficients in `R`,
`⋯ ⟶ Hₙ(U ∩ V) ⟶ Hₙ(U) ⊞ Hₙ(V) ⟶ Hₙ(X) ⟶ Hₙ₋₁(U ∩ V) ⟶ ⋯`,
whose first map is `(i_U, -i_V)` and whose second map is `j_U + j_V`, the `i` and `j` being the
maps induced by the inclusions. The connecting morphism is natural in maps of covered spaces.

The construction is the one of Hatcher. For any two subsets `U` and `V` of `X`, the singular
simplicial sets of `U ∩ V`, `U` and `V` form a pushout square with the subcomplex of singular
simplices of `X` lying in `U` or in `V` (`TopCat.isPushout_toSSet_inter_smallSingularSubcomplex`),
so the Mayer–Vietoris sequence of simplicial sets applies to it. When `U` and `V` are open and
cover `X`, the small-chain theorem (`TauCeti.smallSingularHomologyIso`), which is also the core
of the proof of excision, identifies the homology of that subcomplex with the singular homology
of `X`.

## Main definitions and results

* `TopCat.isPushout_toSSet_inter_smallSingularSubcomplex`: the pushout square of singular
  simplicial sets of an intersection.
* `TopCat.mayerVietorisδ`: the Mayer–Vietoris connecting morphism `Hₙ(X) ⟶ Hₘ(U ∩ V)`,
  `m + 1 = n`, characterized by `TopCat.homologyMap_ι_comp_mayerVietorisδ`. The other two maps
  of the sequence are `SSet.mayerVietorisToBiprod` and `SSet.mayerVietorisFromBiprod` applied to
  the maps of singular simplicial sets induced by the inclusions.
* `TopCat.mayerVietoris_exact₁`, `TopCat.mayerVietoris_exact₂`, `TopCat.mayerVietoris_exact₃`:
  exactness at `Hₘ(U ∩ V)`, at `Hₙ(U) ⊞ Hₙ(V)` and at `Hₙ(X)`.
* `TopCat.epi_mayerVietorisFromBiprod_zero`: surjectivity at the degree-zero endpoint.
* `TopCat.isIso_mayerVietorisToBiprod_of_isZero`: when `Hₙ₊₁(X)` and `Hₙ(X)` vanish,
  `Hₙ(U ∩ V) ≅ Hₙ(U) ⊞ Hₙ(V)`.
* `TopCat.mayerVietorisδ_naturality`: naturality of the connecting morphism.

## References

* A. Hatcher, *Algebraic Topology*, Section 2.2, the Mayer–Vietoris sequences.
-/

public section

noncomputable section

open CategoryTheory Limits Topology

universe w v u

namespace TopCat

variable {X : TopCat.{w}}

variable (U V : Set X)

/-- **The singular simplicial sets of an intersection form a pushout square.** For subsets `U` and
`V` of `X`, the singular simplicial sets of `U ∩ V`, `U` and `V` form a pushout square with the
subcomplex of singular simplices of `X` whose image lies in `U` or in `V`. -/
theorem isPushout_toSSet_inter_smallSingularSubcomplex :
    IsPushout (toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_left (t := V)))))
      (toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_right (s := U)))))
      (toSmallSingularSubcomplex ![U, V] (Matrix.cons_val_zero U ![V]).superset)
      (toSmallSingularSubcomplex ![U, V]
        ((Matrix.cons_val_one U ![V]).trans (Matrix.cons_val_zero V ![])).superset) := by
  let fI := toSSet.map (ofHom (ContinuousMap.subtypeVal (U ∩ V)))
  let fU := toSSet.map (ofHom (ContinuousMap.subtypeVal U))
  let fV := toSSet.map (ofHom (ContinuousMap.subtypeVal V))
  let A := SSet.Subcomplex.range fI
  let B := SSet.Subcomplex.range fU
  let C := SSet.Subcomplex.range fV
  let D := X.smallSingularSubcomplex ![U, V]
  have h_inf : B ⊓ C = A := by
    ext n σ
    -- The lattice structure on subcomplexes is computed pointwise on their `obj` sets.
    change (σ ∈ B.obj n ∧ σ ∈ C.obj n) ↔ σ ∈ A.obj n
    rw [mem_range_toSSet_subtypeVal_iff U,
      mem_range_toSSet_subtypeVal_iff V,
      mem_range_toSSet_subtypeVal_iff (U ∩ V)]
    exact Set.subset_inter_iff.symm
  have h_sup : B ⊔ C = D := by
    ext n σ
    -- Supremum of subcomplexes is also computed pointwise.
    change (σ ∈ B.obj n ∨ σ ∈ C.obj n) ↔ σ ∈ D.obj n
    rw [mem_range_toSSet_subtypeVal_iff U,
      mem_range_toSSet_subtypeVal_iff V, mem_smallSingularSubcomplex_iff]
    simp only [Fin.exists_fin_two, Matrix.cons_val_zero, Matrix.cons_val_one]
  have sq : SSet.Subcomplex.BicartSq A B C D := ⟨h_sup, h_inf⟩
  have hi : Mono fI := Functor.map_mono _ _
  have hu : Mono fU := Functor.map_mono _ _
  have hv : Mono fV := Functor.map_mono _ _
  refine sq.isPushout.of_iso'
    (asIso (SSet.Subcomplex.toRange fI))
    (asIso (SSet.Subcomplex.toRange fU))
    (asIso (SSet.Subcomplex.toRange fV)) (Iso.refl _) ?_ ?_ ?_ ?_
  · rw [← cancel_mono B.ι]
    -- `toRange` followed by the range inclusion is the original singular map.
    change fI = toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_left (t := V)))) ≫ fU
    rw [← Functor.map_comp]
    rfl
  · rw [← cancel_mono C.ι]
    -- `toRange` followed by the range inclusion is the original singular map.
    change fI = toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_right (s := U)))) ≫ fV
    rw [← Functor.map_comp]
    rfl
  · rw [← cancel_mono D.ι]
    -- The range isomorphism reduces this side to the inclusion into `X.toSSet`.
    change fU = toSmallSingularSubcomplex ![U, V]
      (Matrix.cons_val_zero U ![V]).superset ≫ D.ι
    exact (toSmallSingularSubcomplex_ι _ _).symm
  · rw [← cancel_mono D.ι]
    -- The range isomorphism reduces this side to the inclusion into `X.toSSet`.
    change fV = toSmallSingularSubcomplex ![U, V]
      ((Matrix.cons_val_one U ![V]).trans (Matrix.cons_val_zero V ![])).superset ≫ D.ι
    exact (toSmallSingularSubcomplex_ι _ _).symm

/-- Restricting `f` to a set `A` lying in a member of the family `S` and then passing to the small
singular subcomplex of `T` agrees with passing to the small singular subcomplex of `S` first and
then mapping by `f`. -/
@[reassoc]
lemma toSmallSingularSubcomplex_comp_smallSingularSubcomplexMap {Y : TopCat.{w}} {ι κ : Type*}
    (S : ι → Set X) (T : κ → Set Y) (f : X ⟶ Y) (r : ι → κ)
    (hf : ∀ i, Set.MapsTo f (S i) (T (r i))) {A : Set X} {B : Set Y} {i : ι} {j : κ}
    (hA : A ⊆ S i) (hB : B ⊆ T j) (hAB : Set.MapsTo f A B) :
    toSmallSingularSubcomplex S hA ≫ X.smallSingularSubcomplexMap S T f r hf =
      toSSet.map (ofHom ⟨hAB.restrict, f.hom.continuous.restrict hAB⟩) ≫
        toSmallSingularSubcomplex T hB := by
  rw [← cancel_mono (Y.smallSingularSubcomplex T).ι, Category.assoc, Category.assoc,
    smallSingularSubcomplexMap_ι, toSmallSingularSubcomplex_ι_assoc, toSmallSingularSubcomplex_ι,
    ← Functor.map_comp, ← Functor.map_comp, ofHom_subtypeVal_comp f hAB]

/-! ### The Mayer–Vietoris sequence of an open cover by two sets -/

variable {C : Type u} [Category.{v} C] [HasCoproducts.{w} C] [Abelian C] (R : C)
  {U V} (hU : IsOpen U) (hV : IsOpen V) (hUV : U ∪ V = Set.univ)

/-- The Mayer–Vietoris connecting morphism `Hₙ(X) ⟶ Hₘ(U ∩ V)`, where `m + 1 = n`, for an open
cover of `X` by `U` and `V`. It is the connecting morphism of the Mayer–Vietoris sequence of the
singular simplicial sets of `U ∩ V`, `U` and `V`, precomposed with the inverse of the small-chain
isomorphism. -/
def mayerVietorisδ (n m : ℕ) (h : m + 1 = n := by lia) :
    (toSSet.obj X).homology R n ⟶ (toSSet.obj (of ↥(U ∩ V))).homology R m :=
  (TauCeti.smallSingularHomologyIso R ![U, V] (TauCeti.isOpen_vecCons hU hV)
    ((TauCeti.iUnion_vecCons U V).trans hUV) n).inv ≫
    SSet.mayerVietorisδ R (isPushout_toSSet_inter_smallSingularSubcomplex U V) n m h

/-- The Mayer–Vietoris connecting morphism of the open cover restricts, on the homology of the
singular simplices lying in `U` or in `V`, to that of the pushout square of singular simplicial
sets. Since that homology maps isomorphically onto `Hₙ(X)`, this characterizes it. -/
@[reassoc (attr := simp)]
lemma homologyMap_ι_comp_mayerVietorisδ (n m : ℕ) (h : m + 1 = n := by lia) :
    SSet.homologyMap (X.smallSingularSubcomplex ![U, V]).ι R n ≫ mayerVietorisδ R hU hV hUV n m h =
      SSet.mayerVietorisδ R (isPushout_toSSet_inter_smallSingularSubcomplex U V) n m h := by
  rw [mayerVietorisδ, SSet.homologyMap, ← TauCeti.smallSingularHomologyIso_hom R ![U, V]
    (TauCeti.isOpen_vecCons hU hV) ((TauCeti.iUnion_vecCons U V).trans hUV),
    Iso.hom_inv_id_assoc]

private lemma mayerVietorisFromBiprod_comp_homologyMap_ι (n : ℕ) :
    SSet.mayerVietorisFromBiprod R
        (toSmallSingularSubcomplex ![U, V] (Matrix.cons_val_zero U ![V]).superset)
        (toSmallSingularSubcomplex ![U, V]
          ((Matrix.cons_val_one U ![V]).trans (Matrix.cons_val_zero V ![])).superset) n ≫
      SSet.homologyMap (X.smallSingularSubcomplex ![U, V]).ι R n =
    SSet.mayerVietorisFromBiprod R (toSSet.map (ofHom (ContinuousMap.subtypeVal U)))
      (toSSet.map (ofHom (ContinuousMap.subtypeVal V))) n := by
  ext <;> simp [← SSet.homologyMap_comp]

@[reassoc (attr := simp)]
lemma mayerVietorisδ_toBiprod (n m : ℕ) (h : m + 1 = n := by lia) :
    mayerVietorisδ R hU hV hUV n m h ≫
      SSet.mayerVietorisToBiprod R
        (toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_left (t := V)))))
        (toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_right (s := U))))) m = 0 := by
  simp [mayerVietorisδ]

@[reassoc (attr := simp)]
lemma mayerVietorisFromBiprod_δ (n m : ℕ) (h : m + 1 = n := by lia) :
    SSet.mayerVietorisFromBiprod R (toSSet.map (ofHom (ContinuousMap.subtypeVal U)))
        (toSSet.map (ofHom (ContinuousMap.subtypeVal V))) n ≫
      mayerVietorisδ R hU hV hUV n m h = 0 := by
  rw [← mayerVietorisFromBiprod_comp_homologyMap_ι, Category.assoc,
    homologyMap_ι_comp_mayerVietorisδ R hU hV hUV n m h, SSet.mayerVietorisFromBiprod_δ R _ n m h]

/-- **Exactness of the Mayer–Vietoris sequence at `Hₘ(U ∩ V)`.** -/
lemma mayerVietoris_exact₁ (n m : ℕ) (h : m + 1 = n := by lia) :
    (ShortComplex.mk _ _ (mayerVietorisδ_toBiprod R hU hV hUV n m h)).Exact := by
  refine (ShortComplex.exact_iff_of_iso ?_).1
    (SSet.mayerVietoris_exact₁ R (isPushout_toSSet_inter_smallSingularSubcomplex U V) n m h)
  refine ShortComplex.isoMk
    (TauCeti.smallSingularHomologyIso R _ (TauCeti.isOpen_vecCons hU hV)
      ((TauCeti.iUnion_vecCons U V).trans hUV) n)
    (Iso.refl _) (Iso.refl _) ?_ (by simp only [Iso.refl_hom, Category.id_comp, Category.comp_id])
  dsimp only
  rw [Iso.refl_hom, Category.comp_id, TauCeti.smallSingularHomologyIso_hom,
    homologyMap_ι_comp_mayerVietorisδ R hU hV hUV n m h]

include hU hV hUV in
/-- **Exactness of the Mayer–Vietoris sequence at `Hₙ(U) ⊞ Hₙ(V)`.** -/
lemma mayerVietoris_exact₂ (n : ℕ) :
    (ShortComplex.mk _ _
      (SSet.mayerVietorisToBiprod_fromBiprod R ((commSq_ofHom_inter U V).map toSSet) n)).Exact := by
  refine (ShortComplex.exact_iff_of_iso ?_).1
    (SSet.mayerVietoris_exact₂ R (isPushout_toSSet_inter_smallSingularSubcomplex U V) n)
  refine ShortComplex.isoMk (Iso.refl _) (Iso.refl _)
    (TauCeti.smallSingularHomologyIso R _ (TauCeti.isOpen_vecCons hU hV)
      ((TauCeti.iUnion_vecCons U V).trans hUV) n)
    (by simp only [Iso.refl_hom, Category.id_comp, Category.comp_id]) ?_
  dsimp only
  rw [TauCeti.smallSingularHomologyIso_hom, Iso.refl_hom, Category.id_comp,
    mayerVietorisFromBiprod_comp_homologyMap_ι]

/-- **Exactness of the Mayer–Vietoris sequence at `Hₙ(X)`.** -/
lemma mayerVietoris_exact₃ (n m : ℕ) (h : m + 1 = n := by lia) :
    (ShortComplex.mk _ _ (mayerVietorisFromBiprod_δ R hU hV hUV n m h)).Exact := by
  refine (ShortComplex.exact_iff_of_iso ?_).1
    (SSet.mayerVietoris_exact₃ R (isPushout_toSSet_inter_smallSingularSubcomplex U V) n m h)
  refine ShortComplex.isoMk (Iso.refl _)
    (TauCeti.smallSingularHomologyIso R _ (TauCeti.isOpen_vecCons hU hV)
      ((TauCeti.iUnion_vecCons U V).trans hUV) n)
    (Iso.refl _) ?_ ?_
  · dsimp only
    rw [TauCeti.smallSingularHomologyIso_hom, Iso.refl_hom, Category.id_comp,
      mayerVietorisFromBiprod_comp_homologyMap_ι]
  · dsimp only
    rw [Iso.refl_hom, Category.comp_id, TauCeti.smallSingularHomologyIso_hom,
    homologyMap_ι_comp_mayerVietorisδ R hU hV hUV n m h]

include hU hV hUV in
/-- If `Hₙ₊₁(X)` and `Hₙ(X)` vanish, the first map `Hₙ(U ∩ V) ⟶ Hₙ(U) ⊞ Hₙ(V)` of the
Mayer–Vietoris sequence of an open cover is an isomorphism. -/
lemma isIso_mayerVietorisToBiprod_of_isZero (n : ℕ)
    (h₁ : IsZero ((toSSet.obj X).homology R (n + 1))) (h₀ : IsZero ((toSSet.obj X).homology R n)) :
    IsIso (SSet.mayerVietorisToBiprod R
      (toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_left (t := V)))))
      (toSSet.map (ofHom (ContinuousMap.inclusion (Set.inter_subset_right (s := U))))) n) := by
  have := (mayerVietoris_exact₁ R hU hV hUV (n + 1) n).mono_g (h₁.eq_of_src _ _)
  have := (mayerVietoris_exact₂ R hU hV hUV n).epi_f (h₀.eq_of_tgt _ _)
  exact isIso_of_mono_of_epi _

include hU hV hUV in
/-- The map `H₀(U) ⊞ H₀(V) ⟶ H₀(X)` at the end of the Mayer–Vietoris sequence is an
epimorphism. -/
lemma epi_mayerVietorisFromBiprod_zero :
    Epi (SSet.mayerVietorisFromBiprod R (toSSet.map (ofHom (ContinuousMap.subtypeVal U)))
      (toSSet.map (ofHom (ContinuousMap.subtypeVal V))) 0) := by
  have hepi : Epi (SSet.mayerVietorisFromBiprod R
      (toSmallSingularSubcomplex ![U, V] (Matrix.cons_val_zero U ![V]).superset)
      (toSmallSingularSubcomplex ![U, V]
        ((Matrix.cons_val_one U ![V]).trans (Matrix.cons_val_zero V ![])).superset) 0 ≫
      SSet.homologyMap (X.smallSingularSubcomplex ![U, V]).ι R 0) := by
    have : Epi (SSet.homologyMap (X.smallSingularSubcomplex ![U, V]).ι R 0) := by
      -- `smallSingularHomologyIso` identifies this inclusion map with an isomorphism.
      change Epi (HomologicalComplex.homologyMap
        (SSet.chainComplexMap (X.smallSingularSubcomplex ![U, V]).ι R) 0)
      rw [← TauCeti.smallSingularHomologyIso_hom R ![U, V]
        (TauCeti.isOpen_vecCons hU hV) ((TauCeti.iUnion_vecCons U V).trans hUV)]
      infer_instance
    have := SSet.epi_mayerVietorisFromBiprod_zero R
      (isPushout_toSSet_inter_smallSingularSubcomplex U V)
    exact epi_comp _ _
  rw [mayerVietorisFromBiprod_comp_homologyMap_ι] at hepi
  exact hepi

variable {Y : TopCat.{w}} {U' V' : Set Y} (hU' : IsOpen U') (hV' : IsOpen V')
  (hUV' : U' ∪ V' = Set.univ) (f : X ⟶ Y) (hfU : Set.MapsTo f U U') (hfV : Set.MapsTo f V V')

/-- **Naturality of the Mayer–Vietoris connecting morphism.** A map `f : X ⟶ Y` carrying `U` into
`U'` and `V` into `V'` commutes with the connecting morphisms, where `U ∩ V ⟶ U' ∩ V'` is the
restriction of `f`. -/
@[reassoc]
lemma mayerVietorisδ_naturality (n m : ℕ) (h : m + 1 = n := by lia) :
    mayerVietorisδ R hU hV hUV n m h ≫
        SSet.homologyMap (toSSet.map (ofHom ⟨(hfU.inter_inter hfV).restrict,
          f.hom.continuous.restrict (hfU.inter_inter hfV)⟩)) R m =
      SSet.homologyMap (toSSet.map f) R n ≫ mayerVietorisδ R hU' hV' hUV' n m h := by
  have hf : ∀ i, Set.MapsTo f (![U, V] i) (![U', V'] (id i)) := by
    simp [Fin.forall_fin_two, hfU, hfV]
  have hsmall := TauCeti.smallSingularHomologyIso_naturality R ![U, V]
    (TauCeti.isOpen_vecCons hU hV) ((TauCeti.iUnion_vecCons U V).trans hUV) ![U', V'] f id hf
    (TauCeti.isOpen_vecCons hU' hV') ((TauCeti.iUnion_vecCons U' V').trans hUV') n
  have hnat := SSet.mayerVietorisδ_naturality R
    (toSSet.map (ofHom ⟨(hfU.inter_inter hfV).restrict,
      f.hom.continuous.restrict (hfU.inter_inter hfV)⟩))
    (toSSet.map (ofHom ⟨hfU.restrict, f.hom.continuous.restrict hfU⟩))
    (toSSet.map (ofHom ⟨hfV.restrict, f.hom.continuous.restrict hfV⟩))
    (X.smallSingularSubcomplexMap ![U, V] ![U', V'] f id hf)
    (isPushout_toSSet_inter_smallSingularSubcomplex U V)
    (isPushout_toSSet_inter_smallSingularSubcomplex U' V') ?_ ?_ ?_ ?_ n m h
  · rw [mayerVietorisδ, mayerVietorisδ, Category.assoc, hnat, ← Category.assoc,
      ← Category.assoc]
    congr 1
    rw [Iso.inv_comp_eq, ← Category.assoc, hsmall, Category.assoc, Iso.hom_inv_id,
      Category.comp_id]
  -- The four squares of singular simplicial sets commute because the underlying squares of
  -- continuous maps do.
  · rw [← Functor.map_comp, ← Functor.map_comp, ofHom_inclusion_comp]
  · rw [← Functor.map_comp, ← Functor.map_comp, ofHom_inclusion_comp]
  · exact toSmallSingularSubcomplex_comp_smallSingularSubcomplexMap _ _ f id hf _ _ hfU
  · exact toSmallSingularSubcomplex_comp_smallSingularSubcomplexMap _ _ f id hf _ _ hfV

end TopCat
