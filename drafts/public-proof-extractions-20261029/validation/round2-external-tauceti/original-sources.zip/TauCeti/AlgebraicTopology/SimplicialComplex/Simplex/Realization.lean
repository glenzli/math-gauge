/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

import Mathlib.Analysis.Normed.Module.RCLike.Real
import TauCeti.AlgebraicTopology.SimplicialComplex.Realization.Coordinates

public import Mathlib.Analysis.Convex.StdSimplex
public import TauCeti.AlgebraicTopology.SimplicialComplex.Realization.Basic
public import TauCeti.AlgebraicTopology.SimplicialComplex.Simplex.Basic
public import TauCeti.Geometry.Convex.ConvexSpace.LocallyPathConnectedSpaceStdSimplex

/-!
# Realizations of finite simplices

This file compares the closed coordinate simplex on any finite vertex set, including the empty
set, with Mathlib's standard simplex on that set. It also identifies the geometric realization of
any closed simplex in an ambient weak realization with its coordinate simplex, preserving
barycentric coordinates in both directions. This works even in infinite ambient complexes.
Finally, it compares the realization of
the full abstract complex on a finite vertex type with Mathlib's standard simplex of barycentric
coordinate functions. Specializing to two
vertices gives a homeomorphism from the standard one-simplex to the unit interval. Its boundary,
the bottom abstract complex on `Fin 2`, is then identified with the unit zero-sphere.

These are the first realization round-trips in layer 11 of the geometric-topology roadmap. The
roadmap asks that the realization of the boundary of the standard `n`-simplex be homeomorphic to
`Sⁿ⁻¹`; `realizationOneSimplexBoundaryHomeomorphSphereZero` establishes the base case `n = 1`.
The interval identification also supplies the standard topological model for the simplicial
interval used in the later product-and-collapse formulation of Zeeman's conjecture.

The barycentric simplex uses Mathlib's `Convexity.StdSimplex`, and its homeomorphism with the
unit interval is Mathlib's `Convexity.StdSimplex.homeomorphI`. The zero-sphere identification is
the elementary equivalence between its two points and `Fin 2`.

## Main results

* `Finset.standardSimplexHomeomorph`: a closed coordinate simplex is homeomorphic to Mathlib's
  standard simplex on its finite vertex set.
* `AbstractSimplicialComplex.instLocallyPathConnectedSpaceStandardSimplex`: every closed
  coordinate simplex is locally path-connected.
* `realizationTopHomeomorphStdSimplex`: the full complex realizes to Mathlib's standard simplex.
* `range_realization_coe_top`, `range_realization_coe_standardSuccSimplexBoundary`: the coordinate
  vectors of the realizations of the full complex and of the boundary of a standard simplex.
* `realizationOneSimplexHomeomorphUnitInterval`: the standard one-simplex realizes to `[0, 1]`.
* `realizationOneSimplexBoundaryHomeomorphSphereZero`: its boundary realizes to `S⁰`.
-/

public section

noncomputable section

open Metric Set TauCeti.SetLike

namespace Finset

open AbstractSimplicialComplex

variable {α : Type*} {σ : Finset α}

attribute [local instance] Classical.decEq

/-- A closed coordinate simplex is homeomorphic to Mathlib's standard simplex on its finite
vertex set, including when that set is empty. -/
def standardSimplexHomeomorph (σ : Finset α) : StandardSimplex σ ≃ₜ Convexity.StdSimplex ℝ σ where
  toFun x := {
    weights := x.1.subtypeDomain (· ∈ σ)
    nonneg := fun a => StandardSimplex.nonneg x a
    total := by
      exact (Finsupp.sum_subtypeDomain_index (p := fun a => a ∈ σ)
        (h := fun (_ : α) (r : ℝ) => r) (StandardSimplex.support_subset x)).trans
          (StandardSimplex.sum_eq_one x) }
  invFun w := ⟨w.weights.mapDomain Subtype.val, by
    rw [Finset.coe_image, mem_standardSimplex_iff]
    refine ⟨fun a => Finsupp.mapDomain_nonneg w.nonneg a, ?_, ?_⟩
    · rw [Finsupp.sum_mapDomain_index (fun _ => rfl) (fun _ _ _ => rfl)]
      exact w.total
    · intro a ha
      obtain ⟨b, -, rfl⟩ := Finset.mem_image.mp (Finsupp.mapDomain_support ha)
      exact b.2⟩
  left_inv x := by
    apply Subtype.ext
    ext a
    by_cases ha : a ∈ σ
    · simpa only [Finsupp.subtypeDomain_apply] using
        Finsupp.mapDomain_apply_of_injective Subtype.val_injective
          (x.1.subtypeDomain (· ∈ σ)) ⟨a, ha⟩
    · rw [Finsupp.mapDomain_of_notMem_range]
      · exact (Finsupp.notMem_support_iff.mp
          (fun h => ha (StandardSimplex.support_subset x h))).symm
      · simpa using ha
  right_inv w := by
    apply Convexity.StdSimplex.ext
    ext a
    exact Finsupp.mapDomain_apply_of_injective Subtype.val_injective w.weights a
  continuous_toFun := by
    apply (Convexity.StdSimplex.isEmbedding_toFun_comp_weights ℝ σ).continuous_iff.mpr
    exact continuous_pi fun a => (continuous_apply a.1).comp continuous_induced_dom
  continuous_invFun := by
    apply continuous_induced_rng.mpr
    exact continuous_pi fun a =>
      (Convexity.StdSimplex.continuous_weights_apply ℝ a).comp
        (Convexity.StdSimplex.continuous_map ℝ (Subtype.val : σ → α))

/-- The finite-simplex comparison reads the original coordinate at each vertex of the face. -/
@[simp]
theorem standardSimplexHomeomorph_weights (σ : Finset α) (x : StandardSimplex σ) (a : σ) :
    (standardSimplexHomeomorph σ x).weights a = x.1 a := (rfl)

/-- The inverse finite-simplex comparison extends the finite coordinate vector by zero. -/
@[simp]
theorem standardSimplexHomeomorph_symm_val (σ : Finset α) (w : Convexity.StdSimplex ℝ σ) :
    ((standardSimplexHomeomorph σ).symm w : α →₀ ℝ) = w.weights.mapDomain Subtype.val := (rfl)

end Finset

namespace AbstractSimplicialComplex

variable {ι : Type*}

attribute [local instance] Classical.decEq

/-- Every closed coordinate simplex is locally path-connected. -/
instance instLocallyPathConnectedSpaceStandardSimplex (σ : Finset ι) :
    LocallyPathConnectedSpace (StandardSimplex σ) :=
  (Finset.standardSimplexHomeomorph σ).symm.locallyPathConnectedSpace

/-- A closed face, with the subspace topology of the weak realization, is homeomorphic to
its coordinate simplex. The ambient complex and its vertex type may be infinite. -/
noncomputable def simplexRealizationHomeomorph (K : AbstractSimplicialComplex ι)
    (V : Finset ι) (hV : V ∈ K) :
    StandardSimplex V ≃ₜ
      {x : Realization K // x.1.support ∈ PreAbstractSimplicialComplex.simplex V} := by
  let e : StandardSimplex V ≃
      {x : Realization K // x.1.support ∈ PreAbstractSimplicialComplex.simplex V} := {
    toFun x := ⟨faceInclusion K ⟨V, hV⟩ x, by
      refine PreAbstractSimplicialComplex.mem_simplex.mpr
        ⟨K.isRelLowerSet_faces.prop_of_mem (support_mem K (faceInclusion K ⟨V, hV⟩ x)), ?_⟩
      simpa only [faceInclusion_val] using StandardSimplex.support_subset x⟩
    invFun x := ⟨x.1.1, by
      simpa only [Finset.coe_image] using mem_standardSimplex_iff.mpr
        ⟨Realization.nonneg K x.1, Realization.sum_eq_one K x.1,
          (PreAbstractSimplicialComplex.mem_simplex.mp x.2).2⟩⟩
    left_inv x := Subtype.ext (faceInclusion_val K ⟨V, hV⟩ x)
    right_inv x := Subtype.ext (Subtype.ext (faceInclusion_val K ⟨V, hV⟩ _)) }
  letI : CompactSpace (StandardSimplex V) :=
    (Finset.standardSimplexHomeomorph V).symm.compactSpace
  have hc : Continuous e := (continuous_faceInclusion K ⟨V, hV⟩).subtype_mk _
  exact e.toHomeomorphOfContinuousClosed hc hc.isClosedMap

/-- The closed-face identification preserves the barycentric coordinate vector. -/
@[simp] theorem simplexRealizationHomeomorph_val (K : AbstractSimplicialComplex ι)
    (V : Finset ι) (hV : V ∈ K) (x : StandardSimplex V) :
    (K.simplexRealizationHomeomorph V hV x).1.1 = x.1 :=
  faceInclusion_val K ⟨V, hV⟩ x

/-- The inverse closed-face identification preserves the barycentric coordinate vector. -/
@[simp] theorem simplexRealizationHomeomorph_symm_val (K : AbstractSimplicialComplex ι)
    (V : Finset ι) (hV : V ∈ K)
    (x : {x : Realization K // x.1.support ∈ PreAbstractSimplicialComplex.simplex V}) :
    ((K.simplexRealizationHomeomorph V hV).symm x).1 = x.1.1 := by
  have h := congrArg (fun y => y.1.1)
    ((K.simplexRealizationHomeomorph V hV).apply_symm_apply x)
  simpa only [simplexRealizationHomeomorph_val] using h

/-- The coordinate vectors of the realization of the boundary of a standard simplex are the weight
vectors of the standard simplex with some vanishing coordinate. -/
theorem range_realization_coe_standardSuccSimplexBoundary (n : ℕ) :
    range (fun x : Realization (standardSuccSimplexBoundary n) => (x.1 : Fin (n + 2) → ℝ)) =
      {z ∈ range fun t : Convexity.StdSimplex ℝ (Fin (n + 2)) => ⇑t.weights | ∃ i, z i = 0} := by
  ext z
  have hz : ∑ i, z i = 1 → z ≠ 0 := by
    rintro h rfl
    simp at h
  rw [mem_range_realization_coe_iff, mem_standardSuccSimplexBoundary_iff]
  simp [Finset.ssubset_univ_iff, Finset.eq_univ_iff_forall,
    Convexity.StdSimplex.range_toFun_comp_weights]
  grind

variable [Fintype ι] [Nonempty ι]

private theorem univ_mem_top : (Finset.univ : Finset ι) ∈ (⊤ : AbstractSimplicialComplex ι) :=
  Finset.univ_nonempty

private def topFace : Face (⊤ : AbstractSimplicialComplex ι) :=
  ⟨Finset.univ, univ_mem_top⟩

/-- The realization of the full abstract complex on a finite vertex type is homeomorphic to
Mathlib's standard simplex of nonnegative coordinate functions summing to one. -/
noncomputable def realizationTopHomeomorphStdSimplex :
    Realization (⊤ : AbstractSimplicialComplex ι) ≃ₜ Convexity.StdSimplex ℝ ι where
  toFun x := by
    refine ⟨x.1, fun i => ?_, ?_⟩ <;>
      let y : StandardSimplex (carrier (⊤ : AbstractSimplicialComplex ι) x).1 :=
        ⟨x.1, mem_convexHull_carrier _ x⟩
    · exact StandardSimplex.nonneg y i
    · exact StandardSimplex.sum_eq_one y
  invFun x :=
    faceInclusion (⊤ : AbstractSimplicialComplex ι)
      (topFace (ι := ι))
      ⟨x.weights, by
        rw [Finset.coe_image, mem_standardSimplex_iff]
        exact ⟨x.weights_nonneg, x.total, Finset.subset_univ _⟩⟩
  left_inv x := Subtype.ext (faceInclusion_val _ _ _)
  right_inv x := Convexity.StdSimplex.ext (faceInclusion_val _ _ _)
  continuous_toFun := by
    rw [(Convexity.StdSimplex.isEmbedding_toFun_comp_weights ℝ ι).continuous_iff]
    apply continuous_pi
    intro i
    apply continuous_iff_faceInclusion.2
    intro σ
    exact ((continuous_apply i).comp
      (continuous_induced_dom :
        Continuous (fun y : StandardSimplex σ.1 => (y.1 : ι → ℝ)))).congr fun y => by
          exact congrArg (fun z : ι →₀ ℝ => z i) (faceInclusion_val _ _ y).symm
  continuous_invFun := by
    apply (continuous_faceInclusion (⊤ : AbstractSimplicialComplex ι)
      (topFace (ι := ι))).comp
    apply continuous_induced_rng.mpr
    exact continuous_pi fun i => Convexity.StdSimplex.continuous_weights_apply ℝ i

/-- The full-complex realization homeomorphism reads the same barycentric coordinates. -/
@[simp]
theorem realizationTopHomeomorphStdSimplex_apply (x : Realization
    (⊤ : AbstractSimplicialComplex ι)) (i : ι) :
    (realizationTopHomeomorphStdSimplex x).weights i = x.1 i := by
  rfl

/-- The inverse full-complex realization homeomorphism has the prescribed barycentric
coordinates. -/
@[simp]
theorem realizationTopHomeomorphStdSimplex_symm_apply_val (x : Convexity.StdSimplex ℝ ι) (i : ι) :
    (realizationTopHomeomorphStdSimplex.symm x : ι →₀ ℝ) i = x.weights i := by
  rw [realizationTopHomeomorphStdSimplex]
  exact congrArg (fun z : ι →₀ ℝ => z i)
    (faceInclusion_val (⊤ : AbstractSimplicialComplex ι)
      (topFace (ι := ι)) _)

omit [Fintype ι] [Nonempty ι] in
/-- The coordinate vectors of the realization of the full complex on a finite type are the weight
vectors of the standard simplex. -/
theorem range_realization_coe_top [Finite ι] :
    range (fun x : Realization (⊤ : AbstractSimplicialComplex ι) => (x.1 : ι → ℝ)) =
      range fun t : Convexity.StdSimplex ℝ ι => ⇑t.weights := by
  have := Fintype.ofFinite ι
  rcases isEmpty_or_nonempty ι with hι | hι
  · ext z
    rw [mem_range_realization_coe_iff, Convexity.StdSimplex.range_toFun_comp_weights]
    simp
  · rw [← realizationTopHomeomorphStdSimplex.surjective.range_comp]
    exact congrArg range (funext fun x => funext fun i =>
      (realizationTopHomeomorphStdSimplex_apply x i).symm)

/-- The realization of the standard one-simplex is homeomorphic to the unit interval. The zeroth
vertex maps to `0` and the first vertex maps to `1`; see the two endpoint lemmas below. -/
noncomputable def realizationOneSimplexHomeomorphUnitInterval :
    Realization (⊤ : AbstractSimplicialComplex (Fin 2)) ≃ₜ unitInterval :=
  (realizationTopHomeomorphStdSimplex (ι := Fin 2)).trans Convexity.StdSimplex.homeomorphI

private theorem homeomorphI_symm_apply_coe (x : unitInterval) :
    ((Convexity.StdSimplex.homeomorphI.symm x).weights : Fin 2 → ℝ) =
      ![1 - (x : ℝ), (x : ℝ)] := by
  have h : Convexity.StdSimplex.homeomorphI.symm x =
      Convexity.StdSimplex.duple (s := 1 - (x : ℝ)) (t := (x : ℝ)) 0 1
        (sub_nonneg.mpr x.2.2) x.2.1 (by ring) := by
    rw [Homeomorph.symm_apply_eq]
    exact Subtype.ext (by
      simp [Convexity.StdSimplex.homeomorphI_apply_coe,
        Convexity.StdSimplex.weights_duple])
  rw [h, Convexity.StdSimplex.weights_duple]
  funext i
  fin_cases i <;> simp

/-- The one-simplex homeomorphism is its second barycentric coordinate. -/
@[simp]
theorem realizationOneSimplexHomeomorphUnitInterval_coe (x : Realization
    (⊤ : AbstractSimplicialComplex (Fin 2))) :
    (realizationOneSimplexHomeomorphUnitInterval x : ℝ) = x.1 1 := by
  rw [realizationOneSimplexHomeomorphUnitInterval, Homeomorph.trans_apply,
    Convexity.StdSimplex.homeomorphI_apply_coe, realizationTopHomeomorphStdSimplex_apply]

/-- The zeroth barycentric coordinate of the interval inverse is one minus the interval
coordinate. -/
@[simp]
theorem realizationOneSimplexHomeomorphUnitInterval_symm_apply_val_zero (x : unitInterval) :
    (realizationOneSimplexHomeomorphUnitInterval.symm x : Fin 2 →₀ ℝ) 0 =
      1 - (x : ℝ) := by
  rw [realizationOneSimplexHomeomorphUnitInterval, Homeomorph.symm_trans_apply,
    realizationTopHomeomorphStdSimplex_symm_apply_val,
    homeomorphI_symm_apply_coe]
  rfl

/-- The first barycentric coordinate of the interval inverse is the interval coordinate. -/
@[simp]
theorem realizationOneSimplexHomeomorphUnitInterval_symm_apply_val_one (x : unitInterval) :
    (realizationOneSimplexHomeomorphUnitInterval.symm x : Fin 2 →₀ ℝ) 1 = (x : ℝ) := by
  rw [realizationOneSimplexHomeomorphUnitInterval, Homeomorph.symm_trans_apply,
    realizationTopHomeomorphStdSimplex_symm_apply_val,
    homeomorphI_symm_apply_coe]
  rfl

/-- The zeroth vertex of the realized one-simplex is the left endpoint of the interval. -/
@[simp]
theorem realizationOneSimplexHomeomorphUnitInterval_vertex_zero :
    realizationOneSimplexHomeomorphUnitInterval
      (vertex (⊤ : AbstractSimplicialComplex (Fin 2)) 0) = 0 := by
  apply Subtype.ext
  simp

/-- The first vertex of the realized one-simplex is the right endpoint of the interval. -/
@[simp]
theorem realizationOneSimplexHomeomorphUnitInterval_vertex_one :
    realizationOneSimplexHomeomorphUnitInterval
      (vertex (⊤ : AbstractSimplicialComplex (Fin 2)) 1) = 1 := by
  apply Subtype.ext
  simp

private noncomputable def finTwoEquivSphereZero : Fin 2 ≃ sphere (0 : ℝ) 1 := by
  let f : Fin 2 → sphere (0 : ℝ) 1 := fun i =>
    if i = 0 then ⟨1, by simp⟩ else ⟨-1, by simp⟩
  refine Equiv.ofBijective f ⟨?_, ?_⟩
  · intro i j hij
    fin_cases i <;> fin_cases j <;> simp only [f] at hij ⊢ <;> norm_num at hij
  · intro x
    have hx : |(x : ℝ)| = 1 := by
      simpa only [Real.norm_eq_abs] using norm_eq_of_mem_sphere x
    rcases (abs_eq zero_le_one).mp hx with hx | hx
    · exact ⟨0, by apply Subtype.ext; simp [f, hx]⟩
    · exact ⟨1, by apply Subtype.ext; simp [f, hx]⟩

private noncomputable def finTwoHomeomorphSphereZero : Fin 2 ≃ₜ sphere (0 : ℝ) 1 := by
  letI : Finite (sphere (0 : ℝ) 1) :=
    Finite.of_equiv (Fin 2) finTwoEquivSphereZero
  exact Homeomorph.ofDiscrete finTwoEquivSphereZero

@[simp]
private theorem finTwoHomeomorphSphereZero_zero : (finTwoHomeomorphSphereZero 0 : ℝ) = 1 :=
  rfl

@[simp]
private theorem finTwoHomeomorphSphereZero_one : (finTwoHomeomorphSphereZero 1 : ℝ) = -1 :=
  rfl

/-- The realization of the boundary of the standard one-simplex is homeomorphic to the unit
zero-sphere. By `simplexBoundary_univ_fin_two`, the underlying precomplex of the source is exactly
the boundary of the simplex on the two vertices. -/
noncomputable def realizationOneSimplexBoundaryHomeomorphSphereZero :
    Realization (⊥ : AbstractSimplicialComplex (Fin 2)) ≃ₜ sphere (0 : ℝ) 1 :=
  (realizationBotHomeomorph (ι := Fin 2)).trans finTwoHomeomorphSphereZero

/-- The zeroth boundary vertex maps to `1` on the zero-sphere. -/
@[simp]
theorem realizationOneSimplexBoundaryHomeomorphSphereZero_vertex_zero :
    (realizationOneSimplexBoundaryHomeomorphSphereZero
      (vertex (⊥ : AbstractSimplicialComplex (Fin 2)) 0) : ℝ) = 1 := by
  rw [realizationOneSimplexBoundaryHomeomorphSphereZero, Homeomorph.trans_apply,
    realizationBotHomeomorph_apply_vertex, finTwoHomeomorphSphereZero_zero]

/-- The first boundary vertex maps to `-1` on the zero-sphere. -/
@[simp]
theorem realizationOneSimplexBoundaryHomeomorphSphereZero_vertex_one :
    (realizationOneSimplexBoundaryHomeomorphSphereZero
      (vertex (⊥ : AbstractSimplicialComplex (Fin 2)) 1) : ℝ) = -1 := by
  rw [realizationOneSimplexBoundaryHomeomorphSphereZero, Homeomorph.trans_apply,
    realizationBotHomeomorph_apply_vertex, finTwoHomeomorphSphereZero_one]

/-- The inverse zero-sphere homeomorphism sends `1` to the zeroth boundary vertex. -/
@[simp]
theorem realizationOneSimplexBoundaryHomeomorphSphereZero_symm_apply_one :
    realizationOneSimplexBoundaryHomeomorphSphereZero.symm ⟨1, by simp⟩ =
      vertex (⊥ : AbstractSimplicialComplex (Fin 2)) 0 := by
  apply realizationOneSimplexBoundaryHomeomorphSphereZero.injective
  apply Subtype.ext
  simp

/-- The inverse zero-sphere homeomorphism sends `-1` to the first boundary vertex. -/
@[simp]
theorem realizationOneSimplexBoundaryHomeomorphSphereZero_symm_apply_neg_one :
    realizationOneSimplexBoundaryHomeomorphSphereZero.symm ⟨-1, by simp⟩ =
      vertex (⊥ : AbstractSimplicialComplex (Fin 2)) 1 := by
  apply realizationOneSimplexBoundaryHomeomorphSphereZero.injective
  apply Subtype.ext
  simp

end AbstractSimplicialComplex
