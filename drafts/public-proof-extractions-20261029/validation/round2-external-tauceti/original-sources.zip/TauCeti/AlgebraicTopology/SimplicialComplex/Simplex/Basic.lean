/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import TauCeti.AlgebraicTopology.SimplicialComplex.Basic
public import Mathlib.Data.Finset.Powerset
public import Mathlib.Data.Fintype.Card
public import Mathlib.Data.Set.Finite.Basic
public import Mathlib.Order.Fin.Basic
public import TauCeti.AlgebraicTopology.SimplicialComplex.IsCone

/-!
# Abstract simplices and their boundaries

This file defines the abstract simplex spanned by a finite set of vertices and its boundary.
Both are `PreAbstractSimplicialComplex`es on the original ambient vertex type: this lets the
construction remember exactly which vertices occur, unlike `AbstractSimplicialComplex`, which
must contain every singleton of its ambient type.

The boundary consists of the nonempty proper subsets of the spanning vertex set. These
constructions provide the standard models needed for the recursive definitions of combinatorial
spheres and balls in layer 11 of the geometric-topology roadmap.

The definitions follow Rourke--Sanderson, *Introduction to Piecewise-Linear Topology*, Chapter 2.

## Main definitions

* `PreAbstractSimplicialComplex.simplex`: the complex of nonempty subsets of a finite vertex set.
* `PreAbstractSimplicialComplex.simplexBoundary`: its proper faces.
* `AbstractSimplicialComplex.standardSuccSimplexBoundary`: the boundary complex of the standard
  `(n + 1)`-simplex.
-/

public section

namespace PreAbstractSimplicialComplex

variable {ι : Type*}

/-- The abstract simplex spanned by `V`: its faces are the nonempty subsets of `V`. -/
def simplex (V : Finset ι) : _root_.PreAbstractSimplicialComplex ι where
  faces := {σ | σ.Nonempty ∧ σ ⊆ V}
  isRelLowerSet_faces := by
    rintro σ ⟨hσ, hσV⟩
    exact ⟨hσ, fun _ hτσ hτ => ⟨hτ, hτσ.trans hσV⟩⟩

/-- The boundary of the abstract simplex spanned by `V`: its faces are the nonempty proper
subsets of `V`. -/
def simplexBoundary (V : Finset ι) : _root_.PreAbstractSimplicialComplex ι where
  faces := {σ | σ.Nonempty ∧ σ ⊂ V}
  isRelLowerSet_faces := by
    rintro σ ⟨hσ, hσV⟩
    refine ⟨hσ, fun _ hτσ hτ => ⟨hτ, hτσ.trans_ssubset hσV⟩⟩

variable {K : _root_.PreAbstractSimplicialComplex ι} {V W σ : Finset ι}

/-- A finite set is a face of a simplex exactly when it is nonempty and contained in the
spanning vertex set. -/
@[simp]
theorem mem_simplex : σ ∈ simplex V ↔ σ.Nonempty ∧ σ ⊆ V :=
  Iff.rfl

/-- The image of a simplex is the simplex on the image of its spanning vertices. -/
@[simp]
theorem map_simplex {κ : Type*} [DecidableEq κ] (f : ι → κ) :
    (simplex V).map f = simplex (V.image f) := by
  refine SetLike.ext fun τ => ?_
  constructor
  · rintro ⟨σ, hσ, rfl⟩
    obtain ⟨hne, hsub⟩ := mem_simplex.mp hσ
    exact mem_simplex.mpr ⟨hne.image f, Finset.image_subset_image hsub⟩
  · intro hτ
    obtain ⟨hne, hsub⟩ := mem_simplex.mp hτ
    obtain ⟨σ, hσ, rfl⟩ := Finset.subset_image_iff.mp hsub
    exact mem_map_iff.mpr ⟨σ, mem_simplex.mpr ⟨Finset.image_nonempty.mp hne, hσ⟩, rfl⟩

/-- A finite set is a face of a simplex boundary exactly when it is a nonempty proper subset of
the spanning vertex set. -/
@[simp]
theorem mem_simplexBoundary : σ ∈ simplexBoundary V ↔ σ.Nonempty ∧ σ ⊂ V :=
  Iff.rfl

/-- The spanning vertex set is a face of its simplex exactly when it is nonempty. -/
theorem self_mem_simplex : V ∈ simplex V ↔ V.Nonempty := by
  simp

/-- The spanning vertex set is not a face of its own boundary. -/
theorem self_notMem_simplexBoundary : V ∉ simplexBoundary V := by
  simp

/-- A vertex belongs to the spanning set exactly when its singleton is a face of the simplex. -/
theorem singleton_mem_simplex {v : ι} : {v} ∈ simplex V ↔ v ∈ V := by
  simp

/-- A zero-simplex has exactly its singleton vertex as a face. -/
-- Compute faces before converting a singleton simplex to the point complex.
@[simp↓]
theorem faces_simplex_singleton (v : ι) : (simplex {v}).faces = {{v}} := by
  ext σ
  constructor
  · rintro ⟨hne, hsub⟩
    exact hne.subset_singleton_iff.mp hsub
  · rintro rfl
    exact mem_simplex.mpr ⟨Finset.singleton_nonempty v, Finset.Subset.rfl⟩

/-- The boundary of a one-simplex consists of its two singleton vertices. -/
@[simp]
theorem faces_simplexBoundary_pair [DecidableEq ι] {v w : ι} (hne : v ≠ w) :
    (simplexBoundary {v, w}).faces = {{v}, {w}} := by
  ext σ
  constructor
  · rintro ⟨hσ, hsub⟩
    have hlt : σ.card < 2 := by
      simpa [Finset.card_pair hne] using Finset.card_lt_card hsub
    have hc : σ.card = 1 := by
      have := Finset.card_pos.mpr hσ
      omega
    obtain ⟨x, rfl⟩ := Finset.card_eq_one.mp hc
    have hx : x = v ∨ x = w := by
      simpa using hsub.subset (Finset.mem_singleton_self x)
    rcases hx with rfl | rfl <;> simp
  · rintro (rfl | rfl) <;> apply mem_simplexBoundary.mpr <;>
      refine ⟨Finset.singleton_nonempty _,
        Finset.ssubset_iff_subset_ne.mpr ⟨by simp, ?_⟩⟩
    all_goals
      intro he
      have hc := congrArg Finset.card he
      simp [Finset.card_pair hne] at hc

/-- An abstract simplex has finitely many faces: they are subsets of the spanning set. -/
theorem finite_faces_simplex (V : Finset ι) : (simplex V).faces.Finite :=
  V.powerset.finite_toSet.subset fun _ hσ => Finset.mem_powerset.mpr (mem_simplex.mp hσ).2

/-- An abstract simplex is a cone with apex any of its vertices. -/
theorem isCone_simplex [DecidableEq ι] {v : ι} (hv : v ∈ V) : IsCone (simplex V) v where
  apex_mem := mem_simplex.mpr ⟨Finset.singleton_nonempty v, Finset.singleton_subset_iff.mpr hv⟩
  insert_mem σ hσ :=
    mem_simplex.mpr ⟨Finset.insert_nonempty v σ, Finset.insert_subset hv (mem_simplex.mp hσ).2⟩

/-- A singleton is a boundary face exactly when its vertex belongs to a spanning set containing
at least one other vertex. -/
theorem singleton_mem_simplexBoundary {v : ι} : {v} ∈ simplexBoundary V ↔ v ∈ V ∧ V ≠ {v} := by
  simp only [mem_simplexBoundary, Finset.singleton_nonempty, true_and]
  rw [Finset.ssubset_iff_subset_ne, Finset.singleton_subset_iff]
  constructor
  · exact fun ⟨hv, hne⟩ => ⟨hv, hne.symm⟩
  · exact fun ⟨hv, hne⟩ => ⟨hv, hne.symm⟩

/-- The boundary is a subcomplex of the simplex. -/
theorem simplexBoundary_le_simplex : simplexBoundary V ≤ simplex V :=
  fun _ hσ => ⟨hσ.1, hσ.2.subset⟩

/-- The boundary of an abstract simplex has finitely many faces. -/
theorem finite_faces_simplexBoundary (V : Finset ι) : (simplexBoundary V).faces.Finite :=
  (finite_faces_simplex V).subset simplexBoundary_le_simplex

/-- Injective relabeling takes a simplex boundary to the boundary on the image vertex set. -/
@[simp]
theorem map_simplexBoundary {κ : Type*} [DecidableEq κ] (V : Finset ι) (f : ι ↪ κ) :
    (simplexBoundary V).map f = simplexBoundary (V.image f) := by
  ext τ
  constructor
  · rintro ⟨σ, hσ, rfl⟩
    exact mem_simplexBoundary.mpr ⟨Finset.image_nonempty.mpr hσ.1,
      (Finset.image_ssubset_image f.injective).mpr hσ.2⟩
  · intro hτ
    obtain ⟨σ, -, rfl⟩ := Finset.subset_image_iff.mp hτ.2.subset
    exact mem_map_iff.mpr ⟨σ, mem_simplexBoundary.mpr
      ⟨Finset.image_nonempty.mp hτ.1,
        (Finset.image_ssubset_image f.injective).mp hτ.2⟩, rfl⟩

/-- The boundary of a simplex with nonempty spanning set is a strict subcomplex of the simplex. -/
theorem simplexBoundary_lt_simplex (hV : V.Nonempty) : simplexBoundary V < simplex V := by
  refine lt_of_le_of_ne simplexBoundary_le_simplex ?_
  intro h
  have : V ∈ simplexBoundary V := h ▸ (self_mem_simplex.mpr hV : V ∈ simplex V)
  exact self_notMem_simplexBoundary this

/-- The simplex on the empty spanning set has no faces. -/
@[simp]
theorem simplex_empty : simplex (∅ : Finset ι) = ⊥ := by
  ext σ
  constructor
  · intro hσ
    exact hσ.1.ne_empty (Finset.subset_empty.mp hσ.2)
  · exact False.elim

/-- The boundary of the empty simplex has no faces. -/
@[simp]
theorem simplexBoundary_empty : simplexBoundary (∅ : Finset ι) = ⊥ := by
  ext σ
  constructor
  · intro hσ
    exact hσ.1.ne_empty (Finset.subset_empty.mp hσ.2.subset)
  · exact False.elim

/-- The boundary of a one-vertex simplex is empty. -/
@[simp]
theorem simplexBoundary_singleton (v : ι) : simplexBoundary {v} = ⊥ := by
  ext σ
  constructor
  · intro hσ
    exact hσ.1.ne_empty (Finset.ssubset_singleton_iff.mp hσ.2)
  · exact False.elim

/-- The simplex on all vertices is the top pre-abstract simplicial complex. -/
@[simp]
theorem simplex_univ [Fintype ι] : simplex (Finset.univ : Finset ι) = ⊤ := by
  apply le_antisymm
  · exact fun _ hσ => hσ.1
  · exact fun _ hσ => ⟨hσ, Finset.subset_univ _⟩

/-- The boundary of the standard one-simplex consists of its two vertices. Equivalently, it is
the underlying precomplex of the bottom abstract simplicial complex on `Fin 2`. -/
@[simp]
theorem simplexBoundary_univ_fin_two :
    simplexBoundary (Finset.univ : Finset (Fin 2)) =
      (⊥ : AbstractSimplicialComplex (Fin 2)).toPreAbstractSimplicialComplex := by
  ext σ
  constructor
  · rintro ⟨hσ, hproper⟩
    have hcard : σ.card = 1 := by
      have hpos : 0 < σ.card := Finset.card_pos.mpr hσ
      have hlt : σ.card < (Finset.univ : Finset (Fin 2)).card :=
        Finset.card_lt_card hproper
      simp only [Finset.card_fin] at hlt
      omega
    have hsingleton : ∃ v, σ = {v} := Finset.card_eq_one.mp hcard
    exact hsingleton
  · rintro ⟨v, rfl⟩
    refine ⟨Finset.singleton_nonempty v, Finset.ssubset_iff_subset_ne.mpr
      ⟨Finset.subset_univ _, ?_⟩⟩
    intro h
    have := congrArg Finset.card h
    simp at this

/-- The simplex on `V` is contained in a complex exactly when `V` is a face of the complex
whenever `V` is nonempty.  For `V = ∅` the simplex is `⊥`, so it is contained in every complex. -/
theorem simplex_le_iff : simplex V ≤ K ↔ (V.Nonempty → V ∈ K) := by
  constructor
  · exact fun h hV => h (self_mem_simplex.mpr hV)
  · intro h σ hσ
    obtain ⟨x, hx⟩ := hσ.1
    exact (K.isRelLowerSet_faces (h ⟨x, hσ.2 hx⟩)).2 hσ.2 hσ.1

/-- Simplices are ordered exactly when their spanning vertex sets are ordered. -/
theorem simplex_le_simplex_iff : simplex V ≤ simplex W ↔ V ⊆ W := by
  rw [simplex_le_iff]
  constructor
  · intro h
    rcases V.eq_empty_or_nonempty with rfl | hV
    · exact Finset.empty_subset W
    · exact (mem_simplex.mp (h hV)).2
  · exact fun h hV => mem_simplex.mpr ⟨hV, h⟩

/-- Enlarging the spanning vertex set enlarges the simplex. -/
theorem simplex_mono (h : V ⊆ W) : simplex V ≤ simplex W :=
  fun _ hσ => ⟨hσ.1, hσ.2.trans h⟩

/-- Enlarging the spanning vertex set enlarges the boundary. -/
theorem simplexBoundary_mono (h : V ⊆ W) : simplexBoundary V ≤ simplexBoundary W := by
  intro σ hσ
  refine ⟨hσ.1, ?_⟩
  exact hσ.2.trans_le h

/-- A face of a simplex lies in its boundary exactly when it is not the whole spanning set. -/
theorem mem_simplexBoundary_iff_mem_simplex_ne :
    σ ∈ simplexBoundary V ↔ σ ∈ simplex V ∧ σ ≠ V := by
  simp only [mem_simplexBoundary, mem_simplex, Finset.ssubset_iff_subset_ne]
  tauto

/-- The faces of a simplex are its boundary faces together with the spanning set itself, the
latter only when the spanning set is nonempty. -/
theorem mem_simplex_iff_mem_simplexBoundary_or_eq :
    σ ∈ simplex V ↔ σ ∈ simplexBoundary V ∨ V.Nonempty ∧ σ = V := by
  rw [mem_simplexBoundary_iff_mem_simplex_ne]
  constructor
  · intro hσ
    rcases eq_or_ne σ V with rfl | hne
    · exact Or.inr ⟨hσ.1, rfl⟩
    · exact Or.inl ⟨hσ, hne⟩
  · rintro (⟨hσ, -⟩ | ⟨hV, rfl⟩)
    · exact hσ
    · exact self_mem_simplex.mpr hV

end PreAbstractSimplicialComplex

namespace AbstractSimplicialComplex

private theorem singleton_mem_standardSuccSimplexBoundaryPrecomplex (n : ℕ) (v : Fin (n + 2)) :
    {v} ∈ (PreAbstractSimplicialComplex.simplexBoundary
      (Finset.univ : Finset (Fin (n + 2)))).faces := by
  exact PreAbstractSimplicialComplex.singleton_mem_simplexBoundary.mpr
    ⟨Finset.mem_univ v, (Finset.singleton_ne_univ v).symm⟩

/-- The boundary complex of the standard `(n + 1)`-simplex.  Its vertices are `Fin (n + 2)` and
its faces are the nonempty proper subsets of all vertices. -/
def standardSuccSimplexBoundary (n : ℕ) : AbstractSimplicialComplex (Fin (n + 2)) :=
  PreAbstractSimplicialComplex.toAbstractSimplicialComplex (Fin (n + 2))
    (PreAbstractSimplicialComplex.simplexBoundary
      (Finset.univ : Finset (Fin (n + 2))))
    (singleton_mem_standardSuccSimplexBoundaryPrecomplex n)

/-- The underlying precomplex of `standardSuccSimplexBoundary n` is the boundary of the simplex on
all `n + 2` vertices. -/
@[simp]
theorem standardSuccSimplexBoundary_toPreAbstractSimplicialComplex (n : ℕ) :
    (standardSuccSimplexBoundary n).toPreAbstractSimplicialComplex =
      PreAbstractSimplicialComplex.simplexBoundary
        (Finset.univ : Finset (Fin (n + 2))) :=
  by
    ext σ
    rfl

/-- The faces of the boundary of the standard `(n + 1)`-simplex are exactly the nonempty proper
subsets of its vertex set. -/
@[simp]
theorem mem_standardSuccSimplexBoundary_iff {n : ℕ} {σ : Finset (Fin (n + 2))} :
    σ ∈ standardSuccSimplexBoundary n ↔ σ.Nonempty ∧ σ ⊂ Finset.univ :=
  by
    rw [← mem_toPreAbstractSimplicialComplex,
      standardSuccSimplexBoundary_toPreAbstractSimplicialComplex,
      PreAbstractSimplicialComplex.mem_simplexBoundary]

end AbstractSimplicialComplex
