/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import Mathlib.Analysis.Convex.SimplicialComplex.AffineIndependentUnion
public import Mathlib.Analysis.Convex.Combination
public import Mathlib.Topology.UniformSpace.Real
public import Mathlib.Topology.UnitInterval
import Mathlib.Analysis.Convex.Topology
import Mathlib.Topology.Separation.Hausdorff
public import TauCeti.AlgebraicTopology.SimplicialComplex.Basic
import Mathlib.Geometry.Convex.ConvexSpace.Defs

/-!
# Geometric realization of an abstract simplicial complex

This file realizes an abstract simplicial complex in the real vector space of finitely supported
functions on its vertices. A vertex `v` is represented by the coordinate vector
`Finsupp.single v 1`; the realization is the union of the convex hulls of the images of the faces.
Thus points of the realization are precisely finite barycentric combinations supported on a face.

The construction uses `Geometry.SimplicialComplex.onFinsupp` from Mathlib, which proves that the
standard coordinate vectors are affinely independent and that their convex hulls intersect along
common faces. The polyhedron carries the weak topology: the final topology for the inclusions of
all its closed simplices. This avoids a finiteness or local-finiteness hypothesis on `K`.

This is the first item of layer 11 of the geometric-topology roadmap: the polyhedron `|K|` of an
abstract simplicial complex. It is the object used in the subsequent definition of a triangulation.

## Main definitions

* `AbstractSimplicialComplex.standardGeometricComplex`: the standard geometric complex of `K`.
* `AbstractSimplicialComplex.Realization`: the topological space underlying its polyhedron.
* `AbstractSimplicialComplex.faceBarycenter`: the barycenter of a face in standard coordinates.

## Main results

* `mem_standardGeometricComplex_faces_iff`: the geometric faces are exactly the coordinate images
  of the abstract faces.
* `mem_realization_iff`: a finitely supported function belongs to the polyhedron exactly when it
  lies in the convex hull of the coordinate image of some abstract face.
* `faceBarycenter_mem`: a face barycenter belongs to its closed simplex.
* `vertex`: the canonical point of the realization corresponding to a vertex.
* `realizationBotHomeomorph`: the realization of the bottom complex is its discrete vertex space.
-/

public section

noncomputable section

open Set TauCeti.SetLike

namespace AbstractSimplicialComplex

variable {ι : Type*}

attribute [local instance] Classical.decEq

/-- The standard geometric simplicial complex associated to an abstract simplicial complex.

Each vertex is sent to its coordinate vector in `ι →₀ ℝ`. This is Mathlib's
`Geometry.SimplicialComplex.onFinsupp` construction. -/
noncomputable def standardGeometricComplex (K : AbstractSimplicialComplex ι) :
    Geometry.SimplicialComplex ℝ (ι →₀ ℝ) :=
  Geometry.SimplicialComplex.onFinsupp K.toPreAbstractSimplicialComplex

/-- The carrier of the geometric realization (polyhedron) of an abstract simplicial complex. -/
noncomputable abbrev Realization (K : AbstractSimplicialComplex ι) : Type _ :=
  (standardGeometricComplex K).space

/-- The closed simplex spanned by a finite vertex set, in standard barycentric coordinates. -/
noncomputable abbrev StandardSimplex (σ : Finset ι) : Type _ :=
  convexHull ℝ (σ.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ))

/-- The barycenter of a nonempty face, expressed in the standard barycentric coordinates of the
realization. -/
noncomputable def faceBarycenter (K : AbstractSimplicialComplex ι) (σ : Face K) : ι →₀ ℝ :=
  (σ.1.image fun v => Finsupp.single v (1 : ℝ)).centroid ℝ id

/-- The barycenter of a face belongs to the closed simplex spanned by that face. -/
theorem faceBarycenter_mem (K : AbstractSimplicialComplex ι) (σ : Face K) :
    faceBarycenter K σ ∈
      convexHull ℝ (σ.1.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ)) := by
  apply Finset.centroid_mem_convexHull
  exact (K.isRelLowerSet_faces.prop_of_mem σ.2).image _

/-- The barycenter of a face has equal coordinates on its vertices and vanishes elsewhere. -/
@[simp]
theorem faceBarycenter_apply (K : AbstractSimplicialComplex ι) (σ : Face K) (v : ι) :
    faceBarycenter K σ v = if v ∈ σ.1 then (σ.1.card : ℝ)⁻¹ else 0 := by
  have hinj : Function.Injective (fun w : ι => Finsupp.single w (1 : ℝ)) :=
    Finsupp.single_left_injective (M := ℝ) one_ne_zero
  have hne := (K.isRelLowerSet_faces.prop_of_mem σ.2).image
    (fun w => Finsupp.single w (1 : ℝ))
  have hweights : ∑ y ∈ σ.1.image (fun w => Finsupp.single w (1 : ℝ)),
      (σ.1.image fun w => Finsupp.single w (1 : ℝ)).centroidWeights ℝ y = 1 :=
    Finset.sum_centroidWeights_eq_one_of_nonempty ℝ _ hne
  rw [faceBarycenter, Finset.centroid_eq_centerMass _ hne,
    (σ.1.image fun w => Finsupp.single w (1 : ℝ)).centerMass_eq_of_sum_1 _ hweights,
    Finset.sum_apply']
  simp only [Finset.centroidWeights_apply, id_eq, Finsupp.smul_apply, smul_eq_mul]
  rw [Finset.card_image_of_injOn hinj.injOn, Finset.sum_image hinj.injOn]
  simp [Finsupp.single_apply]

/-- The topology induced by the coordinatewise topology on `ι → ℝ`. These are the domain
topologies used to define the weak topology on the whole realization. -/
instance (σ : Finset ι) : TopologicalSpace (StandardSimplex σ) :=
  TopologicalSpace.induced (fun x : StandardSimplex σ => (x.1 : ι → ℝ)) inferInstance

/-- Closed coordinate simplices are Hausdorff, including on an infinite vertex type. -/
instance instT2SpaceStandardSimplex (σ : Finset ι) : T2Space (StandardSimplex σ) :=
  (Topology.IsEmbedding.induced
    (fun _ _ h => Subtype.ext (Finsupp.ext fun v => congrFun h v))).t2Space

/-- Every closed coordinate simplex is compact, even in an infinite vertex set. -/
instance instCompactSpaceStandardSimplex (σ : Finset ι) : CompactSpace (StandardSimplex σ) := by
  let c := Finsupp.lcoeFun (R := ℝ) (α := ι) (M := ℝ)
  have hc : IsCompact
      (c '' convexHull ℝ (σ.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ))) := by
    rw [c.image_convexHull]
    exact ((σ.image (fun v => Finsupp.single v (1 : ℝ))).finite_toSet.image c).isCompact_convexHull
      ℝ
  have hind : Topology.IsInducing (fun x : StandardSimplex σ => (x.1 : ι → ℝ)) :=
    Topology.IsInducing.induced _
  have hr : range (fun x : StandardSimplex σ => (x.1 : ι → ℝ)) =
      c '' convexHull ℝ (σ.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ)) := by
    have hcoe : (fun x : StandardSimplex σ => (x.1 : ι → ℝ)) = ⇑c ∘ Subtype.val :=
      funext fun x => by simp [c]
    rw [hcoe]
    exact (range_comp c Subtype.val).trans (congrArg (fun s => c '' s) Subtype.range_coe)
  refine ⟨hind.isCompact_iff.mpr ?_⟩
  rw [image_univ, hr]
  exact hc

/-- A geometric face is exactly the image of an abstract face under the coordinate embedding. -/
theorem mem_standardGeometricComplex_faces_iff (K : AbstractSimplicialComplex ι)
    (τ : Finset (ι →₀ ℝ)) :
    τ ∈ (standardGeometricComplex K).faces ↔
      ∃ σ ∈ K, σ.image (fun v => Finsupp.single v (1 : ℝ)) = τ := by
  classical
  simp only [standardGeometricComplex, Geometry.SimplicialComplex.onFinsupp,
    Geometry.SimplicialComplex.ofAffineIndependent, PreAbstractSimplicialComplex.map,
    Set.mem_image]
  aesop

/-- Include the realization of a face into the whole polyhedron. -/
noncomputable def faceInclusion (K : AbstractSimplicialComplex ι) (σ : Face K) :
    StandardSimplex σ.1 → Realization K :=
  Set.inclusion (Geometry.SimplicialComplex.convexHull_subset_space
    (K := standardGeometricComplex K)
      ((mem_standardGeometricComplex_faces_iff K _).2 ⟨σ.1, σ.2, rfl⟩))

/-- A face inclusion does not change the underlying barycentric coordinates. -/
@[simp]
theorem faceInclusion_val (K : AbstractSimplicialComplex ι) (σ : Face K) (x : StandardSimplex σ.1) :
    (faceInclusion K σ x : ι →₀ ℝ) = x := by
  exact Set.coe_inclusion
    (Geometry.SimplicialComplex.convexHull_subset_space
      ((mem_standardGeometricComplex_faces_iff K _).2 ⟨σ.1, σ.2, rfl⟩)) x

/-- The weak topology on a realization, final with respect to all face inclusions. -/
instance (K : AbstractSimplicialComplex ι) : TopologicalSpace (Realization K) :=
  ⨆ σ : Face K, TopologicalSpace.coinduced (faceInclusion K σ) inferInstance

/-- Every face inclusion is continuous for the weak topology on the realization. -/
theorem continuous_faceInclusion (K : AbstractSimplicialComplex ι) (σ : Face K) :
    Continuous (faceInclusion K σ) :=
  continuous_iff_coinduced_le.2 (le_iSup (fun τ : Face K =>
    TopologicalSpace.coinduced (faceInclusion K τ) inferInstance) σ)

/-- A subset of a weak realization is closed exactly when its inverse image in every closed
simplex is closed. -/
theorem isClosed_iff_faceInclusion {K : AbstractSimplicialComplex ι} {s : Set (Realization K)} :
    IsClosed s ↔ ∀ σ : Face K, IsClosed (faceInclusion K σ ⁻¹' s) := by
  -- The realization topology is the supremum of the coinduced face topologies.
  simp only [isClosed_iSup_iff, isClosed_coinduced]

/-- A map out of a realization is continuous exactly when its restriction to every face is
continuous. -/
theorem continuous_iff_faceInclusion {K : AbstractSimplicialComplex ι}
    {X : Type*} [TopologicalSpace X] {f : Realization K → X} :
    Continuous f ↔ ∀ σ : Face K, Continuous (f ∘ faceInclusion K σ) := by
  rw [continuous_iSup_dom]
  exact forall_congr' fun _ => continuous_coinduced_dom

/-- Barycentric coordinates are continuous for the weak topology, for any vertex type. -/
theorem continuous_realization_coe (K : AbstractSimplicialComplex ι) :
    Continuous (fun x : Realization K => (x.1 : ι → ℝ)) := by
  apply continuous_iff_faceInclusion.mpr
  intro σ
  exact continuous_induced_dom.congr fun x => by
    exact congrArg (fun y : ι →₀ ℝ => (y : ι → ℝ)) (faceInclusion_val K σ x).symm

/-- Distinct realization points have distinct barycentric coordinates. -/
theorem injective_realization_coe (K : AbstractSimplicialComplex ι) :
    Function.Injective (fun x : Realization K => (x.1 : ι → ℝ)) :=
  fun _ _ h => Subtype.ext (Finsupp.ext fun v => congrFun h v)

/-- The weak realization is Hausdorff: distinct points have distinct continuous
barycentric coordinates. -/
instance instT2SpaceRealization (K : AbstractSimplicialComplex ι) : T2Space (Realization K) :=
  T2Space.of_injective_continuous
    (injective_realization_coe K) (continuous_realization_coe K)

/-- The coordinate image of every abstract face is a face of the geometric complex. -/
theorem image_single_mem_standardGeometricComplex_faces {K : AbstractSimplicialComplex ι}
    {σ : Finset ι} (hσ : σ ∈ K) :
    σ.image (fun v => Finsupp.single v (1 : ℝ)) ∈ (standardGeometricComplex K).faces :=
  (mem_standardGeometricComplex_faces_iff K _).2 ⟨σ, hσ, rfl⟩

/-- A point belongs to the standard polyhedron exactly when it lies in the convex hull of the
coordinate image of some abstract face. -/
theorem mem_realization_iff {K : AbstractSimplicialComplex ι} {x : ι →₀ ℝ} :
    x ∈ (standardGeometricComplex K).space ↔
      ∃ σ ∈ K, x ∈
        convexHull ℝ (σ.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ)) := by
  rw [Geometry.SimplicialComplex.mem_space_iff]
  constructor
  · rintro ⟨τ, hτ, hx⟩
    obtain ⟨σ, hσ, rfl⟩ := (mem_standardGeometricComplex_faces_iff K τ).1 hτ
    exact ⟨σ, hσ, hx⟩
  · rintro ⟨σ, hσ, hx⟩
    exact ⟨σ.image (fun v => Finsupp.single v (1 : ℝ)),
      image_single_mem_standardGeometricComplex_faces hσ, hx⟩

/-- Barycentric coordinates in a standard simplex are nonnegative. -/
theorem StandardSimplex.nonneg {σ : Finset ι} (x : StandardSimplex σ) (v : ι) :
    0 ≤ x.1 v := by
  -- View the coordinate inequality as membership in a convex half-space.
  change x.1 ∈ {y : ι →₀ ℝ | 0 ≤ y v}
  exact convexHull_min (by
      intro y hy
      simp only [Finset.coe_image, Set.mem_image] at hy
      obtain ⟨w, _, rfl⟩ := hy
      by_cases h : w = v <;> simp [h])
    (by
      intro y hy z hz a b ha hb _
      simp only [Set.mem_ofPred_eq, Finsupp.add_apply, Finsupp.smul_apply] at hy hz ⊢
      exact add_nonneg (mul_nonneg ha hy) (mul_nonneg hb hz))
    x.2

/-- The barycentric coordinates in a standard simplex sum to one. -/
theorem StandardSimplex.sum_eq_one {σ : Finset ι} (x : StandardSimplex σ) :
    x.1.sum (fun _ r => r) = 1 := by
  -- Use the linear-map form of coordinate summation required by the convexity API.
  change x.1.sum (fun _ => LinearMap.id (R := ℝ) (M := ℝ)) = 1
  change x.1 ∈
    {y : ι →₀ ℝ | y.sum (fun _ => LinearMap.id (R := ℝ) (M := ℝ)) = 1}
  exact convexHull_min (by
      intro y hy
      simp only [Finset.coe_image, Set.mem_image] at hy
      obtain ⟨v, _, rfl⟩ := hy
      simp)
    (by
      intro y hy z hz a b _ _ hab
      simp only [Set.mem_ofPred_eq] at hy hz ⊢
      rw [Finsupp.sum_add_index]
      · rw [Finsupp.sum_smul_index_linearMap', Finsupp.sum_smul_index_linearMap', hy, hz]
        simpa [smul_eq_mul] using hab
      all_goals simp)
    x.2

/-- The support of a point in a standard simplex is contained in its vertex set. -/
theorem StandardSimplex.support_subset {σ : Finset ι} (x : StandardSimplex σ) :
    x.1.support ⊆ σ := by
  -- Express support containment as membership in the standard supported submodule.
  change (x.1.support : Set ι) ⊆ (σ : Set ι)
  change x.1 ∈ Finsupp.supported ℝ ℝ (σ : Set ι)
  exact convexHull_min (by
    intro y hy
    simp only [Finset.coe_image, Set.mem_image] at hy
    obtain ⟨v, hv, rfl⟩ := hy
    simpa [Finsupp.mem_supported] using hv) (Finsupp.supported ℝ ℝ (σ : Set ι)).convex x.2

/-- Membership in a standard simplex in terms of barycentric coordinates. -/
@[simp]
theorem mem_standardSimplex_iff {σ : Finset ι} {x : ι →₀ ℝ} :
    x ∈ convexHull ℝ
        ((fun v => Finsupp.single v (1 : ℝ)) '' (σ : Set ι)) ↔
      (∀ v, 0 ≤ x v) ∧ x.sum (fun _ r => r) = 1 ∧ x.support ⊆ σ := by
  constructor
  · intro hx
    rw [← Finset.coe_image] at hx
    let x' : StandardSimplex σ := ⟨x, hx⟩
    exact ⟨StandardSimplex.nonneg x', StandardSimplex.sum_eq_one x',
      StandardSimplex.support_subset x'⟩
  · rintro ⟨hnonneg, hsum, hsupp⟩
    have hsum' :
        x.sum (fun _ => LinearMap.id (R := ℝ) (M := ℝ)) = 1 := by
      -- Put the coordinate-sum hypothesis in the linear-map form required by `Convex.sum_mem`.
      change x.sum (fun _ r => r) = 1
      exact hsum
    have hx := (convex_convexHull ℝ
        (σ.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ))).sum_mem
      (fun v _ => hnonneg v) hsum'
      (fun v hv => subset_convexHull ℝ _ (Finset.mem_coe.2 <|
        Finset.mem_image.2 ⟨v, hsupp hv, rfl⟩))
    have heq : (∑ i ∈ x.support, x i • Finsupp.single i (1 : ℝ)) = x := by
      simpa [Finsupp.sum] using x.sum_single
    rw [heq] at hx
    rw [Finset.coe_image] at hx
    exact hx

/-- A point of a standard simplex lies in the simplex spanned by its support. -/
theorem StandardSimplex.mem_convexHull_support {σ : Finset ι} (x : StandardSimplex σ) :
    x.1 ∈ convexHull ℝ
      (x.1.support.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ)) := by
  have hx := (convex_convexHull ℝ _).sum_mem
    (fun v _ => StandardSimplex.nonneg x v)
    (by
      -- Return from the linear-map form expected by `Convex.sum_mem` to scalar summation.
      change x.1.sum (fun _ r => r) = 1
      exact StandardSimplex.sum_eq_one x)
    (fun v hv => subset_convexHull ℝ _ (by
      -- Re-express set membership in the finite image so `Finset.mem_image` applies.
      change Finsupp.single v 1 ∈
        (x.1.support.image (fun w => Finsupp.single w (1 : ℝ)) : Finset (ι →₀ ℝ))
      exact Finset.mem_image.2 ⟨v, hv, rfl⟩))
  have heq : (∑ i ∈ x.1.support, x.1 i • Finsupp.single i (1 : ℝ)) = x.1 := by
    simpa [Finsupp.sum] using x.1.sum_single
  rw [heq] at hx
  exact hx

/-- Moving a point of a closed simplex towards a vertex stays in the enlarged simplex. -/
theorem StandardSimplex.smul_add_single_mem [DecidableEq ι] {σ : Finset ι} (x : StandardSimplex σ)
    (v : ι) (t : unitInterval) :
    (1 - (t : ℝ)) • x.1 + (t : ℝ) • Finsupp.single v 1 ∈
      convexHull ℝ ((insert v σ).image (fun w => Finsupp.single w (1 : ℝ)) :
        Set (ι →₀ ℝ)) := by
  apply (convex_convexHull ℝ _)
  · exact convexHull_mono (Finset.coe_subset.mpr
      (Finset.image_mono _ (Finset.subset_insert v σ))) (by
        -- Set images remove the equality-instance choice in the finite image of `σ`.
        simpa only [Finset.coe_image] using x.2)
  · exact subset_convexHull ℝ _ (Finset.mem_coe.mpr
      (Finset.mem_image.mpr ⟨v, Finset.mem_insert_self v σ, rfl⟩))
  · exact sub_nonneg.mpr t.2.2
  · exact t.2.1
  · ring

/-- The support of a realization point is an abstract face. -/
theorem support_mem (K : AbstractSimplicialComplex ι) (x : Realization K) : x.1.support ∈ K := by
  obtain ⟨σ, hσ, hx⟩ := mem_realization_iff.1 x.2
  let hx' : StandardSimplex σ := ⟨x.1, hx⟩
  have hs : x.1.support ⊆ σ := by
    simpa [hx'] using StandardSimplex.support_subset hx'
  apply K.isRelLowerSet_faces.mem_of_le hσ
    hs
  exact
    (Finsupp.support_nonempty_iff.mpr <| by
      intro h
      have hs := StandardSimplex.sum_eq_one hx'
      have hs' : x.1.sum (fun _ r => r) = 1 := by
        simpa [hx'] using hs
      rw [h] at hs'
      simp at hs')

/-- The minimal abstract face carrying a point of the realization. -/
noncomputable def carrier (K : AbstractSimplicialComplex ι) (x : Realization K) : Face K :=
  ⟨x.1.support, support_mem K x⟩

/-- The vertices of the carrier are exactly the nonzero barycentric coordinates. -/
@[simp]
theorem carrier_val (K : AbstractSimplicialComplex ι) (x : Realization K) :
    (carrier K x).1 = x.1.support :=
  (rfl)

/-- A realization point belongs to the closed simplex spanned by its carrier. -/
theorem mem_convexHull_carrier (K : AbstractSimplicialComplex ι) (x : Realization K) :
    x.1 ∈ convexHull ℝ
      ((carrier K x).1.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ)) := by
  obtain ⟨σ, _, hx⟩ := mem_realization_iff.1 x.2
  rw [carrier_val]
  exact StandardSimplex.mem_convexHull_support ⟨x.1, hx⟩

/-- The barycentric coordinates of a point of the realization are nonnegative. -/
theorem Realization.nonneg (K : AbstractSimplicialComplex ι) (x : Realization K) (v : ι) :
    0 ≤ x.1 v :=
  StandardSimplex.nonneg (σ := (carrier K x).1) ⟨x.1, mem_convexHull_carrier K x⟩ v

/-- The barycentric coordinates of a realization point sum to one. -/
@[simp]
theorem Realization.sum_eq_one (K : AbstractSimplicialComplex ι) (x : Realization K) :
    x.1.sum (fun _ r => r) = 1 :=
  StandardSimplex.sum_eq_one ⟨x.1, mem_convexHull_carrier K x⟩

/-- Every barycentric coordinate of a realization point is at most one. -/
theorem Realization.le_one (K : AbstractSimplicialComplex ι) (x : Realization K) (v : ι) :
    x.1 v ≤ 1 :=
  Convexity.StdSimplex.weights_apply_le_one
    ⟨x.1, Realization.nonneg K x, Realization.sum_eq_one K x⟩ v

/-- The carrier is contained in every finite vertex set whose closed simplex contains the point. -/
theorem carrier_minimal (K : AbstractSimplicialComplex ι) (x : Realization K) {σ : Finset ι}
    (hx : x.1 ∈ convexHull ℝ (σ.image (fun v => Finsupp.single v (1 : ℝ)) : Set (ι →₀ ℝ))) :
    (carrier K x).1 ⊆ σ :=
  by
    rw [carrier_val]
    exact StandardSimplex.support_subset ⟨x.1, hx⟩

/-- The standard coordinate vector of every vertex belongs to the geometric realization. -/
theorem single_mem_standardGeometricComplex_space (K : AbstractSimplicialComplex ι) (v : ι) :
    Finsupp.single v 1 ∈ (standardGeometricComplex K).space := by
  apply Geometry.SimplicialComplex.vertices_subset_space
  rw [Geometry.SimplicialComplex.mem_vertices]
  simpa using image_single_mem_standardGeometricComplex_faces (K.singleton_mem v)

/-- The canonical point of the geometric realization corresponding to a vertex. -/
noncomputable def vertex (K : AbstractSimplicialComplex ι) (v : ι) : Realization K :=
  ⟨Finsupp.single v 1, single_mem_standardGeometricComplex_space K v⟩

/-- The underlying finitely supported function of a realization vertex is its coordinate vector. -/
@[simp]
theorem vertex_val (K : AbstractSimplicialComplex ι) (v : ι) :
    (vertex K v : ι →₀ ℝ) = Finsupp.single v 1 :=
  (rfl)

/-- The barycentric support of a realization vertex is its singleton vertex set. -/
-- Simplify the support before vertex_val rewrites the vertex's coordinates.
@[simp↓]
theorem support_vertex (K : AbstractSimplicialComplex ι) (v : ι) :
    (vertex K v : ι →₀ ℝ).support = {v} := by
  rw [vertex_val, Finsupp.support_single _ one_ne_zero]

/-- A realization point is a vertex exactly when its coordinate at that vertex is one. -/
@[simp]
theorem Realization.eq_vertex_iff (K : AbstractSimplicialComplex ι) (x : Realization K) (v : ι) :
    x = vertex K v ↔ x.1 v = 1 := by
  constructor
  · rintro rfl
    simp
  · intro hv
    have hsum := Finsupp.add_sum_erase' x.1 v (fun _ r => r) (fun _ => rfl)
    rw [Realization.sum_eq_one, hv] at hsum
    have he : (x.1.erase v).sum (fun _ r => r) = 0 := by linarith
    have hzero : ∀ w ∈ (x.1.erase v).support, (x.1.erase v) w = 0 := by
      apply (Finset.sum_eq_zero_iff_of_nonneg ?_).mp he
      intro w _
      by_cases h : w = v
      · simp [h]
      · simpa [Finsupp.erase_ne h] using Realization.nonneg K x w
    apply Subtype.ext
    rw [vertex_val, Finsupp.eq_single_iff]
    refine ⟨?_, hv⟩
    intro w hw
    by_contra h
    have hw' : w ∈ (x.1.erase v).support := by
      simp only [Finsupp.support_erase, Finset.mem_erase]
      exact ⟨by simpa only [Finset.mem_singleton] using h, hw⟩
    exact (Finsupp.mem_support_iff.mp hw') (hzero w hw')

/-- A realization point supported on a singleton is the corresponding vertex. -/
theorem Realization.eq_vertex_of_support_eq (K : AbstractSimplicialComplex ι)
    (x : Realization K) {v : ι} (h : x.1.support = {v}) : x = vertex K v := by
  apply Subtype.ext
  rw [vertex_val]
  let w : Convexity.StdSimplex ℝ ι :=
    ⟨x.1, Realization.nonneg K x, Realization.sum_eq_one K x⟩
  exact congrArg Convexity.StdSimplex.weights
    ((Convexity.StdSimplex.support_weights_eq_singleton (w := w)).mp h)

/-- Distinct vertices give distinct points in the geometric realization. -/
theorem vertex_injective (K : AbstractSimplicialComplex ι) :
    Function.Injective (vertex K) := by
  intro v w h
  have hvw : Finsupp.single v (1 : ℝ) = Finsupp.single w 1 := congrArg Subtype.val h
  classical
  exact Finsupp.single_left_injective (M := ℝ) one_ne_zero hvw

/-- The canonical map from vertices to the realization. -/
noncomputable def vertexEmbedding (K : AbstractSimplicialComplex ι) : ι ↪ Realization K :=
  ⟨vertex K, vertex_injective K⟩

/-- The vertex embedding sends a vertex to its canonical point in the realization. -/
@[simp]
theorem vertexEmbedding_apply (K : AbstractSimplicialComplex ι) (v : ι) :
    vertexEmbedding K v = vertex K v := by
  simp [vertexEmbedding]

/-- The vertices exhaust the realization of the bottom abstract simplicial complex. -/
theorem vertex_bot_surjective :
    Function.Surjective (vertex (⊥ : AbstractSimplicialComplex ι)) := by
  classical
  intro x
  obtain ⟨v, hv⟩ := (carrier (⊥ : AbstractSimplicialComplex ι) x).2
  refine ⟨v, Subtype.ext ?_⟩
  have hx := mem_convexHull_carrier (⊥ : AbstractSimplicialComplex ι) x
  have hx' : x.1 = Finsupp.single v 1 := by
    simpa only [hv, Finset.image_singleton, Finset.coe_singleton, convexHull_singleton,
      mem_singleton_iff] using hx
  rw [vertex_val]
  exact hx'.symm

/-- The weak topology on the realization of the bottom abstract simplicial complex is discrete. -/
instance realizationBotDiscreteTopology :
    DiscreteTopology (Realization (⊥ : AbstractSimplicialComplex ι)) := by
  classical
  rw [discreteTopology_iff_forall_isOpen]
  intro s
  rw [isOpen_iSup_iff]
  intro σ
  rw [isOpen_coinduced]
  obtain ⟨v, hv⟩ := σ.2
  have : Subsingleton (StandardSimplex σ.1) := by
    constructor
    intro x y
    apply Subtype.ext
    have hx : x.1 = Finsupp.single v 1 := by
      simpa only [hv, Finset.image_singleton, Finset.coe_singleton, convexHull_singleton,
        mem_singleton_iff] using x.2
    have hy : y.1 = Finsupp.single v 1 := by
      simpa only [hv, Finset.image_singleton, Finset.coe_singleton, convexHull_singleton,
        mem_singleton_iff] using y.2
    exact hx.trans hy.symm
  exact isOpen_discrete _

private noncomputable def vertexEquivBot :
    ι ≃ Realization (⊥ : AbstractSimplicialComplex ι) :=
  Equiv.ofBijective (vertex (⊥ : AbstractSimplicialComplex ι))
    ⟨vertex_injective _, vertex_bot_surjective⟩

/-- The realization of the bottom abstract simplicial complex is canonically homeomorphic to its
vertex type equipped with a discrete topology. -/
noncomputable def realizationBotHomeomorph [TopologicalSpace ι] [DiscreteTopology ι] :
    Realization (⊥ : AbstractSimplicialComplex ι) ≃ₜ ι :=
  (Homeomorph.ofDiscrete vertexEquivBot).symm

/-- Under the canonical homeomorphism for the bottom complex, the inverse sends a vertex to its
standard barycentric point. -/
@[simp]
theorem realizationBotHomeomorph_symm_apply [TopologicalSpace ι] [DiscreteTopology ι] (v : ι) :
    (realizationBotHomeomorph (ι := ι)).symm v =
      vertex (⊥ : AbstractSimplicialComplex ι) v :=
  by
    rw [realizationBotHomeomorph, Homeomorph.symm_symm]
    calc
      (Homeomorph.ofDiscrete vertexEquivBot) v = vertexEquivBot v := rfl
      _ = vertex (⊥ : AbstractSimplicialComplex ι) v :=
        Equiv.ofBijective_apply _ ⟨vertex_injective _, vertex_bot_surjective⟩ v

/-- The canonical homeomorphism sends the barycentric point of a vertex back to that vertex. -/
@[simp]
theorem realizationBotHomeomorph_apply_vertex [TopologicalSpace ι] [DiscreteTopology ι] (v : ι) :
    realizationBotHomeomorph (vertex (⊥ : AbstractSimplicialComplex ι) v) = v := by
  rw [← realizationBotHomeomorph_symm_apply]
  exact Homeomorph.apply_symm_apply _ _

/-- Inclusion of abstract complexes induces inclusion of their standard polyhedra. -/
theorem standardGeometricComplex_space_mono {K L : AbstractSimplicialComplex ι} (hKL : K ≤ L) :
    (standardGeometricComplex K).space ⊆ (standardGeometricComplex L).space := by
  intro x hx
  rw [mem_realization_iff] at hx ⊢
  obtain ⟨σ, hσ, hx⟩ := hx
  exact ⟨σ, hKL hσ, hx⟩

/-- The continuous map of realizations induced by an inclusion of abstract complexes. -/
noncomputable def realizationMap {K L : AbstractSimplicialComplex ι} (hKL : K ≤ L) :
    Realization K → Realization L :=
  Set.inclusion (standardGeometricComplex_space_mono hKL)

/-- An induced map of realizations does not change the underlying barycentric coordinates. -/
@[simp]
theorem realizationMap_val {K L : AbstractSimplicialComplex ι} (hKL : K ≤ L) (x : Realization K) :
    (realizationMap hKL x : ι →₀ ℝ) = x := by
  exact Set.coe_inclusion (standardGeometricComplex_space_mono hKL) x

/-- The map of realizations induced by an inclusion is injective. -/
theorem realizationMap_injective {K L : AbstractSimplicialComplex ι} (hKL : K ≤ L) :
    Function.Injective (realizationMap hKL) :=
  Set.inclusion_injective (standardGeometricComplex_space_mono hKL)

/-- An inclusion map restricted to a face is the corresponding face inclusion in the larger
complex. -/
@[simp]
theorem realizationMap_comp_faceInclusion {K L : AbstractSimplicialComplex ι} (hKL : K ≤ L)
    (σ : Face K) :
    realizationMap hKL ∘ faceInclusion K σ = faceInclusion L ⟨σ.1, hKL σ.2⟩ := by
  funext x
  exact Subtype.ext rfl

/-- The map of realizations induced by an inclusion is continuous. -/
theorem continuous_realizationMap {K L : AbstractSimplicialComplex ι} (hKL : K ≤ L) :
    Continuous (realizationMap hKL) := by
  apply continuous_iff_faceInclusion.2
  intro σ
  rw [realizationMap_comp_faceInclusion]
  exact continuous_faceInclusion L ⟨σ.1, hKL σ.2⟩

/-- The map induced by the reflexive inclusion is the identity. -/
@[simp]
theorem realizationMap_refl (K : AbstractSimplicialComplex ι) :
    realizationMap (le_refl K) = id :=
  Set.inclusion_eq_id (standardGeometricComplex_space_mono (le_refl K))

/-- Maps induced by inclusions compose according to transitivity of inclusion. -/
theorem realizationMap_trans {K L M : AbstractSimplicialComplex ι} (hKL : K ≤ L) (hLM : L ≤ M) :
    realizationMap (hKL.trans hLM) = realizationMap hLM ∘ realizationMap hKL := by
  exact (Set.inclusion_comp_inclusion (standardGeometricComplex_space_mono hKL)
    (standardGeometricComplex_space_mono hLM)).symm

end AbstractSimplicialComplex
