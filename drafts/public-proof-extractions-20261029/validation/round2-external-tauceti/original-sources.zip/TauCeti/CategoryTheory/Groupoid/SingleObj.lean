/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import Mathlib.CategoryTheory.Groupoid
public import Mathlib.CategoryTheory.SingleObj

/-!
# A connected groupoid is equivalent to its vertex group

Let `C` be a groupoid and `x₀ : C` a *weakly initial* object, that is, one which admits a morphism
to every object. This file proves that the one-object category `SingleObj (End x₀)` of the vertex
group at `x₀` is equivalent to `C`, through the functor sending the unique object to `x₀` and an
endomorphism to itself.

Both halves are immediate once the functor is written down. It is fully faithful in any category,
because its action on the single hom-set is the identity of `End x₀`, and it is essentially
surjective because in a groupoid a morphism `x₀ ⟶ x` is already an isomorphism. What the
equivalence buys is a dictionary: functors out of `C` become functors out of `SingleObj (End x₀)`,
that is, objects with an action of the vertex group, and the dictionary is natural in the target
category; `TauCeti.Groupoid.natIsoOfEnd` in `TauCeti.CategoryTheory.Groupoid.ConnectedFunctor` is
that dictionary applied to isomorphisms.

The weak initiality hypothesis is stated as the family of nonemptiness assertions
`∀ x, Nonempty (x₀ ⟶ x)` rather than through `CategoryTheory.IsConnected`: the intended source of
that data is a path-connected topological space, whose fundamental groupoid comes with paths out
of a chosen basepoint.

For a monoid `M`, a functor from such a groupoid to `SingleObj M` is determined by its values on
the morphisms out of `x₀` (`TauCeti.Groupoid.functor_singleObj_ext_of_map_eq`).

## Main declarations

* `TauCeti.Groupoid.singleObjFunctor`: the functor `SingleObj (End x₀) ⥤ C` picking out `x₀`.
* `TauCeti.Groupoid.fullyFaithfulSingleObjFunctor`: it is fully faithful, without hypotheses.
* `TauCeti.Groupoid.essSurj_singleObjFunctor` and
  `TauCeti.Groupoid.isEquivalence_singleObjFunctor`: it is essentially surjective, hence an
  equivalence, when `x₀` admits a morphism to every object.
* `TauCeti.Groupoid.singleObjEquivalence`: **a connected groupoid is equivalent to the
  one-object category of its vertex group.**
* `TauCeti.Groupoid.functorOfEndHom`: the functor to `SingleObj G` induced by a homomorphism
  `End x₀ →* G` and a choice of morphisms out of `x₀`.
* `TauCeti.Groupoid.functor_singleObj_ext_of_map_eq`: functors from a connected groupoid to
  `SingleObj M` are determined by their values on the morphisms out of one object.
-/

public section

universe v u

open CategoryTheory

namespace TauCeti.Groupoid

section Category

variable {C : Type u} [Category.{v} C] (x₀ : C)

/-- The functor from the one-object category of the vertex group at `x₀` that sends the unique
object to `x₀` and an endomorphism to itself.

It is `@[expose]`d so that the object and morphism equations hold by `rfl` downstream. -/
@[expose] def singleObjFunctor : SingleObj (End x₀) ⥤ C :=
  SingleObj.functor (MonoidHom.id (End x₀))

@[simp]
theorem singleObjFunctor_obj (a : SingleObj (End x₀)) : (singleObjFunctor x₀).obj a = x₀ :=
  (rfl)

@[simp]
theorem singleObjFunctor_map (g : End x₀) :
    (singleObjFunctor x₀).map (X := SingleObj.star (End x₀)) (Y := SingleObj.star (End x₀)) g =
      g.asHom :=
  (rfl)

/-- The functor out of the one-object category of the vertex group is fully faithful: on the
single hom-set it is the identity of `End x₀`. -/
def fullyFaithfulSingleObjFunctor : (singleObjFunctor x₀).FullyFaithful where
  preimage f := .of f

instance singleObjFunctor_full : (singleObjFunctor x₀).Full :=
  (fullyFaithfulSingleObjFunctor x₀).full

instance singleObjFunctor_faithful : (singleObjFunctor x₀).Faithful :=
  (fullyFaithfulSingleObjFunctor x₀).faithful

end Category

section Groupoid

variable {C : Type u} [CategoryTheory.Groupoid.{v} C] (x₀ : C)

/-- If `x₀` admits a morphism to every object of the groupoid, then every object is isomorphic to
`x₀`, so the functor out of the one-object category is essentially surjective. -/
theorem essSurj_singleObjFunctor (hconn : ∀ x : C, Nonempty (x₀ ⟶ x)) :
    (singleObjFunctor x₀).EssSurj where
  mem_essImage x :=
    ⟨SingleObj.star (End x₀),
      ⟨(CategoryTheory.Groupoid.isoEquivHom x₀ x).symm (hconn x).some⟩⟩

/-- If `x₀` admits a morphism to every object of the groupoid, the functor out of the one-object
category of the vertex group is an equivalence. -/
theorem isEquivalence_singleObjFunctor (hconn : ∀ x : C, Nonempty (x₀ ⟶ x)) :
    (singleObjFunctor x₀).IsEquivalence :=
  haveI := essSurj_singleObjFunctor x₀ hconn
  { }

/-- **A connected groupoid is equivalent to the one-object category of its vertex group.**

The equivalence is induced by `TauCeti.Groupoid.singleObjFunctor`, so it sends the unique object
to `x₀` and an endomorphism to itself. -/
noncomputable def singleObjEquivalence (hconn : ∀ x : C, Nonempty (x₀ ⟶ x)) :
    SingleObj (End x₀) ≌ C :=
  haveI := isEquivalence_singleObjFunctor x₀ hconn
  (singleObjFunctor x₀).asEquivalence

@[simp]
theorem singleObjEquivalence_functor (hconn : ∀ x : C, Nonempty (x₀ ⟶ x)) :
    (singleObjEquivalence x₀ hconn).functor = singleObjFunctor x₀ :=
  (rfl)

/-- A monoid homomorphism `f` out of the vertex group at `x₀`, together with a choice of morphisms
`τ y : x₀ ⟶ y` for every object `y`, induces a functor from the whole groupoid to `SingleObj G`: a
morphism `g : y ⟶ z` is sent to the image under `f` of the loop `τ y ≫ g ≫ inv (τ z)` at `x₀`. -/
noncomputable def functorOfEndHom (τ : ∀ y : C, x₀ ⟶ y) {G : Type*} [Monoid G]
    (f : End x₀ →* G) : C ⥤ SingleObj G where
  obj _ := SingleObj.star G
  map {y z} g := f (.of (τ y ≫ g ≫ inv (τ z)))
  map_id y := by
    rw [Category.id_comp, IsIso.hom_inv_id, SingleObj.id_as_one]
    exact map_one f
  map_comp {y z w} g h := by
    rw [SingleObj.comp_as_mul, ← map_mul]
    congr 1
    ext
    simp

@[simp]
theorem functorOfEndHom_obj (τ : ∀ y : C, x₀ ⟶ y) {G : Type*} [Monoid G] (f : End x₀ →* G)
    (y : C) : (functorOfEndHom x₀ τ f).obj y = SingleObj.star G :=
  (rfl)

@[simp]
theorem functorOfEndHom_map (τ : ∀ y : C, x₀ ⟶ y) {G : Type*} [Monoid G] (f : End x₀ →* G)
    {y z : C} (g : y ⟶ z) : (functorOfEndHom x₀ τ f).map g = f (.of (τ y ≫ g ≫ inv (τ z))) :=
  (rfl)

end Groupoid

section Ext

variable {M : Type*} [Monoid M]

/-- In a groupoid, two functors to the one-object category of a monoid are equal once they agree
on every morphism out of an object `x₀` which admits a morphism to every object. -/
theorem functor_singleObj_ext_of_map_eq {C : Type u} [CategoryTheory.Groupoid.{v} C] (x₀ : C)
    (hconn : ∀ x : C, Nonempty (x₀ ⟶ x)) {F F' : C ⥤ SingleObj M}
    (h : ∀ (x : C) (f : x₀ ⟶ x), F.map f = F'.map f) : F = F' := by
  refine CategoryTheory.Functor.ext (fun _ ↦ rfl) fun a b f ↦ ?_
  -- The object components agree by `rfl`, so the coherence morphisms are identities.
  simp only [eqToHom_refl, Category.id_comp, Category.comp_id]
  obtain ⟨e⟩ := hconn a
  rw [← IsIso.inv_hom_id_assoc e f, F.map_comp, F'.map_comp]
  simp only [Functor.map_inv, h]

end Ext

end TauCeti.Groupoid
