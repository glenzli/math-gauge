/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import Mathlib.Topology.Connected.LocallyConnected
public import Mathlib.Topology.Maps.Basic
public import Mathlib.Topology.Separation.Hausdorff

/-!
# Local connectedness of continuous images of compact spaces

Local connectedness is not preserved by continuous images in general — every metric space is a
continuous image of a discrete one — but it *is* preserved by quotient maps, and hence by the
continuous images that are automatically quotient maps: those of a compact space in a Hausdorff
one. This file proves that, in the type-level form and in the set-level form
`TauCeti.locallyConnectedSpace_image_of_isCompact` that a subset of a topological space needs.

The quotient step itself is Mathlib's. `Topology.IsCoinducing.locallyConnectedSpace` states that
a topology coinduced by a locally connected one is locally connected, which reaches quotient maps
through `IsQuotientMap.isCoinducing` and is strictly more general, since coinducing does not ask
for surjectivity. What is added here is the passage from that to a continuous surjection out of a
compact space, which is closed and therefore a quotient map.

One application is the necessary half of Carathéodory's continuity theorem: a conformal map on a
bounded domain with locally connected boundary that extends continuously to the closure has
locally connected image boundary. The extension maps the compact source boundary onto the image
boundary, so the set-level result applies. This application is in
`TauCeti/Analysis/Complex/Conformal/LocallyConnectedBoundary.lean`.

## Main results

* `TauCeti.locallyConnectedSpace_of_continuous_surjective` — the continuous image of a compact
  locally connected space in a Hausdorff space is locally connected.
* `TauCeti.locallyConnectedSpace_image_of_isCompact` — the set-level form: `f '' s` is locally
  connected for a compact, locally connected `s` on which `f` is continuous.
* `TauCeti.locallyConnectedSpace_iUnion_image_of_isCompact` — a finite union of such images is
  locally connected; for instance a finite union of arcs.

## References

* R. Engelking, *General Topology*, Theorem 6.1.29 (Hahn's theorem on quotients).
* J. G. Hocking and G. S. Young, *Topology*, Ch. 3.
-/

public section

namespace TauCeti

open Set Topology

variable {X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y]

/-- **The continuous image of a compact locally connected space in a Hausdorff space is locally
connected.** A continuous surjection out of a compact space onto a Hausdorff one is closed, hence
a quotient map, hence coinducing, so `Topology.IsCoinducing.locallyConnectedSpace` applies. -/
theorem locallyConnectedSpace_of_continuous_surjective [LocallyConnectedSpace X] [CompactSpace X]
    [T2Space Y] {f : X → Y} (hf : Continuous f) (hsurj : Function.Surjective f) :
    LocallyConnectedSpace Y :=
  (hf.isClosedMap.isQuotientMap hf hsurj).isCoinducing.locallyConnectedSpace

/-- **The set-level form: a compact, locally connected set has locally connected continuous
images.** Stated with the subtype topologies on `s` and on `f '' s`, which is how a boundary or a
closure of a subset of a normed space is met in practice. -/
theorem locallyConnectedSpace_image_of_isCompact [T2Space Y] {s : Set X} {f : X → Y}
    [LocallyConnectedSpace s] (hs : IsCompact s) (hf : ContinuousOn f s) :
    LocallyConnectedSpace (f '' s) := by
  have : CompactSpace s := isCompact_iff_compactSpace.mp hs
  exact locallyConnectedSpace_of_continuous_surjective (hf.mapsToRestrict (mapsTo_image f s))
    (surjective_mapsTo_image_restrict f s)

/-- **A finite union of continuous images of a compact, locally connected set is locally
connected.** For instance a finite union of arcs `f i '' Icc 0 1` is locally connected, although a
union of two closed locally connected sets need not be. The union is the continuous image of the
compact, locally connected product of the discrete index type with `s`. -/
theorem locallyConnectedSpace_iUnion_image_of_isCompact [T2Space Y] {ι : Type*} [Finite ι]
    {s : Set X} {f : ι → X → Y} [LocallyConnectedSpace s] (hs : IsCompact s)
    (hf : ∀ i, ContinuousOn (f i) s) : LocallyConnectedSpace (⋃ i, f i '' s) := by
  let _ : TopologicalSpace ι := ⊥
  have : DiscreteTopology ι := ⟨rfl⟩
  have : CompactSpace s := isCompact_iff_compactSpace.mp hs
  let F : ι × s → ⋃ i, f i '' s := fun p =>
    ⟨f p.1 p.2, mem_iUnion.mpr ⟨p.1, mem_image_of_mem _ p.2.2⟩⟩
  refine locallyConnectedSpace_of_continuous_surjective (f := F) ?_ ?_
  · exact continuous_induced_rng.mpr
      (continuous_prod_of_discrete_left.mpr fun i => (hf i).domRestrict)
  · rintro ⟨y, hy⟩
    obtain ⟨i, x, hx, rfl⟩ := mem_iUnion.mp hy
    exact ⟨(i, ⟨x, hx⟩), rfl⟩

end TauCeti
