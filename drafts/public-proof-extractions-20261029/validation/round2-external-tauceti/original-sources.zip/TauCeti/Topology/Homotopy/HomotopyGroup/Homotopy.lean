/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import TauCeti.Topology.Homotopy.GenLoop.Homotopic
public import TauCeti.Topology.Homotopy.HomotopyGroup.Map

/-!
# Homotopy of generalized loops

Mathlib defines `GenLoop.Homotopic`, homotopy of generalized loops relative to the cube
boundary, and separately topologises `Ω^ N X x` with the compact-open topology, but does not
relate the two. This file proves that they agree: two generalized loops are homotopic relative
to the cube boundary exactly when they are joined by a path in `Ω^ N X x`. Currying a homotopy
`I × I^N → X` gives the path, and uncurrying a path gives the homotopy; the boundary condition
is automatic in both directions, because every generalized loop is constant at `x` on the cube
boundary. In the one-dimensional case this is transported across Mathlib's bijection
`genLoopEquivOfUnique` between one-dimensional generalized loops and paths, where homotopy
relative to the cube boundary becomes homotopy of paths.

The file also treats homotopies in the base space: a homotopy between based maps must remain
fixed at the basepoint in order to induce a homotopy between their postcompositions with a
generalized loop. That construction is made explicit, and pointed-homotopic maps are shown to
induce the same map on every homotopy group, with the corresponding equality of bundled monoid
homomorphisms in positive dimensions.

## Main declarations

* `GenLoop.homotopic_iff_joined`: **homotopy relative to the cube boundary is path
  connectedness in `Ω^ N X x`.**
* `GenLoop.homotopic_genLoopEquivOfUnique_iff`: for a singleton index type, homotopy relative
  to the cube boundary is homotopy of the corresponding paths.
* `HomotopyGroup.map_eq_of_homotopicRel`: pointed-homotopic maps induce the same map on
  homotopy groups.
* `FundamentalGroup.mapOfEq_eq_of_homotopicRel`: pointed-homotopic maps induce the same
  homomorphism of fundamental groups.
-/

public section

open scoped unitInterval Topology Topology.Homotopy
open Topology.Homotopy

namespace GenLoop

variable {N X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y]
  {x : X} {y : Y}

/-- Homotopy of one-dimensional generalized loops relative to the cube boundary is homotopy of
the paths they correspond to under Mathlib's bijection `genLoopEquivOfUnique`. Both sides say
that the two classes agree in a quotient, and `homotopyGroupEquivFundamentalGroupOfUnique`
identifies `HomotopyGroup N X x` with `FundamentalGroup X x` by exactly this bijection. -/
theorem homotopic_genLoopEquivOfUnique_iff [Unique N] {p q : Ω^ N X x} :
    (genLoopEquivOfUnique N p).Homotopic (genLoopEquivOfUnique N q) ↔
      _root_.GenLoop.Homotopic p q :=
  ⟨fun h => Quotient.exact
      (((homotopyGroupEquivFundamentalGroupOfUnique (X := X) (x := x) N).trans
        CategoryTheory.End.homEquiv).injective (Quotient.sound h)),
   fun h => Quotient.exact
      (congrArg ((homotopyGroupEquivFundamentalGroupOfUnique (X := X) (x := x) N).trans
        CategoryTheory.End.homEquiv) (Quotient.sound h))⟩

/-! ### Homotopies in the base space -/

/-- Postcomposing a generalized loop with maps homotopic relative to a set containing the
basepoint gives homotopic generalized loops. The resulting homotopy is relative to the cube
boundary. -/
theorem map_homotopic_of_homotopicRel {f g : C(X, Y)} (hf : f x = y) {S : Set X}
    (hx : x ∈ S) (H : f.HomotopicRel g S) (p : Ω^ N X x) :
    _root_.GenLoop.Homotopic (map f hf p) (map g ((H.fst_eq_snd hx).symm.trans hf) p) := by
  obtain ⟨H⟩ := H
  refine ⟨⟨⟨⟨fun tp ↦ H (tp.1, p.1 tp.2), ?_⟩, ?_, ?_⟩, ?_⟩⟩
  · fun_prop
  · intro t
    exact (H.apply_zero (p.1 t)).trans (map_apply f hf p t).symm
  · intro t
    exact (H.apply_one (p.1 t)).trans (map_apply g _ p t).symm
  · intro t u hu
    have hpu : p.1 u ∈ S := by rw [p.2 u hu]; exact hx
    refine (H.eq_fst t hpu).trans ?_
    exact (map_apply f hf p u).symm

end GenLoop

namespace HomotopyGroup

variable {N X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y]
  {x : X} {y : Y}

/-- Continuous maps homotopic relative to a set containing the basepoint induce the same
function on homotopy groups. -/
theorem map_eq_of_homotopicRel {f g : C(X, Y)} (hf : f x = y) {S : Set X}
    (hx : x ∈ S) (H : f.HomotopicRel g S) :
    map (N := N) f hf = map g ((H.fst_eq_snd hx).symm.trans hf) := by
  funext a
  refine Quotient.inductionOn a ?_
  intro p
  exact Quotient.sound (GenLoop.map_homotopic_of_homotopicRel hf hx H p)

/-- Continuous maps homotopic relative to a set containing the basepoint have equal induced
monoid homomorphisms on positive-dimensional homotopy groups. -/
theorem mapHom_eq_of_homotopicRel [DecidableEq N] [Nonempty N] {f g : C(X, Y)}
    (hf : f x = y) {S : Set X} (hx : x ∈ S) (H : f.HomotopicRel g S) :
    mapHom (N := N) f hf = mapHom g ((H.fst_eq_snd hx).symm.trans hf) :=
  MonoidHom.ext fun a ↦ congrFun (map_eq_of_homotopicRel hf hx H) a

end HomotopyGroup

namespace FundamentalGroup

variable {X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y] {x : X} {y : Y}

/-- Continuous maps homotopic relative to a set containing the basepoint induce the same
homomorphism of fundamental groups. -/
theorem mapOfEq_eq_of_homotopicRel {f g : C(X, Y)} (hf : f x = y) (hg : g x = y) {S : Set X}
    (hx : x ∈ S) (H : f.HomotopicRel g S) :
    mapOfEq f hf = mapOfEq g hg := by
  ext a
  obtain ⟨b, rfl⟩ := HomotopyGroup.pi1EquivFundamentalGroup.surjective a
  rw [← HomotopyGroup.pi1EquivFundamentalGroup_map, ← HomotopyGroup.pi1EquivFundamentalGroup_map,
    HomotopyGroup.map_eq_of_homotopicRel hf hx H]

end FundamentalGroup
