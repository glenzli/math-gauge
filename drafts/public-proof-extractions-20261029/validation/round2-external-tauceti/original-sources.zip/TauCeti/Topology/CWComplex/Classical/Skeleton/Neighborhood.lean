/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import Mathlib.Topology.CWComplex.Classical.Subcomplex
public import Mathlib.Topology.Homotopy.Basic
public import TauCeti.Analysis.Normed.Module.Ball.Radial.Push
public import TauCeti.Topology.CWComplex.Classical.Skeleton.CellDeformation

/-!
# The skeleton with the cores of its top cells removed

Let `C` be a relative CW complex and `n : ℕ`, and write `Xⁿ = skeletonLT C (n + 1)` and
`Xⁿ⁻¹ = skeletonLT C n` for the skeleta made of the cells of dimension at most `n` and below `n`.
Removing from `Xⁿ` the image `map n j '' ball 0 2⁻¹` of the inner half of every open `n`-cell
leaves `TauCeti.skeletonNeighborhood C n`: `Xⁿ⁻¹` together with the outer halves of the open
`n`-cells.  It is a neighbourhood of `Xⁿ⁻¹` in `Xⁿ`, and it deformation retracts onto `Xⁿ⁻¹`, so
`(Xⁿ, Xⁿ⁻¹)` is a good pair in the sense of Hatcher.

The deformation is one homotopy `TauCeti.skeletonNeighborhoodHomotopy C n` of the whole of
`Xⁿ`, starting at the identity.  Inside each closed `n`-cell, read through the characteristic map,
it pushes
points radially outwards: the point `y` of the closed unit ball moves along the segment from `y`
to `2 • y` if `‖y‖ ≤ 2⁻¹`, and to `‖y‖⁻¹ • y` otherwise.  It fixes `Xⁿ⁻¹` pointwise at all times,
keeps `skeletonNeighborhood C n` inside itself at all times, and at the end sends
`skeletonNeighborhood C n` into `Xⁿ⁻¹`.  Consequently the inclusion of pairs
`(Xⁿ, Xⁿ⁻¹) ⟶ (Xⁿ, skeletonNeighborhood C n)` is a homotopy equivalence of pairs, while in the
second pair `Xⁿ⁻¹` lies in the interior of the subspace and can
be excised.

## Main definitions

* `TauCeti.skeletonNeighborhood C n`: `Xⁿ` minus the inner halves of the open `n`-cells.
* `TauCeti.skeletonNeighborhoodHomotopy C n`: the homotopy of `Xⁿ` from the identity to
  `TauCeti.skeletonNeighborhoodEndpoint C n`.

## Main results

* `TauCeti.isClosed_iUnion_map_closedBall`: the closed cores of radius `r < 1` of the open
  `n`-cells form a closed set.
* `TauCeti.skeletonLT_subset_interior_skeletonNeighborhood`: `skeletonNeighborhood C n` is a
  neighbourhood of `Xⁿ⁻¹` in `Xⁿ`.
* `TauCeti.skeletonNeighborhoodHomotopy_apply_of_mem`: the homotopy fixes `Xⁿ⁻¹`.
* `TauCeti.skeletonNeighborhoodHomotopy_mem`: the homotopy keeps
  `skeletonNeighborhood C n` inside itself.
* `TauCeti.skeletonNeighborhoodEndpoint_mem`: its endpoint sends
  `skeletonNeighborhood C n` into `Xⁿ⁻¹`.

## References

* A. Hatcher, [*Algebraic Topology*](https://pi.math.cornell.edu/~hatcher/AT/AT.pdf),
  Section 2.1 (good pairs) and Section 2.2, Lemma 2.34, whose proof uses that `(Xⁿ, Xⁿ⁻¹)` is a
  good pair.
-/

public section

noncomputable section

open Metric Set Topology Topology.RelCWComplex unitInterval

universe u

namespace TauCeti

variable {X : Type u} [TopologicalSpace X] [T2Space X] {D : Set X} (C : Set X) [RelCWComplex C D]

/-- The `n`-skeleton `Xⁿ = skeletonLT C (n + 1)` of a relative CW complex with the inner half
`map n j '' ball 0 2⁻¹` of every open `n`-cell removed: `Xⁿ⁻¹ = skeletonLT C n` together with the
outer halves of the open `n`-cells.  It is a neighbourhood of `Xⁿ⁻¹` in `Xⁿ`
(`TauCeti.skeletonLT_subset_interior_skeletonNeighborhood`) which deformation retracts onto
`Xⁿ⁻¹` through `TauCeti.skeletonNeighborhoodHomotopy`. -/
def skeletonNeighborhood (n : ℕ) : Set X :=
  (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X) \ ⋃ j : cell C n, map n j '' ball 0 2⁻¹

variable {C}

lemma mem_skeletonNeighborhood {n : ℕ} {x : X} :
    x ∈ skeletonNeighborhood C n ↔ x ∈ (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X) ∧
      ∀ (j : cell C n) (y : Fin n → ℝ), ‖y‖ < 2⁻¹ → map n j y ≠ x := by
  simp [skeletonNeighborhood]

variable (C)

lemma skeletonNeighborhood_subset_skeletonLT_succ (n : ℕ) :
    skeletonNeighborhood C n ⊆ (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X) :=
  sdiff_subset

variable {C}

lemma skeletonLT_subset_skeletonNeighborhood (n : ℕ) :
    (skeletonLT C (n : ℕ∞) : Set X) ⊆ skeletonNeighborhood C n := by
  refine fun x hx ↦ mem_skeletonNeighborhood.2 ⟨skeletonLT_mono (mod_cast n.le_succ) hx, ?_⟩
  rintro j y hy rfl
  exact map_notMem_skeletonLT j (hy.trans (by norm_num)) hx

/-- **The closed cores of the open `n`-cells form a closed set**: for `r < 1`, the union over all
`n`-cells of the images of the closed ball of radius `r` under the characteristic maps is closed.
Each core lies in its open cell. A closed cell of dimension `n` meets the union only in its
own compact core; open cells of other dimensions are disjoint from it. -/
theorem isClosed_iUnion_map_closedBall (n : ℕ) {r : ℝ} (hr : r < 1) :
    IsClosed (⋃ j : cell C n, map n j '' closedBall 0 r) := by
  have hcore (j : cell C n) : map n j '' closedBall 0 r ⊆ openCell n j :=
    image_mono (closedBall_subset_ball hr)
  refine isClosed_of_disjoint_openCell_or_isClosed_inter_closedCell (C := C) ?_ ?_
    fun m _ i ↦ ?_
  · exact iUnion_subset fun j ↦ (hcore j).trans (openCell_subset_complex n j)
  · convert isClosed_empty
    refine eq_empty_of_forall_notMem fun x ⟨hx, hxD⟩ ↦ ?_
    obtain ⟨j, hj⟩ := mem_iUnion.1 hx
    exact (disjointBase n j).notMem_of_mem_left (hcore j hj) hxD
  by_cases hm : m = n
  · subst hm
    right
    -- Only the core of `i` meets the closed cell of `i`: a point of another open `m`-cell lies
    -- neither in the open cell of `i` nor in its frontier, which is in `skeletonLT C m`.
    convert (isCompact_closedBall (0 : Fin m → ℝ) r |>.image_of_continuousOn
      ((continuousOn m i).mono (closedBall_subset_closedBall hr.le))).isClosed using 1
    refine subset_antisymm (fun x ⟨hx, hxi⟩ ↦ ?_) fun x hx ↦
      ⟨mem_iUnion.2 ⟨i, hx⟩, openCell_subset_closedCell m i (hcore i hx)⟩
    obtain ⟨j, hj⟩ := mem_iUnion.1 hx
    rw [← cellFrontier_union_openCell_eq_closedCell] at hxi
    obtain hxi | hxi := hxi
    · exact absurd (hcore j hj) fun h ↦ (disjoint_skeletonLT_openCell le_rfl).notMem_of_mem_left
        (cellFrontier_subset_skeletonLT m i hxi) h
    · obtain rfl : j = i := by
        by_contra hne
        exact (disjoint_openCell_of_ne (by simpa using hne)).notMem_of_mem_left (hcore j hj) hxi
      exact hj
  · left
    refine disjoint_iUnion_left.2 fun j ↦ ((disjoint_openCell_of_ne ?_).mono_left (hcore j))
    simp [Ne.symm hm]

variable (C) in
/-- **`TauCeti.skeletonNeighborhood C n` is a neighbourhood of `Xⁿ⁻¹ = skeletonLT C n` in
`Xⁿ = skeletonLT C (n + 1)`.** -/
theorem skeletonLT_subset_interior_skeletonNeighborhood (n : ℕ) :
    (Subtype.val ⁻¹' (skeletonLT C n : Set X) : Set (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X)) ⊆
      interior (Subtype.val ⁻¹' skeletonNeighborhood C n) := by
  -- The complement of the closed cores of radius `2⁻¹` is open, contains `skeletonLT C n`, and
  -- lies in `TauCeti.skeletonNeighborhood C n`.
  have hK := isClosed_iUnion_map_closedBall (C := C) n (r := 2⁻¹) (by norm_num)
  refine fun x hx ↦ interior_maximal (t := (Subtype.val ⁻¹'
    (⋃ j : cell C n, map n j '' closedBall 0 2⁻¹))ᶜ) (fun y hy ↦ ?_)
    (hK.preimage continuous_subtype_val).isOpen_compl ?_
  · refine mem_skeletonNeighborhood.2 ⟨y.2, fun j z hz h ↦ hy (mem_iUnion.2 ⟨j, z, ?_, h⟩)⟩
    exact mem_closedBall_zero_iff.2 hz.le
  · rintro hx'
    obtain ⟨j, y, hy, hxy⟩ := mem_iUnion.1 hx'
    exact map_notMem_skeletonLT j ((mem_closedBall_zero_iff.1 hy).trans_lt (by norm_num))
      (hxy ▸ hx)

/-- The radial push `TauCeti.radialPush 2⁻¹` of the closed unit ball, as a continuous map. -/
private def radialPushMap (n : ℕ) : C(I × (Fin n → ℝ), Fin n → ℝ) :=
  ⟨fun q ↦ radialPush 2⁻¹ q.1 q.2, continuous_radialPush (by norm_num)⟩

private lemma radialPushMap_of_norm_eq_one (n : ℕ) (t : I) (y : Fin n → ℝ) (hy : ‖y‖ = 1) :
    radialPushMap n (t, y) = y :=
  radialPush_of_norm_eq_one (by norm_num) (by norm_num) t hy

private lemma norm_radialPushMap_le_one (n : ℕ) (t : I) (y : Fin n → ℝ) (hy : ‖y‖ ≤ 1) :
    ‖radialPushMap n (t, y)‖ ≤ 1 :=
  norm_radialPush_le_one (by norm_num) t hy

/-- Through the characteristic map of an `n`-cell, the radial push of the cells is the radial
push of the closed unit ball. -/
private lemma cellDeformation_radialPushMap_map {n : ℕ} (t : I) (j : cell C n) {y : Fin n → ℝ}
    (hy : ‖y‖ ≤ 1) :
    cellDeformation (univ : Set (cell C n)) (radialPushMap n) (t, map n j y) =
      map n j (radialPush 2⁻¹ t y) :=
  cellDeformation_map (radialPushMap_of_norm_eq_one n) (mem_univ j) t hy

/-- A point of a closed `n`-cell belongs to the skeletal neighborhood exactly when it lies outside
the inner half of its cell. -/
@[simp]
lemma map_mem_skeletonNeighborhood_iff {n : ℕ} (j : cell C n) {y : Fin n → ℝ}
    (hy : ‖y‖ ≤ 1) : map n j y ∈ skeletonNeighborhood C n ↔ (2 : ℝ)⁻¹ ≤ ‖y‖ := by
  rcases hy.lt_or_eq with hy | hy
  · constructor
    · intro h
      exact not_lt.1 fun hlt ↦ (mem_skeletonNeighborhood.1 h).2 j y hlt rfl
    · intro h
      refine mem_skeletonNeighborhood.2 ⟨map_mem_skeletonLT_succ j hy.le, ?_⟩
      intro i z hz heq
      obtain ⟨_, rfl⟩ := (map_eq_map_iff (hz.trans (by norm_num)) hy).1 heq
      exact (not_lt.2 h) hz
  · -- A point of the boundary sphere lands in the cell frontier, inside `Xⁿ⁻¹`.
    refine iff_of_true (skeletonLT_subset_skeletonNeighborhood n ?_) (by rw [hy]; norm_num)
    exact cellFrontier_subset_skeletonLT n j ⟨y, mem_sphere_zero_iff_norm.2 hy, rfl⟩

variable (C) in
/-- The radial push of the `n`-cells as a homotopy of `skeletonLT C (n + 1)`. -/
private def pushMap (n : ℕ) :
    C(I × (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X), (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X)) :=
  ⟨fun p ↦ ⟨cellDeformation (univ : Set (cell C n)) (radialPushMap n) (p.1, p.2),
      cellDeformation_mem (norm_radialPushMap_le_one n) p.1 p.2.2⟩,
    (continuous_cellDeformation univ (radialPushMap_of_norm_eq_one n)
      (norm_radialPushMap_le_one n)).subtype_mk _⟩

private lemma pushMap_apply_coe {n : ℕ} (p : I × (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X)) :
    (pushMap C n p : X) =
      cellDeformation (univ : Set (cell C n)) (radialPushMap n) (p.1, (p.2 : X)) :=
  (rfl)

variable (C) in
/-- The endpoint of `TauCeti.skeletonNeighborhoodHomotopy`: the self-map of
`Xⁿ = skeletonLT C (n + 1)`
which pushes the outer half of every open `n`-cell onto its boundary and expands the inner half
over the whole cell.  It sends `TauCeti.skeletonNeighborhood C n` into `Xⁿ⁻¹ = skeletonLT C n`. -/
def skeletonNeighborhoodEndpoint (n : ℕ) :
    C(skeletonLT C ((n + 1 : ℕ) : ℕ∞), skeletonLT C ((n + 1 : ℕ) : ℕ∞)) :=
  (pushMap C n).curry 1

variable (C) in
/-- The radial deformation of the `n`-skeleton `Xⁿ = skeletonLT C (n + 1)` of a relative CW
complex: inside each closed `n`-cell, read through the characteristic map, it moves `y` along the
segment from `y` to `2 • y` if `‖y‖ ≤ 2⁻¹` and to `‖y‖⁻¹ • y` otherwise.  It fixes
`Xⁿ⁻¹ = skeletonLT C n`, keeps `TauCeti.skeletonNeighborhood C n` inside itself, and ends at
`TauCeti.skeletonNeighborhoodEndpoint C n`. -/
def skeletonNeighborhoodHomotopy (n : ℕ) :
    (ContinuousMap.id _).Homotopy (skeletonNeighborhoodEndpoint C n) where
  toContinuousMap := pushMap C n
  map_zero_left x := by
    refine Subtype.ext ?_
    obtain hx | ⟨j, y, hy, hxy⟩ := mem_skeletonLT_or_exists_map x.2
    · exact cellDeformation_of_mem_skeletonLT hx
    · rw [ContinuousMap.toFun_eq_coe, pushMap_apply_coe, ContinuousMap.id_apply, ← hxy,
        cellDeformation_radialPushMap_map 0 j hy.le, radialPush_zero]
  map_one_left _ := rfl

private lemma coe_skeletonNeighborhoodHomotopy_apply {n : ℕ} (t : I)
    (x : (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X)) :
    (skeletonNeighborhoodHomotopy C n (t, x) : X) =
      cellDeformation (univ : Set (cell C n)) (radialPushMap n) (t, (x : X)) :=
  (rfl)

/-- On a closed `n`-cell, the skeletal deformation is the straight-line homotopy
`TauCeti.radialPush 2⁻¹` to the scaled radial retraction, read through the characteristic map. -/
lemma skeletonNeighborhoodHomotopy_map {n : ℕ} (t : I) (j : cell C n)
    {y : Fin n → ℝ} (hy : ‖y‖ ≤ 1)
    (x : (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X)) (hx : (x : X) = map n j y) :
    ((skeletonNeighborhoodHomotopy C n (t, x) : X)) = map n j (radialPush 2⁻¹ t y) := by
  rw [coe_skeletonNeighborhoodHomotopy_apply, hx, cellDeformation_radialPushMap_map t j hy]

/-- The deformation fixes `Xⁿ⁻¹ = skeletonLT C n` pointwise. -/
@[simp]
lemma skeletonNeighborhoodHomotopy_apply_of_mem {n : ℕ} (t : I)
    (x : (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X)) (hx : (x : X) ∈ (skeletonLT C n : Set X)) :
    skeletonNeighborhoodHomotopy C n (t, x) = x :=
  Subtype.ext (cellDeformation_of_mem_skeletonLT hx)

/-- The endpoint of the deformation fixes `Xⁿ⁻¹ = skeletonLT C n` pointwise. -/
@[simp]
lemma skeletonNeighborhoodEndpoint_apply_of_mem {n : ℕ}
    (x : (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X))
    (hx : (x : X) ∈ (skeletonLT C n : Set X)) :
    skeletonNeighborhoodEndpoint C n x = x := by
  rw [← (skeletonNeighborhoodHomotopy C n).apply_one,
    skeletonNeighborhoodHomotopy_apply_of_mem 1 x hx]

/-- The deformation keeps `TauCeti.skeletonNeighborhood C n` inside itself at every time. -/
lemma skeletonNeighborhoodHomotopy_mem {n : ℕ} (t : I)
    (x : (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X))
    (hx : (x : X) ∈ skeletonNeighborhood C n) :
    (skeletonNeighborhoodHomotopy C n (t, x) : X) ∈ skeletonNeighborhood C n := by
  obtain hx' | ⟨j, y, hy, hxy⟩ := mem_skeletonLT_or_exists_map x.2
  · rw [skeletonNeighborhoodHomotopy_apply_of_mem t x hx']
    exact hx
  have hy2 : (2 : ℝ)⁻¹ ≤ ‖y‖ := not_lt.1 fun h ↦ (mem_skeletonNeighborhood.1 hx).2 j y h hxy
  rw [coe_skeletonNeighborhoodHomotopy_apply, ← hxy,
    cellDeformation_radialPushMap_map t j hy.le]
  have hz : ‖y‖ ≤ ‖radialPush 2⁻¹ t y‖ :=
    norm_le_norm_radialPush (by norm_num) (by norm_num) t hy.le
  rcases (norm_radialPush_le_one (r := 2⁻¹) (by norm_num) t hy.le).lt_or_eq with
      hz1 | hz1
  · refine mem_skeletonNeighborhood.2 ⟨map_mem_skeletonLT_succ j hz1.le, fun i w hw h ↦ ?_⟩
    obtain ⟨-, rfl⟩ := (map_eq_map_iff (hw.trans (by norm_num)) hz1).1 h
    linarith
  · exact skeletonLT_subset_skeletonNeighborhood n
      (cellFrontier_subset_skeletonLT n j ⟨_, mem_sphere_zero_iff_norm.2 hz1, rfl⟩)

/-- The endpoint of the deformation sends `TauCeti.skeletonNeighborhood C n` into
`Xⁿ⁻¹ = skeletonLT C n`. -/
lemma skeletonNeighborhoodEndpoint_mem {n : ℕ} (x : (skeletonLT C ((n + 1 : ℕ) : ℕ∞) : Set X))
    (hx : (x : X) ∈ skeletonNeighborhood C n) :
    (skeletonNeighborhoodEndpoint C n x : X) ∈ (skeletonLT C n : Set X) := by
  obtain hx' | ⟨j, y, hy, hxy⟩ := mem_skeletonLT_or_exists_map x.2
  · rw [← (skeletonNeighborhoodHomotopy C n).apply_one,
      skeletonNeighborhoodHomotopy_apply_of_mem 1 x hx']
    exact hx'
  have hy2 : (2 : ℝ)⁻¹ ≤ ‖y‖ := not_lt.1 fun h ↦ (mem_skeletonNeighborhood.1 hx).2 j y h hxy
  rw [← (skeletonNeighborhoodHomotopy C n).apply_one, coe_skeletonNeighborhoodHomotopy_apply, ← hxy,
    cellDeformation_radialPushMap_map 1 j hy.le]
  exact cellFrontier_subset_skeletonLT n j
    ⟨_, mem_sphere_zero_iff_norm.2 (norm_radialPush_one (by norm_num) hy2), rfl⟩

end TauCeti
