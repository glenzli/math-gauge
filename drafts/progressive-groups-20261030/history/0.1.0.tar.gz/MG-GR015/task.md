# 自由模的商记录、完成支持与提升

逐项按 S 编号交付。prove 要给证明，construct 要给对象及性质，decide 要先判定所列命题并给完整证明或满足全部前提的反例，synthesize 要完成全部分类或综合要求。援引前项或标准定理时说明实际适用条件。允许有效短证明与替代路线；所有阶段均必答，不能以某一阶段的反例替代其他阶段。无需 Lean。



## S1 分裂列的完成（prove，15 分）

设 R=k[t]，0→A→B→C→0 为任意 R 模短正合列，另给 R 线性截面 s:C→B。证明完成列短正合，构造每个 ĉ∈Ĉ 的全部提升，并说明更换 s 如何改变所选提升。

## S2 可数自由模的完成模型（construct，15 分）

令 M=⊕_{i≥0}Re_i。把 M̂ 具体识别为 R̂=k[[t]] 的序列族：准确给出允许的支持条件、加法和标量作用，并证明与全部相容商记录双向互逆。

## S3 有界对角指数（prove，15 分）

取 A=⊕Rf_i、B=⊕Re_i，ι(f_i)=t^{ν_i}e_i，其中 0≤ν_i≤M 为固定整数界，C=coker ι。证明完成列短正合，并用 S2 的坐标模型写出全部提升。

## S4 整体对象与全部恢复目标（decide，25 分）

对下面全部给定条件及全部目标作总体判定；目标是待论证的结论，不是附加前提。若成立须完成所列的全部构造、分类与性质；若不成立须给保持全部条件的反例。

设 $k$ 为域，$R=k[t]$。给定 $R$ 模的短正合列

$$0\longrightarrow A\xrightarrow{\iota}B\xrightarrow{q}C\longrightarrow0,$$

其中 $A,B$ 均为可数生成的自由 $R$ 模。

对任意 $R$ 模 $M$，定义其 $t$ 进完备化

$$\widehat M=\varprojlim_{n\ge0}M/t^nM,$$

过渡映射为自然约化。原行映射在各层诱导商模映射，因而诱导 $\widehat\iota:\widehat A\to\widehat B$ 和 $\widehat q:\widehat B\to\widehat C$。

建立自由呈示在完备化后的相容恢复理论。目标是证明

$$0\longrightarrow\widehat A\xrightarrow{\widehat\iota}\widehat B
\xrightarrow{\widehat q}\widehat C\longrightarrow0$$

仍为短正合列，并给出相容商记录的提升构造与全部提升的自由度。请完成构造和正合性论证。

## S5 原模与完成的值域（decide，15 分）

仍令 M=⊕_{i≥0}k[t]e_i。判定典范映射 M→M̂ 是否必为满射；若不是，给出在每一商层都由原模代表但不来自一个原模元素的记录。

## S6 再次完成（decide，15 分）

把 M̂ 视为 R 模，判定 M̂→lim_n M̂/t^nM̂ 是否为同构，并验证典范映射而非另选抽象同构。
