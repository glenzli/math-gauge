#!/usr/bin/env python3
"""Start the gated two-slot queue only after the explicit inference release."""
from pathlib import Path
import datetime
import json
import subprocess
import sys
from gates import EXPECTED_IDS, FLOW, digest, load, verify_release

def main():
    freeze, release = verify_release()
    probes = load(FLOW / 'open-probe-summary.json')
    if probes.get('passed') is not True or [row['case_id'] for row in probes['cases']] != EXPECTED_IDS:
        raise RuntimeError('Every actual per-case file/network probe must pass before queue startup')
    supervisor = FLOW / 'queue-supervisor.json'
    if supervisor.exists():
        raise RuntimeError('This queue has already been started; no automatic restarts')
    script = FLOW / 'run_cases.py'
    stdout = FLOW / 'queue.stdout.txt'; stderr = FLOW / 'queue.stderr.txt'
    with stdout.open('xb') as out, stderr.open('xb') as error:
        proc = subprocess.Popen([str(Path(sys.executable).resolve()), '-B', str(script)],
                                cwd=FLOW, stdin=subprocess.DEVNULL, stdout=out, stderr=error,
                                start_new_session=True)
    record = {
        'pid': proc.pid, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'script': str(script), 'script_sha256': digest(script),
        'stdout': str(stdout), 'stderr': str(stderr), 'max_parallel': 2,
        'per_case_timeout_seconds': 2700, 'cases': EXPECTED_IDS,
        'fresh_run_root': str(FLOW / 'live-runs'), 'no_automatic_model_retry': True,
        'halts_new_starts_on_failure': True,
        'inference_release_sha256': digest(FLOW / 'inference-release.json'),
        'pretrial_freeze_sha256': digest(FLOW / 'pretrial-freeze.json'),
        'suite_sha256': freeze['suite_sha256'],
    }
    with supervisor.open('x') as out:
        json.dump(record, out, indent=2); out.write('\n')
    print(json.dumps(record))

if __name__ == '__main__':
    main()
