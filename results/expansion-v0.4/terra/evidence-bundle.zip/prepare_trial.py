#!/usr/bin/env python3
"""Freeze all owner-approved evaluation material and prepare ten fresh runs.

No inference is started. The queue additionally requires a later explicit parent
release bound to the resulting pretrial-freeze.json SHA256.
"""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import shutil
import sys
from gates import EXPECTED_IDS, FLOW, MIRROR, verify_frozen_cases

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        json.dump(value, out, ensure_ascii=False, indent=2); out.write('\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    verify_frozen_cases()
    sys.path.insert(0, str(MIRROR))
    from math_gauge.catalog import Suite
    from math_gauge.execution import runner_fingerprint
    suite = Suite.load(MIRROR / 'cases/public')
    assert suite.metadata['version'] == '0.4.0' and len(suite.cases) == 20
    review_root = MIRROR / 'results/expansion-v0.4/reviews'
    editorial = json.loads((review_root / 'PROMPT-AUDIT.json').read_text())
    resolution = json.loads((review_root / 'PROMPT-AUDIT-RESOLUTION.json').read_text())
    assert resolution['audit_sha256'] == digest(review_root / 'PROMPT-AUDIT.json')
    assert [row['task_id'] for row in editorial['tasks']] == EXPECTED_IDS
    for row in editorial['tasks']:
        assert row['editorial_verdict'] == 'pass'
        assert row['task_sha256'] == digest(MIRROR / 'cases/public' / row['task_id'] / 'task.md')
    spec = importlib.util.spec_from_file_location('runtime_helper', FLOW / 'tools/prepare_runtime.py')
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    snapshot = FLOW / 'evaluator-freeze'; snapshot.mkdir(exist_ok=False)
    for cid in EXPECTED_IDS:
        shutil.copytree(MIRROR / 'cases/public' / cid, snapshot / cid)
    for name in ('suite.json', 'sources.json'):
        shutil.copyfile(MIRROR / 'cases/public' / name, snapshot / name)
    shutil.copyfile(MIRROR / 'scripts/formal/suite.json', snapshot / 'formal-suite.json')
    shutil.copytree(review_root, snapshot / 'reviews')
    files = [{'path': p.relative_to(FLOW).as_posix(), 'sha256': digest(p), 'bytes': p.stat().st_size}
             for p in sorted(snapshot.rglob('*')) if p.is_file()]
    pretrial = {'schema': 'math-gauge.pretrial-freeze/v1', 'recorded_utc': helper.now(),
                'case_ids': EXPECTED_IDS, 'suite_version': suite.metadata['version'],
                'suite_sha256': suite.sha256, 'runner_sha256': runner_fingerprint(),
                'frozen_files': files, 'requested_model': 'gpt-6.1-terra', 'requested_effort': 'max',
                'candidate_policy': 'Exactly one task.md message per new ephemeral session; no feedback or automatic retries.',
                'model_requests_so_far': 0, 'inference_release_required': True}
    pretrial['editorial_audit_sha256'] = digest(review_root / 'PROMPT-AUDIT.json')
    pretrial['prompt_contract_resolution_sha256'] = digest(review_root / 'PROMPT-AUDIT-RESOLUTION.json')
    save(FLOW / 'attempt-ledger.json', {'attempts': [], 'tool_mismatch_decisions': [], 'mathematical_requests': 0})
    installation = Path('/Users/g4i/.codex/installation_id')
    save(FLOW / 'installation-id-before.json', {'path': str(installation), 'sha256': digest(installation), 'contents_copied': False, 'utc': helper.now()})
    (FLOW / 'live-runs').mkdir(exist_ok=False)
    (FLOW / 'configs-live').mkdir(exist_ok=False)
    template = json.loads((FLOW / 'policy-preflight-config.json').read_text())
    for cid in EXPECTED_IDS:
        config = json.loads(json.dumps(template))
        config['prompt'] = str(snapshot / cid / 'task.md')
        config['run_dir'] = str(FLOW / 'live-runs' / cid)
        for probe in config['probes']:
            if probe['category'] == 'reference': probe['path'] = str(snapshot / cid / 'reference.md')
        config['probes'].append({'category': 'current_evaluator', 'path': str(MIRROR / 'cases/public' / cid / 'rubric.json')})
        save(FLOW / 'configs-live' / (cid + '.json'), config)
        helper.prepare(config)
        run = Path(config['run_dir'])
        shutil.copyfile(FLOW / 'runtime-policy-extension.json', run / 'runtime/policy-exceptions.json')
        shutil.copyfile(FLOW / 'network_probe.py', run / 'runtime/network-probe.py')
        assert (run / 'input/task.md').read_bytes() == (snapshot / cid / 'task.md').read_bytes()
    operator_files = [FLOW / name for name in (
        'gates.py', 'prepare_trial.py', 'run_cases.py', 'start_queue.py', 'probe_runs.py',
        'network_probe.py', 'runtime-policy-extension.json', 'model-inventory.json',
        'cli-inspection/identity.json', 'tools/prepare.py', 'tools/prepare_runtime.py', 'tools/probe.py')]
    prepared_files = []
    for cid in EXPECTED_IDS:
        run = FLOW / 'live-runs' / cid
        original = json.loads((run / 'runtime/prepared-hashes.json').read_text())
        names = [name for name in original if name != 'runtime/attempt-ledger.json']
        names += ['runtime/prepared-hashes.json', 'runtime/policy-exceptions.json', 'runtime/network-probe.py']
        prepared_files += [run / name for name in names]
    pretrial['operator_files'] = [{'path': p.relative_to(FLOW).as_posix(), 'sha256': digest(p)} for p in operator_files]
    pretrial['prepared_files'] = [{'path': p.relative_to(FLOW).as_posix(), 'sha256': digest(p)} for p in prepared_files]
    save(FLOW / 'pretrial-freeze.json', pretrial)
    print(json.dumps({'prepared': len(EXPECTED_IDS), 'pretrial_freeze_sha256': digest(FLOW / 'pretrial-freeze.json'), 'inference_started': False}))

if __name__ == '__main__':
    main()
