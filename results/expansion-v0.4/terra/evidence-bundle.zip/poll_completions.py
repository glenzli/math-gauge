#!/usr/bin/env python3
"""Accept completed runtime evidence without loading answer/reasoning text."""
from pathlib import Path
import hashlib
import importlib.util
import json

FLOW = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('runtime_helper', FLOW / 'tools/prepare_runtime.py')
helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)

def load(path):
    return json.loads(path.read_text())

def main():
    new = []
    for run in sorted((FLOW / 'live-runs').iterdir()):
        path = run / 'runtime/execution.json'
        if not path.exists(): continue
        execution = load(path)
        if not execution.get('finished_utc'): continue
        receipt_path = FLOW / 'receipts' / (run.name + '-runtime-acceptance.json')
        if receipt_path.exists(): continue
        audit = helper.audit(run)
        events = execution['events_summary']
        response = run / 'output/response.md'
        response_hash = hashlib.sha256(response.read_bytes()).hexdigest() if response.exists() else None
        checks = {
            'prepared_artifacts': audit['artifact_checks_passed'],
            'complete_policy_reports': audit['runtime_reports_complete'],
            'exit_zero': execution['exit_code'] == 0,
            'one_stdin_submission': execution['request_count'] == 1 and execution.get('stdin_write_calls') == 1 and execution.get('stdin_closed') is True,
            'one_completed_turn': events['event_types'].get('turn.completed') == 1,
            'no_tool_events': set(events['item_types']).issubset({'agent_message', 'reasoning', 'error'}) and execution['tool_mismatch'] is None,
            'expected_requested_configuration': execution['requested_model'] == 'gpt-6.1-terra' and execution['requested_effort'] == 'max',
            'actual_new_parent_executable': execution.get('parent_identity', {}).get('new_since_prelaunch_snapshot') is True,
            'policy_checked_before_stdin': bool(execution.get('pre_submission_policy_verified_utc') and execution['pre_submission_policy_verified_utc'] <= execution['request_utc'] and execution['parent_policy_probe']['report']['passed']),
            'worker_policy_checked': bool(execution['worker_records']) and all(row['policy_probe']['report']['passed'] for row in execution['worker_records']),
            'write_policy_checked': execution['pre_submission_write_policy']['passed'],
            'installation_identity_unchanged': execution['installation_id_content_unchanged'],
            'file_probe_passed': load(run / 'runtime/open-probe.json')['passed'],
            'network_probe_passed': load(run / 'runtime/network-probe.json')['passed'],
            'response_hash_matches': response_hash is not None and response_hash == execution.get('artifact_hashes', {}).get('output/response.md', {}).get('sha256'),
        }
        report = {
            'case_id': run.name, 'engineering_accepted': all(checks.values()), 'checks': checks,
            'response_path': str(response), 'response': execution.get('artifact_hashes', {}).get('output/response.md'),
            'parent_pid': execution['parent_pid'], 'worker_pids': execution['worker_pids'],
            'observed_model': execution['observed_model'], 'observed_effort': execution['observed_effort'],
            'event_types': events['event_types'], 'item_types': events['item_types'],
            'failure': execution['failure'], 'mathematical_review': None,
            'answer_text_loaded': False,
        }
        with receipt_path.open('x') as out:
            json.dump(report, out, indent=2); out.write('\n')
        new.append(report)
    print(json.dumps({'new_completions': new, 'mathematical_scoring_performed': False}, indent=2))

if __name__ == '__main__':
    main()
