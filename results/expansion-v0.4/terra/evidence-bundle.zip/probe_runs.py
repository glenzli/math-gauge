#!/usr/bin/env python3
"""Run actual OS opens/connects for every prepared case, without model calls."""
from pathlib import Path
import datetime
import json
import subprocess
import sys

FLOW = Path(__file__).resolve().parent
rows = []
for run in sorted((FLOW / 'live-runs').iterdir()):
    plan = json.loads((run / 'runtime/plan.json').read_text())
    python = str(Path(sys.executable).resolve())
    checks = []
    for name, args in [
        ('open-probe', [python, '-B', str(run / 'runtime/probe.py'), '--manifest', str(run / 'runtime/probes.json'), '--out', str(run / 'runtime/open-probe.json')]),
        ('network-probe', [python, '-B', str(run / 'runtime/network-probe.py'), str(run / 'runtime/network-probe.json')]),
    ]:
        argv = plan['argv'][:3] + args
        result = subprocess.run(argv, cwd=run, capture_output=True, timeout=30)
        for channel in ('stdout', 'stderr'):
            with (run / 'runtime' / (name + '.' + channel + '.txt')).open('xb') as out:
                out.write(getattr(result, channel))
        output = run / 'runtime' / (name + '.json')
        report = json.loads(output.read_text()) if output.exists() else None
        checks.append({'check': name, 'argv': argv, 'exit_code': result.returncode, 'passed': bool(report and report['passed'])})
    rows.append({'case_id': run.name, 'checks': checks, 'passed': all(row['passed'] for row in checks)})
    print(json.dumps({'case_id': run.name, 'passed': rows[-1]['passed']}), flush=True)
summary = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'cases': rows, 'passed': len(rows) == 10 and all(row['passed'] for row in rows), 'model_requests': 0}
with (FLOW / 'open-probe-summary.json').open('x') as out:
    json.dump(summary, out, indent=2); out.write('\n')
raise SystemExit(0 if summary['passed'] else 1)
