#!/usr/bin/env python3
"""Compact queue status without loading candidate answer or reasoning text."""
from pathlib import Path
import argparse
import collections
import json
import os

FLOW = Path(__file__).resolve().parent

def alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return None

def main():
    rows = []
    root = FLOW / 'live-runs'
    for run in sorted(root.iterdir()) if root.is_dir() else []:
        path = run / 'runtime/execution.json'
        if not path.exists():
            rows.append({'case_id': run.name, 'status': 'prepared-not-started'})
            continue
        execution = json.loads(path.read_text())
        row = {key: execution.get(key) for key in ('parent_pid', 'worker_pids', 'request_count', 'started_utc', 'request_utc', 'finished_utc', 'exit_code', 'elapsed_seconds', 'failure', 'observed_model', 'observed_effort')}
        row['case_id'] = run.name
        row['process_alive'] = alive(row['parent_pid']) if row['parent_pid'] else False
        events = collections.Counter()
        event_path = run / 'output/events.ndjson'
        if event_path.exists():
            with event_path.open() as stream:
                for line in stream:
                    try:
                        events[json.loads(line).get('type')] += 1
                    except (ValueError, TypeError):
                        events['unparseable'] += 1
        row['event_types'] = dict(events)
        response = run / 'output/response.md'
        row['response_bytes'] = response.stat().st_size if response.exists() else None
        row['status'] = 'failed' if row['failure'] else ('completed' if row['finished_utc'] else 'running')
        rows.append(row)
    print(json.dumps({'release_present': (FLOW / 'inference-release.json').exists(), 'cases': rows, 'answer_text_loaded': False}, indent=2))

if __name__ == '__main__':
    main()
