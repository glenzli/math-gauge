#!/usr/bin/env python3
"""Reviewable per-frozen-case configurations, without sessions or inference."""
from pathlib import Path
import hashlib
import json

FLOW = Path(__file__).resolve().parent
MIRROR = FLOW.parent / 'integration'
state = json.loads((FLOW / 'integration-state.json').read_text())
template = json.loads((FLOW / 'policy-preflight-config.json').read_text())
out = FLOW / 'config-templates'
out.mkdir(exist_ok=True)
records = []
for cid in sorted(state['frozen_cases']):
    case = MIRROR / 'cases/public' / cid
    receipt = json.loads((FLOW / state['frozen_cases'][cid]['receipt']).read_text())
    actual = hashlib.sha256((case / 'task.md').read_bytes()).hexdigest()
    if actual != receipt['frozen_inputs']['task.md']:
        raise RuntimeError('Frozen task changed: ' + cid)
    config = json.loads(json.dumps(template))
    config['prompt'] = str(case / 'task.md')
    config['run_dir'] = str(FLOW / 'live-runs' / cid)
    for probe in config['probes']:
        if probe['category'] == 'reference': probe['path'] = str(case / 'reference.md')
    config['probes'].append({'category': 'current_evaluator', 'path': str(case / 'rubric.json')})
    encoded = (json.dumps(config, ensure_ascii=False, indent=2) + '\n').encode()
    path = out / (cid + '.json')
    if path.exists() and path.read_bytes() != encoded:
        raise RuntimeError('Review template would change: ' + cid)
    path.write_bytes(encoded)
    records.append({'case_id': cid, 'task_sha256': actual, 'config_sha256': hashlib.sha256(encoded).hexdigest()})
record = {'schema': 'math-gauge.readiness-configurations/v1', 'cases': records, 'pending_cases': state['pending_cases'],
          'status': 'templates-only-no-model-session', 'model_requests': 0,
          'not_final_pretrial_plan': True, 'final_preparation_uses_identical_task_bytes_from_locked_evaluator_snapshot': True}
(FLOW / 'configuration-readiness.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'prepared_templates': len(records), 'pending': state['pending_cases'], 'sessions_started': 0}))
