#!/usr/bin/env python3
"""Prepare a non-inference policy probe using the frozen R020 task bytes."""
from pathlib import Path
import importlib.util
import json
import shutil
import sys

FLOW = Path(__file__).resolve().parent
ROOT = FLOW.parent
spec = importlib.util.spec_from_file_location('runtime_prepare', FLOW / 'tools/prepare_runtime.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)

def save(path, value):
    with path.open('x', encoding='utf-8') as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write('\n')

history = Path('/Users/g4i/.codex/sessions/2026/06/05/rollout-2026-06-05T14-34-57-019e967d-f3d7-7c50-acb1-53e6b1f07c97.jsonl.zst')
assert history.is_file()
config = {
    'schema': 'math-gauge.isolated-cli/v1', 'client': 'codex',
    'cli_identity': str(FLOW / 'cli-inspection/identity.json'),
    'prompt': str(ROOT / 'integration/cases/public/MG-R020/task.md'),
    'run_dir': str(FLOW / 'policy-preflight'),
    'model': 'gpt-6.1-terra', 'effort': 'max',
    'deny_read_roots': ['/Users/g4i', '/System/Volumes/Data/Users/g4i', '/private/tmp', '/private/var/folders', '/Volumes/Data'],
    'read_exceptions': [
        {'path': '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex', 'kind': 'literal', 'purpose': 'Selected CLI executable only'},
        {'path': '/Users/g4i/.codex/auth.json', 'kind': 'literal', 'purpose': 'Existing login only; no contents copied or logged'},
        {'path': '/Users/g4i/.codex/installation_id', 'kind': 'literal', 'purpose': 'Exact non-history installation identity required at startup; unchanged hash checked'}],
    'credential_links': [],
    'probes': [
        {'category': 'reference', 'path': str(ROOT / 'integration/cases/public/MG-R020/reference.md')},
        {'category': 'history', 'path': str(history)},
        {'category': 'prior_run', 'path': '/Users/g4i/lab/math-gauge/results/full-lean-terra/answers/MG-R001.md'},
        {'category': 'memory', 'path': '/Users/g4i/.codex/memories/MEMORY.md'},
        {'category': 'global_config', 'path': '/Users/g4i/.codex/config.toml'},
        {'category': 'global_rules', 'path': '/Users/g4i/.codex/AGENTS.md'},
        {'category': 'other_workspace', 'path': '/Users/g4i/lab/oet-dev/the-operator-evolution-theory/formal-oet/lake-manifest.json'},
        {'category': 'global_state', 'path': '/Users/g4i/.codex/state_5.sqlite'},
        {'category': 'data_volume_alias', 'path': '/System/Volumes/Data/Users/g4i/lab/math-gauge/cases/public/MG-R001/reference.md'},
        {'category': 'prior_temporary_answer', 'path': '/private/tmp/math-gauge-full-lean-20261029/flow/live-runs/MG-R001/output/response.md'},
        {'category': 'other_task', 'path': str(ROOT / 'integration/cases/public/MG-R001/task.md')},
    ],
}
save(FLOW / 'policy-preflight-config.json', config)
helper.prepare(config)
run = Path(config['run_dir'])
shutil.copyfile(FLOW / 'runtime-policy-extension.json', run / 'runtime/policy-exceptions.json')
shutil.copyfile(FLOW / 'network_probe.py', run / 'runtime/network-probe.py')
save(run / 'runtime/preflight-scope.json', {'model_process_started': False, 'model_requests': 0, 'purpose': 'Actual file-open and connect policy checks only. R020 task is locally copied for the positive read hash; no stdin is submitted to a CLI.'})
print(json.dumps({'run': str(run), 'model_requests': 0}))
