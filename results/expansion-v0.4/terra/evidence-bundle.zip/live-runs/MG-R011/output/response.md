可以直接用有限问题的投影构造全局投影；关键是有限问题的最优值之差控制投影点之间的距离。

首先，每个 \(C_F\) 都是非空闭凸集，因此有限问题的最小点存在且唯一。为完整起见，若 \(A\) 是任意非空闭凸集，令 \(\delta=\inf_{z\in A}\|x-z\|\)，取极小序列 \(z_n\in A\)。由平行四边形恒等式及 \((z_n+z_m)/2\in A\)，
\[
\|z_n-z_m\|^2
\le 2\bigl(\|x-z_n\|^2-\delta^2\bigr)
 +2\bigl(\|x-z_m\|^2-\delta^2\bigr).
\]
故 \((z_n)\) 是 Cauchy 列，极限属于 \(A\) 并达到最小值；同一不等式也给出最小点的唯一性。

固定 \(x\in H\)，简记
\[
p_F=P_Fx,\qquad d_F=\|x-p_F\|.
\]
对 \(z\in C_F\) 和 \(0\le t\le1\)，点 \(p_F+t(z-p_F)\) 属于 \(C_F\)。利用 \(p_F\) 的最优性并令 \(t\downarrow0\)，得到
\[
\langle x-p_F,z-p_F\rangle\le0.
\]
展开平方，因而有
\[
\|x-z\|^2\ge d_F^2+\|z-p_F\|^2
\qquad(z\in C_F). \tag{1}
\]
特别地，若 \(F\subseteq G\)，则 \(p_G\in C_F\)，所以
\[
\|p_G-p_F\|^2\le d_G^2-d_F^2. \tag{2}
\]

由假设，\(d_F\le\|x\|+B\)；而 \(F\subseteq G\) 时 \(d_F\le d_G\)。因此
\[
D:=\sup_{F\subseteq I,\ F\text{ 有限}}d_F^2
\le(\|x\|+B)^2<\infty.
\]

对每个 \(n\ge1\)，选有限集 \(E_n\) 使 \(D-d_{E_n}^2<1/n^2\)，并令
\[
F_n=\bigcup_{k=1}^n E_k.
\]
则 \(F_n\subseteq F_{n+1}\)，且 \(D-d_{F_n}^2<1/n^2\)。由 (2)，当 \(m\ge n\) 时，
\[
\|p_{F_m}-p_{F_n}\|^2
\le d_{F_m}^2-d_{F_n}^2
\le D-d_{F_n}^2<\frac1{n^2}.
\]
故 \(p_{F_n}\) 在范数中收敛到某个 \(p\in H\)。

这个序列未必包含每个指标，但它的极限仍满足所有约束。事实上，任取 \(i\in I\)，由 (2)，
\[
\|p_{F_n\cup\{i\}}-p_{F_n}\|^2
\le D-d_{F_n}^2<\frac1{n^2}.
\]
所以 \(p_{F_n\cup\{i\}}\to p\)。这些点都属于闭集 \(C_i\)，故 \(p\in C_i\)。由于 \(i\) 任意，**\(p\in C\)**。同时，
\[
\|x-p\|^2
=\lim_{n\to\infty}d_{F_n}^2
=D. \tag{3}
\]

对任意 \(z\in C\)，都有 \(z\in C_{F_n}\)。在有限问题的变分不等式中令 \(n\to\infty\)，得到
\[
\langle x-p,z-p\rangle\le0.
\]
于是
\[
\|x-z\|^2\ge \|x-p\|^2+\|z-p\|^2
\qquad(z\in C). \tag{4}
\]
这说明 \(p\) 是全约束问题的唯一最小点，也说明它与上述有限集的选择无关。定义 \(Px=p\)，便得到所求映射 \(P:H\to C\)。由 (3)，全局最优值满足
\[
\boxed{\;
\operatorname{dist}(x,C)^2
=\sup_{F\subseteq I,\ F\text{ 有限}}
  \operatorname{dist}(x,C_F)^2
\;}
\]
等价地，\(\operatorname{dist}(x,C)=\sup_F\operatorname{dist}(x,C_F)\)。特别地，取 \(x=0\) 可知 \(C\) 中存在范数不超过 \(B\) 的点。

还可以从 (1) 得到整个有限子集网的收敛。因为 \(Px\in C\subseteq C_F\)，
\[
\boxed{\;
\|P_Fx-Px\|^2
\le \operatorname{dist}(x,C)^2-d_F^2.
\;} \tag{5}
\]
按包含关系增大 \(F\) 时，\(d_F^2\) 单调趋于其上确界 \(D=\operatorname{dist}(x,C)^2\)。因此 (5) 的右侧趋于零，即
\[
P_Fx\longrightarrow Px\quad\text{在范数中}.
\]

最后，令 \(p=Px\)、\(q=Py\)。分别对 \(x,p,z=q\) 和 \(y,q,z=p\) 使用全局变分不等式，并相加，得到
\[
\|p-q\|^2\le \langle x-y,p-q\rangle
\le \|x-y\|\,\|p-q\|.
\]
若 \(p\ne q\)，消去 \(\|p-q\|\)；若 \(p=q\)，结论显然。因此
\[
\boxed{\|Px-Py\|\le\|x-y\|\qquad(x,y\in H).}
\]