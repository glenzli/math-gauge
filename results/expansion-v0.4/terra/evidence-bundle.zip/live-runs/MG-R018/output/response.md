相容记录恰好对应于 \(X\) 上的**超滤子**。这个对应对集合映射自然，并把题中的观察求值所确定的单子识别为通常的超滤子单子。特别地，所有相容记录都唯一地来自 \(X\) 中的点，当且仅当 \(X\) 有限；这里也包括空集。

记 \(\operatorname{Uf}(X)\) 为 \(X\) 上全部超滤子的集合。对 \(S\subseteq X\)，令 \(\chi_S:X\to\mathbf 2=\{0,1\}\) 为特征函数。所需的典范双射是

\[
\Phi_X:R(X)\longrightarrow\operatorname{Uf}(X),\qquad
\Phi_X(r)=\{S\subseteq X:r_{\mathbf 2}(\chi_S)=1\}.
\]

反过来，若 \(p\in\operatorname{Uf}(X)\)，则对应记录 \(r^p\) 由下式确定：

\[
r^p_A(f)=\text{唯一满足 }f^{-1}(\{a\})\in p\text{ 的 }a\in A.
\tag{1}
\]

对映射 \(h:X\to Y\)，该分类下的函子作用为超滤子的推前：

\[
\operatorname{Uf}(h)(p)
=\{T\subseteq Y:h^{-1}(T)\in p\}.
\tag{2}
\]

单位是主超滤子

\[
x\longmapsto p_x:=\{S\subseteq X:x\in S\}.
\tag{3}
\]

若 \(\mathscr P\) 是 \(\operatorname{Uf}(X)\) 上的超滤子，则乘法为

\[
\mathscr P\longmapsto
\left\{S\subseteq X:
\widehat S:=\{p\in\operatorname{Uf}(X):S\in p\}\in\mathscr P
\right\}.
\tag{4}
\]

下面证明这些断言，并直接验证观察求值所要求的公式和单子律。

首先，\(R(X)\) 确实是集合。令

\[
\mathcal F_{\mathcal U}=\{A\in\mathcal U:A\text{ 有限}\},\qquad
I_X=\{(A,f):A\in\mathcal F_{\mathcal U},\ f:X\to A\}.
\]

由于 \(\mathcal U\) 是集合，\(I_X\) 是集合。例如，它是
\(\mathcal F_{\mathcal U}\times\mathcal P(X\times\mathcal U)\) 的子集。把记录写成函数 \((A,f)\mapsto r_A(f)\)，则 \(R(X)\) 可由分离公理构造为 \(\mathcal U^{I_X}\) 的子集。

观察求值 \(e^X_{A,f}:R(X)\to A\) 共同区分记录：两个记录相等，当且仅当它们在每个 \((A,f)\) 上的求值相等。此外，相容条件正是

\[
e^X_{B,g\circ f}=g\circ e^X_{A,f}.
\tag{5}
\]

由于 \(\mathbb N\in\mathcal U\)，有限集合 \(\mathbf 1,\mathbf 2\) 以及 \(\mathbf 2\times\mathbf 2\) 都可用作测试集合。对记录 \(r\)，写

\[
\theta_r(S)=r_{\mathbf 2}(\chi_S)\qquad(S\subseteq X).
\]

利用从 \(\mathbf 1\) 到 \(\mathbf 2\) 的两个常值映射、\(\mathbf 2\) 上的取反映射，以及 \(\mathbf 2\times\mathbf 2\) 的投影和合取映射，逐一应用相容条件，得到

\[
\begin{aligned}
\theta_r(X)&=1,&\theta_r(\varnothing)&=0,\\
\theta_r(X\setminus S)&=1-\theta_r(S),&
\theta_r(S\cap T)&=\theta_r(S)\theta_r(T).
\end{aligned}
\tag{6}
\]

因此 \(\theta_r^{-1}(1)\) 含 \(X\) 而不含 \(\varnothing\)，对有限交封闭，并且对每个 \(S\subseteq X\) 恰好含 \(S\) 与 \(X\setminus S\) 之一。它也向上封闭：若 \(S\subseteq T\) 且 \(\theta_r(S)=1\)，则由 \(S=S\cap T\) 和 (6) 得 \(\theta_r(T)=1\)。这证明了 \(\Phi_X(r)\) 是超滤子。

反之，设 \(p\) 是 \(X\) 上的超滤子。任意映射 \(f:X\to A\) 的纤维

\[
\{f^{-1}(\{a\}):a\in A\}
\]

构成 \(X\) 的有限分割，其中恰有一块属于 \(p\)。至多一块属于 \(p\)，因为不同纤维不交；至少一块属于 \(p\)，因为否则所有纤维的补集都属于 \(p\)，它们的有限交为空集。故 (1) 良定义。这一论证也处理了空测试集合：若 \(p\) 存在，则 \(X\ne\varnothing\)，所以不存在 \(X\to\varnothing\) 的映射。

若 \(a=r^p_A(f)\) 且 \(g:A\to B\)，则

\[
f^{-1}(\{a\})\subseteq(g\circ f)^{-1}(\{g(a)\}).
\]

由超滤子的向上封闭性，右侧属于 \(p\)，故
\(r^p_B(g\circ f)=g(a)\)。于是 \(r^p\) 是相容记录。

这两个构造互逆。的确，由特征函数直接得到
\(\Phi_X(r^p)=p\)。另一方面，对 \(a\in A\)，令
\(\delta_a:A\to\mathbf 2\) 为 \(\{a\}\) 的特征函数，则

\[
\begin{aligned}
f^{-1}(\{a\})\in\Phi_X(r)
&\iff r_{\mathbf 2}(\delta_a\circ f)=1\\
&\iff \delta_a(r_A(f))=1\\
&\iff r_A(f)=a.
\end{aligned}
\]

所以 (1) 从 \(\Phi_X(r)\) 恢复了 \(r\)，证明了 \(\Phi_X\) 是双射。

现在直接构造函子。对任意 \(h:X\to Y\)，定义

\[
(R(h)(r))_A(f)=r_A(f\circ h),
\qquad f:Y\to A.
\tag{7}
\]

右侧对测试映射的相容性从 \(r\) 的相容性立即得到，故 \(R(h)(r)\in R(Y)\)。恒等映射和复合映射的函子律也由 (7) 直接成立。等价地，\(R(h)\) 是由下列观察公式唯一确定的映射：

\[
e^Y_{A,f}\circ R(h)=e^X_{A,f\circ h}.
\tag{8}
\]

对于 \(T\subseteq Y\)，有

\[
\begin{aligned}
T\in\Phi_Y(R(h)(r))
&\iff r_{\mathbf 2}(\chi_T\circ h)=1\\
&\iff h^{-1}(T)\in\Phi_X(r).
\end{aligned}
\]

这证明 \(\Phi\) 对 \(h\) 自然，并给出推前公式 (2)。

单位定义为点值记录：

\[
(\eta_X(x))_A(f)=f(x).
\tag{9}
\]

它显然相容，且满足 \(e^X_{A,f}\circ\eta_X=f\)。由观察求值共同区分记录，这一公式唯一确定 \(\eta_X\)。在 \(\Phi_X\) 下，(9) 正是主超滤子 (3)。

对 \(Q\in R(R(X))\)，定义乘法

\[
(\mu_X(Q))_A(f)=Q_A(e^X_{A,f}).
\tag{10}
\]

这是良定义的相容记录：由 (5) 和 \(Q\) 的相容性，

\[
g\bigl(Q_A(e^X_{A,f})\bigr)
=Q_B(g\circ e^X_{A,f})
=Q_B(e^X_{B,g\circ f}).
\]

因此 (10) 给出映射 \(\mu_X:R(R(X))\to R(X)\)，并满足

\[
e^X_{A,f}\circ\mu_X
=e^{R(X)}_{A,e^X_{A,f}}.
\tag{11}
\]

观察求值共同区分记录，故 (11) 也唯一确定 \(\mu_X\)。

\(\eta\) 和 \(\mu\) 都自然。单位的自然性由 (8) 和
\(e^X_{A,f}\circ\eta_X=f\) 得到。对乘法，若 \(Q\in R(R(X))\)、\(f:Y\to A\)，则

\[
\begin{aligned}
e^Y_{A,f}\bigl(\mu_Y(R(R(h))(Q))\bigr)
&=Q_A(e^Y_{A,f}\circ R(h))\\
&=Q_A(e^X_{A,f\circ h})\\
&=e^Y_{A,f}\bigl(R(h)(\mu_X(Q))\bigr).
\end{aligned}
\]

故 \(\mu_Y\circ R(R(h))=R(h)\circ\mu_X\)。

单子律同样逐项验证。对 \(r\in R(X)\)，由 (9)、(10) 得

\[
\begin{aligned}
e^X_{A,f}\bigl(\mu_X(\eta_{R(X)}(r))\bigr)
&=e^X_{A,f}(r),\\
e^X_{A,f}\bigl(\mu_X(R(\eta_X)(r))\bigr)
&=r_A(e^X_{A,f}\circ\eta_X)
=e^X_{A,f}(r).
\end{aligned}
\]

所以两个单位律成立。对 \(W\in R^3(X)\)，结合 (8) 和 (11)，复合

\[
\mu_X\circ\mu_{R(X)}
\quad\text{与}\quad
\mu_X\circ R(\mu_X)
\]

经任意 \(e^X_{A,f}\) 求值后都等于

\[
W_A\!\left(e^{R(X)}_{A,e^X_{A,f}}\right).
\]

因此结合律成立。

最后核对超滤子乘法 (4)。将 \(Q\in R(R(X))\) 在两层都通过 \(\Phi\) 识别为 \(\operatorname{Uf}(X)\) 上的超滤子 \(\mathscr P\)。对 \(S\subseteq X\)，由 (10)，

\[
\begin{aligned}
S\in\Phi_X(\mu_X(Q))
&\iff Q_{\mathbf 2}(e^X_{\mathbf 2,\chi_S})=1\\
&\iff \{r\in R(X):e^X_{\mathbf 2,\chi_S}(r)=1\}
       \in\Phi_{R(X)}(Q).
\end{aligned}
\]

通过 \(\Phi_X\)，最后出现的集合正对应于 \(\widehat S\)，故得到 (4)。这也表明所得单子在典范同构意义下不依赖于所选的测试宇宙 \(\mathcal U\)。

剩下判断何时所有记录都是点值记录。每个 \(\eta_X\) 都是单射：若 \(x\ne y\)，则测试 \(\chi_{\{x\}}\) 区分 \(\eta_X(x)\) 与 \(\eta_X(y)\)。

若 \(X\) 有限且非空，超滤子在由单点集组成的有限分割中恰好选出一个 \(\{x\}\)；向上封闭性随即表明它就是 \(p_x\)。若 \(X=\varnothing\)，则不存在超滤子，也不存在相容记录：例如，唯一的 \(\varnothing\to\varnothing\) 使得 \(r_\varnothing\) 必须从一个单点集合映入空集。因此有限 \(X\) 的每个记录都唯一来自一个点。

若 \(X\) 无限，余有限集合构成真滤子

\[
\mathcal F=\{S\subseteq X:X\setminus S\text{ 有限}\}.
\]

由 Zorn 引理，它可扩张为极大真滤子 \(p\)。这个极大滤子是超滤子：若 \(B\notin p\)，而 \(p\) 中没有集合与 \(B\) 不交，则加入 \(B\) 生成的滤子仍是真滤子，违背极大性；所以某个 \(F\in p\) 与 \(B\) 不交，从而 \(X\setminus B\in p\)。又因为 \(p\) 含每个 \(X\setminus\{x\}\)，它不含任何单点集，因而不是主超滤子。对应的记录就不是任何点的求值记录。

以上构造在 ZFC 的全体集合上成立。若题中的 \(\mathcal V\) 是包含 \(\mathcal U\) 的 Grothendieck 宇宙，其闭包性质还保证 \(R(X)\in\mathcal V\)，所以所得结构是 \(\mathcal V\) 中集合范畴上的单子；若 \(\mathcal V\) 仅表示任意集合，则这种闭包不能只由 \(\mathcal U,X\in\mathcal V\) 推出。