该结论不成立：两个满足题设提升性质的 profinite 空间，其乘积未必满足该性质。反例取
\[
P_1=P_2=\beta\mathbb N,
\]
其中 \(\beta\mathbb N\) 是自然数集合上所有超滤子的空间。

先验证这两个空间满足题设。对 \(A\subseteq\mathbb N\)，记
\[
\widehat A=\{\mathcal U\in\beta\mathbb N:A\in\mathcal U\}.
\]
这些集合构成一组既开又闭的基。不同的超滤子可由这样的基集合分离；紧性则由 ZFC 中的超滤子引理得到：如果一族基开集没有有限子覆盖，其对应集合的补集具有有限交性质，可扩充为一个不被这族开集覆盖的超滤子。因此 \(\beta\mathbb N\) 是 profinite 空间。

把 \(n\in\mathbb N\) 等同于由 \(n\) 生成的主超滤子。这样 \(\mathbb N\) 是 \(\beta\mathbb N\) 中的稠密离散子空间，且每个单点 \(\{n\}\) 都是开集。

我们还需要以下延拓事实：若 \(K\) 是紧 Hausdorff 空间，任意映射 \(h:\mathbb N\to K\) 都能连续延拓到 \(\beta\mathbb N\)。具体地，对超滤子 \(\mathcal U\)，令 \(\bar h(\mathcal U)\) 为 \(h\) 沿 \(\mathcal U\) 的极限。此极限存在，因为
\[
\left\{\overline{h(A)}:A\in\mathcal U\right\}
\]
具有有限交性质；它唯一，因为 \(K\) 是 Hausdorff 的。若 \(\bar h(\mathcal U)\in O\)，利用紧 Hausdorff 空间的正则性，取开集 \(V\) 使
\(\bar h(\mathcal U)\in V\subseteq\overline V\subseteq O\)。于是
\[
A=\{n:h(n)\in V\}\in\mathcal U,
\qquad
\bar h(\widehat A)\subseteq\overline V\subseteq O,
\]
故 \(\bar h\) 连续。

现在给定题设中的满射 \(q:Y\to Z\) 和映射 \(f:\beta\mathbb N\to Z\)。由选择公理，对每个 \(n\) 选取 \(y_n\in Y\)，使 \(q(y_n)=f(n)\)。将 \(n\mapsto y_n\) 连续延拓为 \(g:\beta\mathbb N\to Y\)。映射 \(qg\) 和 \(f\) 在稠密子集 \(\mathbb N\) 上相等，因而在整个 \(\beta\mathbb N\) 上相等。所以 \(\beta\mathbb N\) 满足题设提升性质。

下面构造其乘积上不能提升的映射。设
\[
X=\beta\mathbb N\times\beta\mathbb N,\qquad
U=\{(n,m)\in\mathbb N^2:n<m\},\qquad
C=\overline U.
\]
由于 \(\mathbb N^2\) 中的每个单点都是 \(X\) 的开集，\(U\) 是开集。我们证明 \(C\) 不是开集。

取一个非主超滤子 \(\mathcal P\)；它存在，因为余有限滤子可扩充为超滤子。对于任意 \(A,B\in\mathcal P\)，交集 \(A\cap B\) 都是无限集，因此含有 \(n<m\)。由此可见，\((\mathcal P,\mathcal P)\) 的每个基本邻域 \(\widehat A\times\widehat B\) 都与 \(U\) 相交，所以
\[
(\mathcal P,\mathcal P)\in C.
\]
同理，它的每个基本邻域也与
\[
V=\{(n,m)\in\mathbb N^2:n>m\}
\]
相交。而 \(V\) 的每个点都是 \(X\) 中与 \(U\) 不相交的开单点，故 \(V\subseteq X\setminus C\)。于是
\[
(\mathcal P,\mathcal P)\in C\cap\overline{X\setminus C},
\]
这证明 \(C\) 不是开集。

令 \(D=X\setminus U\)，并构造有限不交并
\[
Y=(C\times\{0\})\sqcup(D\times\{1\}),\qquad Z=X.
\]
这里 \(C,D\) 都是 \(X\) 的闭子空间，所以 \(Y,Z\) 都是 profinite 空间。定义
\[
q:Y\longrightarrow X,\qquad q(x,i)=x,
\qquad\text{以及}\qquad f=\operatorname{id}_X.
\]
由于 \(C\cup D=X\)，映射 \(q\) 是连续满射。

假设存在连续提升 \(g:X\to Y\)，满足 \(qg=\operatorname{id}_X\)。则
\[
A=g^{-1}(C\times\{0\})
\]
是 \(X\) 的既开又闭子集。由 \(qg=\operatorname{id}_X\) 得 \(A\subseteq C\)；又因为 \(U\cap D=\varnothing\)，对 \(x\in U\)，其提升只能落在 \(C\times\{0\}\) 中，所以 \(U\subseteq A\)。由于 \(A\) 是闭集，
\[
C=\overline U\subseteq A\subseteq C.
\]
因此 \(A=C\)，这与 \(C\) 不是开集矛盾。

所以此处的 \(f=\operatorname{id}_X\) 没有连续提升，题目要求的结论在 ZFC 下不成立。