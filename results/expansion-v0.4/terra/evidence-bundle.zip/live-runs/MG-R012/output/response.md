定义从固定记录出发的路径势
\[
f(z)=\sup\left\{
\sum_{j=0}^{n-1}y_j(x_{j+1}-x_j)+y_n(z-x_n):
\begin{array}{l}
n\ge 0,\quad (x_0,y_0)=(\bar x,\bar y),\\
(x_j,y_j)\in\Gamma\quad(1\le j\le n)
\end{array}
\right\}.
\]
当 \(n=0\) 时，求和为空，相应的表达式是 \(\bar y(z-\bar x)\)。因此取上确界的集合非空，且
\[
f(z)\ge \bar y(z-\bar x)>-\infty.
\]

每条路径对应的表达式都是连续仿射函数：其中 \(y_n\in E'\)，而其余部分是常数。所以，它们的逐点上确界 \(f\) 是凸函数，也是下半连续函数。这里不需要对 \(E\) 作局部凸或 Hausdorff 假设。

循环单调性给出归一化条件。对于任意路径，将其终点接回 \(\bar x\)，便有
\[
\sum_{j=0}^{n-1}y_j(x_{j+1}-x_j)
+y_n(\bar x-x_n)\le 0.
\]
因此 \(f(\bar x)\le 0\)；取 \(n=0\) 又得到 \(f(\bar x)\ge0\)。故
\[
f(\bar x)=0,
\]
特别地，\(f\) 是正规函数。

接下来固定任意 \((x,y)\in\Gamma\)。对于定义 \(f\) 所用的任意路径，在其后附上记录 \((x,y)\)，再接回 \((\bar x,\bar y)\)。循环单调性给出
\[
\sum_{j=0}^{n-1}y_j(x_{j+1}-x_j)
+y_n(x-x_n)+y(\bar x-x)\le0.
\]
对路径取上确界可得
\[
f(x)\le y(x-\bar x)<+\infty.
\]
另一方面，对任意 \(z\in E\)，在同一条路径后附上 \((x,y)\)，便得到定义 \(f(z)\) 的一个候选值：
\[
\sum_{j=0}^{n-1}y_j(x_{j+1}-x_j)
+y_n(x-x_n)+y(z-x).
\]
对原路径取上确界，得到
\[
f(z)\ge f(x)+y(z-x)\qquad(z\in E).
\]
结合 \(f(x)<+\infty\)，这正说明 \(y\in\partial f(x)\)。所以 \(f\) 满足所有要求。

最后证明逐点最小性。设 \(g:E\to\mathbb R\cup\{+\infty\}\) 是任意满足
\[
g(\bar x)=0,\qquad
(x,y)\in\Gamma\Longrightarrow y\in\partial g(x)
\]
的函数。对任意定义 \(f\) 时所用的路径，逐次应用次梯度不等式，得到
\[
g(x_{j+1})\ge g(x_j)+y_j(x_{j+1}-x_j)
\quad(0\le j<n),
\]
以及
\[
g(z)\ge g(x_n)+y_n(z-x_n).
\]
这些记录点上的 \(g\) 值均有限，因为相应次梯度非空。将不等式相加并利用 \(g(x_0)=0\)，便得
\[
g(z)\ge
\sum_{j=0}^{n-1}y_j(x_{j+1}-x_j)+y_n(z-x_n).
\]
对所有路径取上确界，得到 \(g(z)\ge f(z)\) 对每个 \(z\in E\) 成立。因此 \(f\) 是所求函数类中的逐点最小元素。

若另有一个逐点最小的合格函数 \(h\)，由于 \(f\) 和 \(h\) 都合格，分别由它们的最小性得到 \(f\le h\) 与 \(h\le f\)。故 \(h=f\)，逐点最小函数唯一。