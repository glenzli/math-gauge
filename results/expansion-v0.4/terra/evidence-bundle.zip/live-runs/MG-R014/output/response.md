设 \(V=k^{(I)}\)，并记 \(e_i\in V\) 为第 \(i\) 个标准基向量。对 \(v\in V\) 和 \(x\in k^I\)，写

\[
\langle v,x\rangle=\sum_{i\in I}v(i)x_i.
\]

这给出自然同构 \(k^I\simeq V^*=\operatorname{Hom}_k(V,k)\)。以下所有求和均因支撑有限而有意义。

先把给定方程整理为两个线性映射：

\[
T:k^{(J)}\longrightarrow V,\qquad T(c)=\sum_{j\in J}c_j a_j,
\]
\[
h:k^{(J)}\longrightarrow k,\qquad h(c)=\sum_{j\in J}c_j b_j.
\]

若 \(T(c)=0\)，对 \(c\) 支撑中的有限个方程取一个共同解，便得 \(h(c)=0\)。因此 \(\ker T\subseteq\ker h\)，从而有良定义的线性泛函

\[
R:=\operatorname{im}T\subseteq V,\qquad
\beta:R\longrightarrow k,\qquad \beta(T(c))=h(c).
\]

这对 \((R,\beta)\) 完全由给定系数和常数确定。原方程组恰好要求对应的 \(f_x\in V^*\) 满足

\[
f_x|_R=\beta.
\]

在 ZFC 中，取 \(R\) 的一组基并将其扩充为 \(V\) 的一组基；令扩充出的基向量上的值为 \(0\)，即可把 \(\beta\) 延拓成 \(f_0\in V^*\)。于是

\[
x_i^0=f_0(e_i)\qquad(i\in I)
\]

是一个整体解。令 \(W=V/R\)，商映射为 \(q:V\to W\)，则所有解无重复地写成

\[
\boxed{\quad
x_i=f_0(e_i)+\lambda(q(e_i))
\quad(i\in I),\qquad \lambda\in W^*.
\quad}
\]

特别地，题设的有限可解性、条件 \(\ker T\subseteq\ker h\) 和整体可解性彼此等价。

这也给出解集的代数分类：非空的此类方程解集与各对 \((R,\beta)\) 一一对应，其中 \(R\leq V\)，\(\beta\in R^*\)。任意这样一对都可由方程

\[
\langle r,x\rangle=\beta(r)\qquad(r\in R)
\]

实现；而由解集可唯一恢复它们，因为

\[
R=\{v\in V:\langle v,x\rangle\text{ 在 }\mathcal S\text{ 上为常数}\},
\]

该常数就是 \(\beta(v)\)。确实，若 \(v\notin R\)，可在 \(V/R\) 上取一个在 \(q(v)\) 处值为 \(1\) 的线性泛函，由此得到两个在 \(v\) 处取值不同的解。因此，所有有限支撑的线性方程后果，恰好是 \(\langle r,x\rangle=\beta(r)\)，其中 \(r\in R\)。

对任意 \(A\subseteq I\)，把 \(k^{(A)}\) 视为子空间 \(V_A\leq V\)，并把 \(y\in k^A\) 视为 \(V_A\) 上的线性泛函。坐标像为

\[
\boxed{\quad
\pi_A(\mathcal S)
=
\{y\in k^A:\langle r,y\rangle=\beta(r)
\text{ 对每个 }r\in R\cap V_A\}.
\quad}
\]

用原数据直接写，这要求：对每个 \(c\in k^{(J)}\)，只要

\[
\sum_{j\in J}c_j a_j(i)=0\qquad(i\notin A),
\]

就有

\[
\sum_{i\in A}\left(\sum_{j\in J}c_j a_j(i)\right)y_i
=
\sum_{j\in J}c_j b_j.
\]

也就是说，先对有限多个原方程作线性组合，消去 \(I\setminus A\) 中的坐标；所得方程给出了像的全部条件。

为证明充分性并描述纤维，设 \(y\) 满足这些条件，在 \(D_A:=R+V_A\) 上定义

\[
\gamma_y(r+u)=\beta(r)+\langle u,y\rangle
\qquad(r\in R,\ u\in V_A).
\]

像的条件正好保证这个定义与分解方式无关。将 \(\gamma_y\) 延拓到 \(V\)，便得到一个限制为 \(y\) 的整体解。因此，不满足上述条件的 \(y\) 的纤维为空；满足条件时，

\[
\pi_A^{-1}(y)
=
\{f\in V^*:f|_{D_A}=\gamma_y\}.
\]

若 \(f_y\) 是其中任意一个延拓，则这个纤维是仿射空间

\[
\boxed{\quad
f_y+\operatorname{Hom}_k(V/(R+V_A),k).
\quad}
\]

这里商空间上的泛函通过商映射拉回到 \(V\)。因此所有非空纤维都有同一个平移空间。若记 \(U_A=q(V_A)\leq W\)，则 \(V/(R+V_A)\simeq W/U_A\)，而像本身是以 \(U_A^*\) 为平移空间的仿射空间。

这些公式立即分类了整个投影：

\[
\begin{array}{c|c}
\text{性质}&\text{充要条件}\\ \hline
\pi_A\text{ 满射到 }k^A&R\cap V_A=\{0\}\\
\pi_A\text{ 单射}&R+V_A=V\\
\pi_A\text{ 双射}&V=R\oplus V_A
\end{array}
\]

例如，若 \(R\cap V_A\ne0\)，其中一个非零向量给出 \(A\) 上不可违背的方程，所以像不是整个 \(k^A\)。若 \(R+V_A\ne V\)，商空间上存在非零线性泛函，因而每个非空纤维都不止一个元素。

更具体地，第 \(i\) 个坐标能否由 \(A\) 上的坐标恢复，有如下完全判据：

\[
\boxed{\quad
x_i\text{ 在 }\mathcal S\text{ 上由 }x|_A\text{ 唯一确定}
\iff e_i\in R+V_A.
\quad}
\]

若右侧成立，可写成

\[
e_i=\sum_{j\in F}d_j a_j+\sum_{a\in A_0}c_a e_a
\]

其中 \(F\subseteq J\) 和 \(A_0\subseteq A\) 都有限，于是每个解满足有限仿射恢复公式

\[
\boxed{\quad
x_i=\sum_{j\in F}d_j b_j+\sum_{a\in A_0}c_a x_a.
\quad}
\]

反之，若 \(e_i\notin R+V_A\)，可取 \(V/(R+V_A)\) 上的线性泛函，使 \(e_i\) 的像取值 \(1\)。把它的任意标量倍加到纤维中的一个解上，得到同一纤维中的解，且 \(x_i\) 遍历整个 \(k\)。因此，即使只要求一个任意形式的函数从 \(x|_A\) 确定 \(x_i\)，也必然存在上面的有限仿射公式。

定义

\[
\operatorname{cl}(A)=\{i\in I:e_i\in R+V_A\}.
\]

这是由向量族 \(\{q(e_i):i\in I\}\) 给出的线性拟阵闭包。它具有有限性：\(i\in\operatorname{cl}(A)\) 时，已有某个有限 \(A_0\subseteq A\) 使 \(i\in\operatorname{cl}(A_0)\)。它还满足交换性质；例如，若 \(q(e_i)\in U_A+kq(e_j)\) 但 \(q(e_i)\notin U_A\)，解出 \(q(e_j)\) 即得 \(j\in\operatorname{cl}(A\cup\{i\})\)。

在这个拟阵中，\(A\) 独立恰好意味着 \(\pi_A\) 满射，\(A\) 生成整个 \(W\) 恰好意味着 \(\pi_A\) 单射。因此，恰使 \(\pi_B\) 双射的集合 \(B\) 正是向量族 \(q(e_i)\) 的基所对应的指标集。每个可自由赋值的坐标集都能扩充成这样的 \(B\)；每个能恢复全部坐标的集合都包含这样的 \(B\)。这些自由与恢复性质只依赖系数 \(a_j\)；常数 \(b_j\) 决定相应的仿射常数。

还可以对任意固定的 \(A\) 同时构造像和全部纤维的自由坐标。先选 \(B\subseteq A\)，使 \(\{q(e_b):b\in B\}\) 是 \(U_A\) 的一组基，再选 \(C\subseteq I\setminus A\)，使

\[
\{q(e_b):b\in B\}\cup\{q(e_c):c\in C\}
\]

是 \(W\) 的一组基。这些选择由 Zorn 引理保证。对每个 \(i\in I\)，作唯一的有限展开

\[
q(e_i)=\sum_{b\in B}u_{ib}q(e_b)+\sum_{c\in C}v_{ic}q(e_c),
\]

并令

\[
r_i=e_i-\sum_{b\in B}u_{ib}e_b-\sum_{c\in C}v_{ic}e_c\in R.
\]

那么所有解恰好且无重复地由任意 \(s\in k^B\)、\(t\in k^C\) 给出：

\[
\boxed{\quad
x_i=\beta(r_i)+\sum_{b\in B}u_{ib}s_b
                 +\sum_{c\in C}v_{ic}t_c
\qquad(i\in I).
\quad}
\]

这里 \(s_b=x_b\)、\(t_c=x_c\)。该构造确实产生解：把所选商空间基向量送到对应的 \(e_b,e_c\)，得到线性截面 \(\sigma:W\to V\)；任意 \(s,t\) 决定一个 \(\lambda\in W^*\)，而

\[
f(v)=\beta\bigl(v-\sigma q(v)\bigr)+\lambda(q(v))
\]

延拓 \(\beta\)，其坐标正是上式。

由于 \(a\in A\) 时 \(v_{ac}=0\)，像也可写为

\[
\pi_A(\mathcal S)
=
\left\{y\in k^A:
y_a=\beta(r_a)+\sum_{b\in B}u_{ab}y_b
\text{ 对所有 }a\in A\right\}.
\]

对满足这些公式的 \(y\)，取 \(s_b=y_b\)，再让 \(t\in k^C\) 任意变化，就得到其全部纤维。因此

\[
|\pi_A(\mathcal S)|=|k|^{|B|},\qquad
|\pi_A^{-1}(y)|=|k|^{|C|}\quad(y\in\pi_A(\mathcal S)),
\qquad
|\mathcal S|=|k|^{|B|+|C|}.
\]

其中 \(|B|=\dim U_A\)，\(|C|=\dim(W/U_A)\)。在无限情形，\(|C|\) 是可自由指定的坐标的指标基数，不必等于纤维平移空间 \((W/U_A)^*\) 的代数维数。

最后还有一个内在分类：若给每个 \(k\) 赋离散拓扑，非空的此类解集恰是 \(k^I\) 的非空闭仿射子空间。一个方向源于每条有限支撑方程都是闭条件。反过来，若 \(H\) 是非空闭仿射子空间且 \(x\notin H\)，存在有限 \(F\subseteq I\) 使 \(x|_F\notin\pi_F(H)\)；在有限维空间 \(k^F\) 中用一个线性泛函分离该点与仿射子空间，便得到一条在 \(H\) 上成立、在 \(x\) 处不成立的有限支撑方程。收集所有这样的方程即可得到 \(H\)。上述像的公式也表明，每个 \(\pi_A(\mathcal S)\) 同样是闭仿射子空间。