题设不足以保证整体分裂。即使 \(B\) 是秩为 \(1\) 的自由模，所有素点处的分裂也未必来自一个整体映射。

取
\[
R=\prod_{n\ge1}\mathbf F_2,\qquad
I=\bigoplus_{n\ge1}\mathbf F_2,
\]
其中 \(I\) 是所有有限支撑序列构成的理想。令 \(A=I\)、\(B=R\)、\(C=R/I\)，并取自然短正合列
\[
0\longrightarrow I\longrightarrow R\xrightarrow{q}R/I\longrightarrow0.
\]
这里 \(C\) 由 \(\bar1=1+I\) 生成，且 \(C\ne0\)，因为常数序列 \(1\) 不属于 \(I\)。

对任意素理想 \(\mathfrak p\)，局部化后的映射 \(q_{\mathfrak p}\) 都分裂：

- 若 \(I\not\subseteq\mathfrak p\)，则 \(I_{\mathfrak p}=R_{\mathfrak p}\)，故 \(C_{\mathfrak p}=0\)。
- 若 \(I\subseteq\mathfrak p\)，对每个 \(a\in I\)，由于 \(a^2=a\)，有 \((1-a)a=0\)。又 \(1-a\notin\mathfrak p\)，所以 \(a/1=0\) 于 \(R_{\mathfrak p}\)。因此 \(I_{\mathfrak p}=0\)，而 \(q_{\mathfrak p}\) 是同构。

但 \(q\) 没有整体右逆。记 \(\delta_n\in I\) 为仅在第 \(n\) 个位置取值 \(1\) 的序列。若 \(s:C\to R\) 是任意 \(R\) 线性映射，令 \(x=s(\bar1)\)，则
\[
\delta_nx=s(\delta_n\bar1)=0\qquad(n\ge1).
\]
这迫使 \(x\) 的每个分量都为零，故 \(x=0\)。于是 \(q(s(\bar1))=0\ne\bar1\)，所以 \(s\) 不可能是右逆。因而也不存在与该短正合列相容的 \(R\cong I\oplus R/I\)。

对于一般的题设，可以准确刻画何时存在整体分裂及其自由度。取 \(C\) 的一个生成元 \(c\)，记
\[
I=\operatorname{Ann}_R(c),\qquad C\cong R/I.
\]
则
\[
\boxed{\quad q\text{ 有整体右逆}
\iff
I=(1-e)R\text{，其中 }e^2=e\in R.\quad}
\]

事实上，设 \(\pi:R\to C\) 由 \(\pi(r)=rc\) 给出。若 \(q\) 有右逆 \(s\)，由于 \(B\) 自由，存在 \(h:B\to R\) 使 \(\pi h=q\)。令 \(t=hs\)，则 \(\pi t=I_C\)。设 \(e=t(c)\)，便有 \(1-e\in I\) 和 \(Ie=0\)。因此 \(e^2=e\)，并且
\[
I=(1-e)R.
\]
反过来，若 \(I=(1-e)R\) 且 \(e^2=e\)，任选 \(b\in B\) 使 \(q(b)=c\)，则
\[
s_0(rc)=r\,e b
\]
是定义良好的整体右逆：\(I\) 消去 \(eb\)，且 \(q(eb)=ec=c\)。

这个判据也解释了局部条件的不足：局部环中的幂等元只能是 \(0\) 或 \(1\)，因此逐素点分裂等价于每个 \(I_{\mathfrak p}\) 都是 \(0\) 或整个 \(R_{\mathfrak p}\)；这不强制 \(I\) 由一个整体幂等元生成。

一旦存在一个右逆 \(s_0\)，所有右逆恰为
\[
s_0+\iota f,\qquad f\in\operatorname{Hom}_R(C,A).
\]
对应生成元 \(c\)，有
\[
\operatorname{Hom}_R(C,A)\cong
A[I]:=\{a\in A: Ia=0\}.
\]
在上面的幂等元条件下，\(A[I]=eA\)。因此所有右逆可具体写成
\[
s_a(rc)=r\bigl(eb+\iota(a)\bigr),\qquad a\in eA,
\]
且参数 \(a\) 唯一。

每个这样的 \(s_a\) 给出所需的相容同构
\[
A\oplus C\longrightarrow B,\qquad
(x,y)\longmapsto\iota(x)+s_a(y),
\]
其逆为
\[
b'\longmapsto
\left(\iota^{-1}\!\bigl(b'-s_a(q(b'))\bigr),\,q(b')\right).
\]
所有与 \(\iota,q\) 相容的同构都以这种方式唯一得到。