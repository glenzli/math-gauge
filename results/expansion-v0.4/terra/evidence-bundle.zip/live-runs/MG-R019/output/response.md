定义
\[
\widehat A=\{\mathcal F\in U(X):A\in\mathcal F\},\qquad
c(A)=\{a(\mathcal F):\mathcal F\in U(X),\ A\in\mathcal F\}.
\]
所求拓扑的闭包将是 \(c\)。在这个拓扑下，所求的 profinite 空间可以取为所有有限值观测组成的乘积中 \(X\) 的像；其纤维恰好是 \(X\) 的连通分支。

先使用两个关于超滤子的基本事实。对任意拓扑空间 \(T\)，
\[
x\in\overline A
\iff
\text{存在 }\mathcal F\in U(T)\text{，使 }A\in\mathcal F
\text{ 且 }\mathcal F\to x,                                      \tag{1}
\]
并且
\[
\mathcal F\to x
\iff
x\in\bigcap_{A\in\mathcal F}\overline A.                          \tag{2}
\]
对于 (1)，若 \(x\in\overline A\)，则 \(A\) 与 \(x\) 的全部邻域有有限交性质，故可扩张为超滤子；反向则因为收敛超滤子中的每个集合都与 \(x\) 的每个邻域相交。对于 (2)，若右边成立而某个 \(x\) 的开邻域 \(V\notin\mathcal F\)，则 \(T\setminus V\in\mathcal F\)，但 \(x\notin\overline{T\setminus V}\)，矛盾。

同样由超滤子扩张定理可知：空间紧当且仅当每个超滤子都有收敛点；空间 Hausdorff 当且仅当每个超滤子至多有一个收敛点。例如，若两个不同点不能由不相交邻域分开，它们的邻域共同生成的滤子可以扩张为同时收敛到这两点的超滤子。

下面验证 \(c\) 是闭包算子。集合运算 \(A\mapsto\widehat A\) 保持有限交和补，因此题中定义的 \(m_X(\mathfrak W)\) 确实是超滤子。由主超滤子和超滤子的性质，
\[
c(\varnothing)=\varnothing,\qquad A\subseteq c(A),\qquad
c(A\cup B)=c(A)\cup c(B).
\]
特别地，\(c\) 单调。关键是证明 \(c(c(A))\subseteq c(A)\)。

取 \(\mathcal F\in U(X)\) 且 \(c(A)\in\mathcal F\)。在 \(U(X)\) 上考虑集合族
\[
\{\widehat A\}\ \cup\
\{a^{-1}(B):B\in\mathcal F\}.
\]
它有有限交性质：若 \(B_1,\ldots,B_n\in\mathcal F\)，令
\(B=B_1\cap\cdots\cap B_n\)。由于 \(B\cap c(A)\in\mathcal F\)，可取
\(y\in B\cap c(A)\)，继而按 \(c(A)\) 的定义取 \(\mathcal G\) 使
\(A\in\mathcal G\) 且 \(a(\mathcal G)=y\)。于是
\(\mathcal G\in\widehat A\cap a^{-1}(B)\)。

将该集合族扩张为 \(\mathfrak W\in U(U(X))\)。那么
\[
U(a)(\mathfrak W)=\mathcal F,\qquad A\in m_X(\mathfrak W).
\]
第一个等式是因为左边包含超滤子 \(\mathcal F\)。故代数恒等式给出
\[
a(\mathcal F)
=a(U(a)(\mathfrak W))
=a(m_X(\mathfrak W))\in c(A).
\]
这证明 \(c(c(A))\subseteq c(A)\)；反向包含由 \(D\subseteq c(D)\) 得到。因此 \(c\) 是 Kuratowski 闭包算子。令 \(C\subseteq X\) 闭当且仅当 \(c(C)=C\)，便得到一个拓扑，且其闭包恰为 \(c\)。

对每个 \(\mathcal F\in U(X)\) 和每个 \(A\in\mathcal F\)，都有
\(a(\mathcal F)\in c(A)\)。由 (2)，
\[
\mathcal F\longrightarrow a(\mathcal F).
\]
还要证明它没有其他收敛点。假设 \(\mathcal F\to x\)，令
\[
K_x=\{\mathcal G\in U(X):a(\mathcal G)=x\}.
\]
由 (2)，每个 \(A\in\mathcal F\) 都满足 \(x\in c(A)\)。于是
\[
\{K_x\}\cup\{\widehat A:A\in\mathcal F\}
\]
有有限交性质：对有限个 \(A_i\in\mathcal F\)，它们的交仍属于 \(\mathcal F\)，而
\(x\in c(\bigcap_i A_i)\) 提供了所需的 \(\mathcal G\)。取包含这一集合族的
\(\mathfrak W\in U(U(X))\)，便有
\[
m_X(\mathfrak W)=\mathcal F,\qquad
U(a)(\mathfrak W)=\delta_x.
\]
因此
\[
a(\mathcal F)
=a(m_X(\mathfrak W))
=a(U(a)(\mathfrak W))
=a(\delta_x)=x.
\]
所以每个超滤子恰好收敛于其运算值。前述超滤子判据随即说明该拓扑紧且 Hausdorff。

这个拓扑也是唯一的：在任何具有题述收敛性质的拓扑中，(1) 都迫使
\[
\overline A
=\{a(\mathcal F):A\in\mathcal F\}
=c(A).
\]
闭包确定拓扑。

反过来，设 \(X\) 已是紧 Hausdorff 空间，令 \(a(\mathcal F)\) 为 \(\mathcal F\) 的唯一极限。显然 \(a(\delta_x)=x\)。对 \(\mathfrak W\in U(U(X))\)，令
\[
x=a(U(a)(\mathfrak W)).
\]
若 \(V\) 是 \(x\) 的开邻域，则 \(a^{-1}(V)\in\mathfrak W\)。而
\(a(\mathcal G)\in V\) 蕴含 \(V\in\mathcal G\)，所以
\(a^{-1}(V)\subseteq\widehat V\)。于是 \(\widehat V\in\mathfrak W\)，即
\(V\in m_X(\mathfrak W)\)。这证明 \(m_X(\mathfrak W)\to x\)，由极限唯一性，
\[
a(m_X(\mathfrak W))=a(U(a)(\mathfrak W)).
\]
由 (1)，从此运算重建的闭包就是原闭包；反过来，从运算构造拓扑后取超滤子极限也恢复原运算。因此两种构造互逆。

对映射 \(f:X\to Y\)，若它连续，则 \(U(f)(\mathcal F)\) 收敛于
\(f(a(\mathcal F))\)，故
\[
f(a(\mathcal F))=b(U(f)(\mathcal F)).
\]
反之，假设这个等式对所有 \(\mathcal F\) 成立。若 \(B\subseteq Y\) 闭且
\(f^{-1}(B)\in\mathcal F\)，则 \(B\in U(f)(\mathcal F)\)，因而
\[
f(a(\mathcal F))=b(U(f)(\mathcal F))\in B.
\]
所以
\(c_X(f^{-1}(B))\subseteq f^{-1}(B)\)，即 \(f^{-1}(B)\) 闭。这证明 \(f\) 连续，也证明了题中要求的映射对应。

为构造并刻画 \(P\)，先证明一个紧 Hausdorff 空间的性质。对点 \(x\)，令
\[
Q_x=\bigcap\{C:C\text{ 是开闭集且 }x\in C\}.
\]
则 \(Q_x\) 恰是 \(x\) 的连通分支。事实上，\(Q_x\) 是紧集。若它分成非空、互不相交的相对闭集 \(L,M\)，并设 \(x\in L\)，则 \(L,M\) 是不相交的紧集，故可分别置于不相交开集 \(V_L,V_M\) 中。紧集
\(D=X\setminus(V_L\cup V_M)\) 与 \(Q_x\) 不交；对每个 \(d\in D\)，存在包含 \(x\) 而不包含 \(d\) 的开闭集。由 \(D\) 的紧性，可取其中有限多个的交 \(C\)，使
\[
Q_x\subseteq C\subseteq V_L\cup V_M.
\]
于是 \(C\cap V_L=C\setminus V_M\) 是包含 \(x\) 的开闭集，却不包含 \(M\)，与 \(Q_x\) 的定义矛盾。故 \(Q_x\) 连通。任何包含 \(x\) 的连通集都包含在每个含 \(x\) 的开闭集中，所以也包含在 \(Q_x\) 中。

特别地，紧 Hausdorff 全不连通空间中，任意两个不同点可由开闭集分开。进一步，对任意点的开邻域，利用其补集的紧性取有限个这样的分离开闭集的交，可得包含该点且位于原邻域中的开闭集；因此这类空间有开闭基。

现在只用标准有限集合 \(n=\{0,\ldots,n-1\}\) 作观测目标。令
\[
\mathcal O=
\{(n,f):n\in\mathbb N,\ f:X\to n,\ 
f\circ a=b_n\circ U(f)\}.
\]
这是一个集合。有限离散空间上的超滤子极限运算正是 \(b_n\)，所以由映射对应，\(\mathcal O\) 中的 \(f\) 恰是连续的有限值映射。任意有限集合都可与某个 \(n\) 双射，而有限集合上的超滤子都是主超滤子；因此重新标记目标保持观测条件，不会遗漏题目中的任何有限值观测。

给每个 \(n\) 离散拓扑，定义
\[
E=\prod_{(n,f)\in\mathcal O}n,\qquad
p:X\longrightarrow E,\quad
p(x)=(f(x))_{(n,f)\in\mathcal O},
\]
并令
\[
P=p(X),\qquad q:X\longrightarrow P,\quad q(x)=p(x).
\]
各坐标连续，故 \(p\) 连续。于是 \(P\) 紧；\(E\) Hausdorff，故 \(P\) Hausdorff 且是 \(E\) 的闭子集。\(P\) 中不同点在某个有限离散坐标上不同，因而可由开闭柱集分开，所以 \(P\) 全不连通。故 \(P\) 是所要求的 profinite 空间，\(q\) 连续且满射。

这个构造也可完全用有限一致性描述：
\[
P=
\left\{(t_o)_{o\in\mathcal O}\in E:
\begin{array}{l}
\text{对每个有限 }J\subseteq\mathcal O,\text{ 都存在 }x\in X,\\
\text{使每个 }o=(n,f)\in J\text{ 满足 }f(x)=t_o
\end{array}\right\}.
\]
右边是 \(p(X)\) 在乘积中的闭包，而 \(p(X)\) 已经是闭集。

定义以下完全由原运算给出的集合族：
\[
\mathcal B_a=
\left\{B\subseteq X:
\forall\mathcal F\in U(X),\
\bigl(B\in\mathcal F\iff a(\mathcal F)\in B\bigr)\right\}.
\]
它恰是 \(X\) 的开闭集族。确实，令 \(\chi_B:X\to 2\) 为 \(B\) 的特征函数，则
\[
b_2(U(\chi_B)(\mathcal F))=1
\iff B\in\mathcal F,
\]
所以 \(\chi_B\) 是有限值观测当且仅当 \(B\in\mathcal B_a\)；而 \(\chi_B\) 连续当且仅当 \(B\) 开闭。

每个有限值观测的点纤维都是开闭集，反过来每个开闭集都由其特征观测检测。因此，对 \(x,y\in X\)，
\[
\begin{aligned}
q(x)=q(y)
&\iff f(x)=f(y)\quad\text{对所有有限值观测 }f,\\
&\iff x,y\text{ 属于完全相同的开闭集},\\
&\iff y\text{ 与 }x\text{ 属于同一连通分支}.
\end{aligned}
\]
特别地，纤维有纯代数描述
\[
\boxed{\quad
q^{-1}(\{q(x)\})
=\bigcap_{\substack{B\in\mathcal B_a\\x\in B}}B
=\text{\(x\) 的连通分支}.
\quad}                                                           \tag{3}
\]

最后验证泛性质。设 \(Z\) 是 profinite 空间，\(h:X\to Z\) 连续。若 \(q(x)=q(y)\)，则 \(x,y\) 对 \(X\) 的所有开闭集具有相同的归属关系。对 \(Z\) 的任意开闭集 \(C\)，\(h^{-1}(C)\) 也是开闭集，因此 \(h(x),h(y)\) 不能被开闭集分开。由于 \(Z\) 中不同点可由开闭集分开，必有 \(h(x)=h(y)\)。故存在唯一集合映射
\[
\bar h:P\to Z,\qquad h=\bar h\circ q.
\]
\(q\) 是从紧空间到 Hausdorff 空间的连续满射，因而是闭映射，也是商映射。由 \(h=\bar h\circ q\) 连续，得到 \(\bar h\) 连续。于是复合给出所需双射
\[
C(P,Z)\xrightarrow{\ \cong\ }C(X,Z).
\]
该泛性质还保证：任何另一个满足同样条件的 \(P'\) 都与 \(P\) 通过唯一一个和 \(X\) 上的映射相容的同胚对应。

由 (3)，\(q\) 为单射当且仅当有限值观测分离点，即
\[
\boxed{\quad
\forall x\ne y,\ \exists\text{ 有限值观测 }f
\text{ 使 }f(x)\ne f(y).
\quad}
\]
等价地，这个条件可以只用二值观测写成
\[
\boxed{\quad
\forall x\ne y,\ \exists B\subseteq X:\ 
x\in B,\ y\notin B,\quad
\forall\mathcal F\in U(X),\
\bigl(B\in\mathcal F\iff a(\mathcal F)\in B\bigr).
\quad}
\]
它也等价于重建出的 \(X\) 全不连通。此时 \(X\) 本身是 profinite，连续双射 \(q:X\to P\) 是同胚。空集情形同样成立：此时 \(U(X)=P=\varnothing\)，上述断言均按空情形成立。