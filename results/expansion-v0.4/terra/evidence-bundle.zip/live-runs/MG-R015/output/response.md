所要求的短正合性在题设下**一般不成立**。相容的商记录总能提升到 \(\widehat B\)，但其全部提升由 \(A\) 从 \(B\) 继承的滤过控制；这个滤过未必与 \(A\) 自身的 \(t\) 进滤过给出相同的完备化。

先看中间正合性失败的例子。取

\[
B=\bigoplus_{j\ge1}Re_j,\qquad
A=\bigoplus_{j\ge1}Ra_j,\qquad
\iota(a_j)=t^je_j.
\]

这是自由模之间的单射，且 \(C\simeq\bigoplus_{j\ge1}R/(t^j)\)。可数自由模的完备化可表示为受限序列：

\[
\widehat{\bigoplus_j R}\cong
\left\{(r_j)\in k[[t]]^{\mathbb N}:
\text{对每个 }n,\text{ 只有有限多个 }r_j\notin t^nk[[t]]\right\}.
\]

因此 \(\beta=(t^j)_{j\ge1}\) 属于 \(\widehat B\)。对每个 \(n\)，它在 \(B/t^nB\) 中的像为

\[
\sum_{j<n}t^je_j=\iota\!\left(\sum_{j<n}a_j\right),
\]

所以 \(\widehat q(\beta)=0\)。若 \(\beta=\widehat\iota(\alpha)\)，逐坐标比较得到 \(\alpha_j=1\) 对所有 \(j\) 成立；但这个序列在模 \(t\) 后有无限多个非零坐标，不属于 \(\widehat A\)。故

\[
\operatorname{im}\widehat\iota
\subsetneq \ker\widehat q.
\]

下面给出在原题条件下始终成立的提升与恢复结论。

取任意相容记录 \(\bar c=(\bar c_n)_{n\ge1}\in\widehat C\)，选代表元 \(c_n\in C\)。相容性给出

\[
c_{n+1}-c_n=t^nd_n\qquad(d_n\in C).
\]

选 \(b_1,v_n\in B\)，使 \(q(b_1)=c_1\)、\(q(v_n)=d_n\)，并递归定义

\[
b_{n+1}=b_n+t^nv_n.
\]

于是 \(q(b_n)=c_n\)，且 \(b_{n+1}\equiv b_n\pmod{t^nB}\)。所以

\[
\bar b=(b_n+t^nB)_{n\ge1}\in\widehat B,
\qquad \widehat q(\bar b)=\bar c.
\]

这证明了 **\(\widehat q\) 始终满射**。

为了刻画全部提升，令

\[
F_nA=\iota^{-1}(t^nB).
\]

因为 \(t^nA\subseteq F_nA\)，逐层有自然同构

\[
A/F_nA
\;\cong\;
\ker\bigl(B/t^nB\longrightarrow C/t^nC\bigr).
\]

取逆极限得到

\[
\boxed{\quad
\ker\widehat q\;\cong\;\varprojlim_n A/F_nA.
\quad}
\]

具体地，固定上述一个提升 \(\bar b^{\,0}\)，则 \(\bar c\) 的所有提升恰为

\[
\left(b_n^{0}+\iota(a_n)+t^nB\right)_{n\ge1},
\qquad a_{n+1}-a_n\in F_nA.
\]

两个记录 \((a_n)\)、\((a_n')\) 给出同一提升，当且仅当对每个 \(n\) 都有 \(a_n-a_n'\in F_nA\)。由 \(t^nA\subseteq F_nA\) 得到的自然映射

\[
\theta:\widehat A=\varprojlim A/t^nA
\longrightarrow\varprojlim A/F_nA
\]

在上述同构下就是 \(\widehat\iota\)。因此，原题要求的短正合列成立，当且仅当 \(\theta\) 是双射。

事实上，\(\widehat\iota\) 的单射性也可能失败。另取

\[
B=\bigoplus_{n\ge0}Re_n,\qquad
A=Rx_*\oplus\bigoplus_{n\ge0}Rx_n,
\]
\[
\iota(x_*)=e_0,\qquad
\iota(x_n)=e_n-te_{n+1}.
\]

原映射 \(\iota\) 是单射：有限线性组合中，最高指标处的系数依次迫使所有系数为零。然而

\[
x_*-\sum_{n\ge0}t^nx_n\in\widehat A
\]

非零，而其像为零，因为部分和望远镜相消：

\[
e_0-\sum_{n=0}^{N}t^n(e_n-te_{n+1})
=t^{N+1}e_{N+1}\longrightarrow0.
\]

这两种障碍还可以只用 \(C\) 描述。记 \(C[t^n]=\{c\in C:t^nc=0\}\)，定义

\[
\Delta:\prod_{n\ge1}C[t^n]\longrightarrow\prod_{n\ge1}C[t^n],
\qquad
\Delta((u_n))=(u_n-tu_{n+1})_{n\ge1}.
\]

则有自然正合列

\[
\boxed{\quad
0\longrightarrow\ker\Delta
\longrightarrow\widehat A
\xrightarrow{\widehat\iota}\ker\widehat q
\longrightarrow\operatorname{coker}\Delta
\longrightarrow0.
\quad}
\]

这里对 \(c\in C[t^n]\) 选提升 \(b\in B\)，由 \(t^nb=\iota(a)\) 得到同构
\(C[t^n]\cong F_nA/t^nA\)；使用了自由模 \(B\) 没有 \(t\)-挠元。相邻层的映射在此同构下对应乘以 \(t\)。

正合列的最后一项也有直接的构造解释：对 \((u_n)\in\varprojlim A/F_nA\)，任取其在 \(A/t^nA\) 中的提升 \(v_n\)。相邻差

\[
v_n-\bigl(v_{n+1}\bmod t^nA\bigr)\in F_nA/t^nA
\]

给出 \(\operatorname{coker}\Delta\) 的一个元素；它为零恰好意味着可以调整各 \(v_n\)，使它们成为 \(\widehat A\) 的相容记录。反过来，利用各约化映射 \(A/t^{n+1}A\to A/t^nA\) 的满射性，可递归实现任意这样的障碍。因此原题的短正合性恰好等价于 \(\Delta\) 双射。

一个足以恢复原结论的附加条件是：存在 \(s\ge0\)，使 \(t^s\) 消去 \(C\) 的全部 \(t\)-幂挠元。在此条件下

\[
F_{n+s}A\subseteq t^nA\subseteq F_nA.
\]

确实，若 \(\iota(a)=t^{n+s}b\)，则 \(q(b)\) 是 \(t\)-幂挠元，故 \(t^sb\in\iota(A)\)，从而 \(a\in t^nA\)。因此两种滤过互相合并为同一个完备化；具体地，相容记录 \((a_n\bmod F_nA)\) 唯一恢复出

\[
(a_{n+s}\bmod t^nA)_{n\ge1}\in\widehat A.
\]

在这个附加条件下，\(\theta\) 为同构，原题中的完备化序列才确为短正合列，而且每个商记录的全部提升唯一地写成 \(\bar b^{\,0}+\widehat\iota(\widehat a)\)。