# 超滤子运算与有限观测的空间实现

采用 ZFC。对集合 $X$，记 $U(X)$ 为它的全部超滤子构成的集合，$\delta_x$ 为 $x$ 处的主超滤子。映射 $f:X\to Y$ 的推前为

$$U(f)(\mathcal F)=\{B\subseteq Y:f^{-1}(B)\in\mathcal F\}.$$

对 $\mathfrak W\in U(U(X))$，定义

$$m_X(\mathfrak W)=\{A\subseteq X:\{\mathcal F\in U(X):A\in\mathcal F\}\in\mathfrak W\}.$$

给定集合 $X$ 和映射 $a:U(X)\to X$，假设对每个 $x\in X$ 及 $\mathfrak W\in U(U(X))$ 有

$$a(\delta_x)=x,\qquad a(m_X(\mathfrak W))=a(U(a)(\mathfrak W)).$$

目标是在 $X$ 上构造唯一的紧 Hausdorff 拓扑，使每个超滤子 $\mathcal F$ 恰好收敛于 $a(\mathcal F)$，并建立这类运算与紧 Hausdorff 拓扑之间的双向对应。

该对应还应识别全部映射：若 $a:U(X)\to X$、$b:U(Y)\to Y$ 满足上述条件，则集合映射 $f:X\to Y$ 对所构造的拓扑连续，当且仅当

$$f\circ a=b\circ U(f).$$

此外，为重建出的空间构造一个 profinite 空间 $P$（紧、Hausdorff、全不连通）及连续满射 $q:X\to P$，使对每个 profinite 空间 $Z$，与 $q$ 复合给出双射

$$C(P,Z)\longrightarrow C(X,Z).$$

刻画 $q$ 的各个纤维，并用原运算 $a$ 及有限值观测给出 $q$ 为单射的充要判据。这里，对有限集合 $A$，记 $b_A:U(A)\to A$ 为将超滤子送到其中唯一单点集的点的映射；一个有限值观测是满足

$$f\circ a=b_A\circ U(f)$$

的映射 $f:X\to A$。

请给出构造、唯一性及完整论证。
