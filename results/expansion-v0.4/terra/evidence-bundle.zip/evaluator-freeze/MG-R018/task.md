# 有限观察的相容选择

采用 ZFC，固定 Grothendieck 宇宙 $\mathcal U\in\mathcal V$，且 $\mathbb N\in\mathcal U$。集合 $X$ 属于 $\mathcal V$，有限测试集合 $A$ 属于 $\mathcal U$。

$X$ 上的一个相容记录 $r$，为每个有限测试集合 $A$ 指定映射

$$r_A:\operatorname{Map}(X,A)\longrightarrow A,$$

并对所有有限测试集合 $A,B$、映射 $f:X\to A$ 与 $g:A\to B$ 满足

$$g(r_A(f))=r_B(g\circ f).$$

记全部这样的记录构成的集合为 $R(X)$，并记观察求值为 $e_{A,f}(r)=r_A(f)$。

建立 $R(X)$ 的内在集合论分类，并使分类在任意 $X,Y\in\mathcal V$ 之间的集合映射 $X\to Y$ 下自然。确定观察求值所诱导的函子及单子结构：单位 $\eta_X:X\to R(X)$ 与乘法 $\mu_X:R(R(X))\to R(X)$ 应满足

$$e_{A,f}\circ\eta_X=f,\qquad
e_{A,f}\circ\mu_X=e_{A,e_{A,f}}.$$

证明这些映射良定义、自然且满足单子律，并准确刻画哪些集合 $X$ 的全部相容记录都唯一地由某个 $x\in X$ 的点值求值得到。请给出主定理、构造和完整论证。
