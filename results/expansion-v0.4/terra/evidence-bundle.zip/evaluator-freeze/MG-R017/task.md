# 两个参数空间上的连续提升

采用 ZFC。这里的 profinite 空间指紧、Hausdorff、全不连通拓扑空间，映射均为连续映射。

给定两个 profinite 空间 $P_1,P_2$。对 $i=1,2$，假设它具有以下性质：对任意 profinite 空间 $Y,Z$、连续满射 $q:Y\to Z$ 及连续映射 $f:P_i\to Z$，均存在连续映射 $g:P_i\to Y$ 满足 $qg=f$。

以通常的积拓扑赋予 $P_1\times P_2$。目标是为任意 profinite 空间 $Y,Z$、连续满射 $q:Y\to Z$ 及连续映射 $f:P_1\times P_2\to Z$，构造连续映射 $g:P_1\times P_2\to Y$，使 $qg=f$。请给出完整论证。
