# 素点分裂的整体实现

设 $R$ 为含幺交换环，给定 $R$ 模的短正合列

$$0\longrightarrow A\xrightarrow{\iota}B\xrightarrow{q}C\longrightarrow0,$$

其中 $B$ 为有限秩自由模，$C$ 为循环模。对每个素理想 $\mathfrak p\subset R$，记 $R_{\mathfrak p}$ 及 $M_{\mathfrak p}=R_{\mathfrak p}\otimes_R M$ 为通常的局部化。假设每个局部化商映射均存在 $R_{\mathfrak p}$ 线性右逆：

$$\exists s_{\mathfrak p}:C_{\mathfrak p}\longrightarrow B_{\mathfrak p},
\qquad q_{\mathfrak p}s_{\mathfrak p}=I_{C_{\mathfrak p}}.$$

把这些素点上的分裂组织为整体实现：构造 $R$ 线性映射 $s:C\to B$，满足 $qs=I_C$，并由此得到与 $\iota,q$ 相容的同构 $B\cong A\oplus C$。刻画所有整体分裂的自由度，并给出完整论证。
