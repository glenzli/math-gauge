#!/usr/bin/env python3
"""Archive completed or failed trial evidence via explicit non-state paths.

This command never starts or retries a model and never scores an answer. It
requires the queue summary to exist; all failed attempts remain in the ledger.
"""
from pathlib import Path
import collections
import datetime
import hashlib
import importlib.util
import json
import re
import sys
import zipfile

FLOW = Path(__file__).resolve().parent

def load(path):
    return json.loads(Path(path).read_text())

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    with path.open('x') as out:
        json.dump(value, out, ensure_ascii=False, indent=2); out.write('\n')

def main():
    queue = load(FLOW / 'run-live-summary.json')
    freeze = load(FLOW / 'pretrial-freeze.json')
    ledger = load(FLOW / 'attempt-ledger.json')
    spec = importlib.util.spec_from_file_location('runtime_helper', FLOW / 'tools/prepare_runtime.py')
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    issues = []; cases = []; thread_ids = []
    for run in sorted((FLOW / 'live-runs').iterdir()):
        if not (run / 'runtime/execution.json').exists():
            issues.append(run.name + ': no model attempt started')
            cases.append({'case_id': run.name, 'status': 'not-started', 'mathematical_review': None})
            continue
        execution = load(run / 'runtime/execution.json')
        thread_ids.append(execution.get('events_summary', {}).get('thread_id'))
        local = helper.audit(run)
        save(run / 'runtime/local-audit.json', local)
        counts = collections.Counter(); items = collections.Counter()
        event_path = run / 'output/events.ndjson'
        if event_path.exists():
            with event_path.open() as stream:
                for line in stream:
                    try: event = json.loads(line)
                    except ValueError: continue
                    counts[event.get('type')] += 1
                    if isinstance(event.get('item'), dict): items[event['item'].get('type')] += 1
        tools = {key: value for key, value in items.items() if key not in {'agent_message', 'reasoning', 'error'}}
        valid = (execution.get('exit_code') == 0 and execution.get('request_count') == 1
                 and counts['turn.completed'] == 1 and local['artifact_checks_passed']
                 and local['runtime_reports_complete'] and not tools
                 and execution.get('installation_id_content_unchanged') is True
                 and load(run / 'runtime/network-probe.json')['passed'] is True
                 and execution.get('pre_submission_write_policy', {}).get('passed') is True)
        valid = valid and execution.get('fresh_ephemeral_session') is True and execution.get('home_preserved') is True and execution.get('codex_home_preserved') is True
        if not valid: issues.append(run.name + ': engineering completion or isolation acceptance failed')
        cases.append({
            'case_id': run.name, 'engineering_accepted': valid,
            **{key: execution.get(key) for key in ('requested_model', 'requested_effort', 'observed_model', 'observed_effort', 'model_metadata_limit', 'parent_pid', 'worker_pids', 'worker_structure', 'request_count', 'exit_code', 'elapsed_seconds', 'failure')},
            'event_types': dict(counts), 'item_types': dict(items), 'tool_events': tools,
            'response': execution.get('artifact_hashes', {}).get('output/response.md'),
            'mathematical_review': None,
        })
    if len(thread_ids) != 10 or not all(thread_ids) or len(set(thread_ids)) != 10:
        issues.append('Expected ten distinct newly created session thread IDs')
    report = {'schema': 'math-gauge.isolated-engineering-report/v1',
              'recorded_utc': helper.now(), 'queue_summary': queue, 'cases': cases,
              'engineering_checks_passed': not issues, 'issues': issues,
              'suite_sha256': freeze['suite_sha256'], 'runner_sha256': freeze['runner_sha256'],
              'distinct_new_thread_ids': thread_ids, 'distinct_new_session_count': len(set(thread_ids)),
              'all_stdin_submissions_including_failed_startups': sum(x.get('request_count', 0) for x in ledger['attempts']),
              'failed_attempts_preserved': [x['id'] for x in ledger['attempts'] if x.get('status') == 'failed'],
              'mathematical_scoring_performed_by_engineering': False,
              'mathematical_review_scope': 'Independent root/Astra review records are separate and may already exist; this engineering report does not score answers.',
              'human_approval': False,
              'state_and_credentials_archived': False,
              'identity_limit': 'Requested CLI model/effort and actual PID/executable evidence are separate from explicit runtime backend metadata; unreported observations stay null.'}
    save(FLOW / 'final-engineering-report.json', report)
    names = set()
    root_names = (
        'pretrial-freeze.json', 'inference-release.json', 'model-inventory.json',
        'PRETRIAL_READY.json', 'PREPARATION_HANDOFF.json',
        'attempt-ledger.json', 'runtime-policy-extension.json', 'installation-id-before.json',
        'preflight-report.json', 'open-probe-summary.json', 'configuration-readiness.json',
        'queue-supervisor.json', 'queue.stdout.txt', 'queue.stderr.txt',
        'run-live-summary.json', 'run-live-summary.partial.json', 'final-engineering-report.json',
        'FLOW_HANDOFF.md', 'gates.py', 'prepare_trial.py', 'prepare_config_templates.py',
        'run_cases.py', 'start_queue.py', 'monitor.py', 'poll_completions.py', 'probe_runs.py', 'network_probe.py',
        'prepare_preflight.py', 'run_preflight.py', 'policy-preflight-config.json',
        'test_release_gates.py', 'finalize_evidence.py')
    for name in root_names:
        if (FLOW / name).is_file(): names.add(name)
    for directory in ('tools', 'cli-inspection', 'receipts', 'frozen-cases', 'configs-live', 'config-templates'):
        for path in (FLOW / directory).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                names.add(path.relative_to(FLOW).as_posix())
    names.update(row['path'] for row in freeze['frozen_files'])
    runtime_names = {
        'probe.py', 'cli-identity.json', 'outer.sb', 'codex-settings.json', 'probes.json',
        'plan.json', 'attempt-ledger.json', 'execution.template.json', 'prepared-hashes.json',
        'execution.json', 'open-probe.json', 'open-probe.stdout.txt', 'open-probe.stderr.txt',
        'parent-pid-check.json', 'worker-pid-check.json', 'write-pid-check.json',
        'process-identity.json', 'process-identity-final.json', 'policy-exceptions.json',
        'network-probe.py', 'network-probe.json', 'network-probe.stdout.txt',
        'network-probe.stderr.txt', 'preflight-scope.json', 'local-audit.json'}
    for run in [FLOW / 'policy-preflight', *sorted((FLOW / 'live-runs').iterdir())]:
        for name in ('input/task.md', 'output/events.ndjson', 'output/stderr.txt', 'output/response.md'):
            if (run / name).is_file(): names.add((run / name).relative_to(FLOW).as_posix())
        for name in runtime_names:
            path = run / 'runtime' / name
            if path.is_file(): names.add(path.relative_to(FLOW).as_posix())
        for path in (run / 'runtime').glob('worker-pid-check-*.json'):
            names.add(path.relative_to(FLOW).as_posix())
    patterns = {
        'token-key': re.compile(rb'\bsk-[A-Za-z0-9_-]{20,}'),
        'bearer': re.compile(rb'(?i)\bBearer\s+[A-Za-z0-9._-]{16,}'),
        'credential-json': re.compile(rb'"(?:access_token|refresh_token|id_token)"\s*:\s*"[^"\s]{12,}"'),
        'private-key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    }
    files = []; hits = []
    for name in sorted(names):
        path = FLOW / name
        if (path.is_symlink() or not path.resolve().is_relative_to(FLOW) or not path.is_file()
            or 'state' in Path(name).parts or path.suffix in {'.sqlite', '.sqlite-shm', '.sqlite-wal', '.olean', '.ilean'}
            or path.name in {'auth.json', 'installation_id'}):
            raise RuntimeError('Forbidden evidence path: ' + name)
        data = path.read_bytes()
        matched = [key for key, pattern in patterns.items() if pattern.search(data)]
        if matched: hits.append({'path': name, 'patterns': matched})
        files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    save(FLOW / 'credential-scan.json', {'recorded_utc': helper.now(), 'patterns': list(patterns), 'hits': hits, 'credential_values_printed': False, 'rule': 'Any match blocks archival; original evidence is never rewritten.'})
    save(FLOW / 'evidence-whitelist.json', {'recorded_utc': helper.now(), 'files': files, 'state_included': False, 'credentials_included': False, 'credential_scan_passed': not hits, 'engineering_checks_passed': not issues, 'mathematical_scoring_performed': False})
    if hits: raise RuntimeError('Credential-like match blocks archival; paths-only scan report retained')
    archive = FLOW / 'evidence-bundle.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as out:
        for item in files: out.write(FLOW / item['path'], item['path'])
        for name in ('credential-scan.json', 'evidence-whitelist.json'): out.write(FLOW / name, name)
    save(FLOW / 'archive-identity.json', {'recorded_utc': helper.now(), 'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest(archive), 'engineering_checks_passed': not issues, 'all_failed_attempts_retained': True, 'mathematical_review': None})
    print(json.dumps({'archive': str(archive), 'sha256': digest(archive), 'files': len(files), 'engineering_checks_passed': not issues, 'issues': issues}))
    return 0 if not issues else 1

if __name__ == '__main__':
    raise SystemExit(main())
