"""No-inference rejection tests for the operator queue release boundary."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import gates

class ReleaseGateTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        (self.root / 'bound-policy.txt').write_text('frozen')
        self.freeze = {'suite_sha256': 'frozen-suite', 'frozen_files': [], 'prepared_files': [],
                       'operator_files': [{'path': 'bound-policy.txt', 'sha256': gates.digest(self.root / 'bound-policy.txt')}]}
        self.write('pretrial-freeze.json', self.freeze)
        self.release = {'schema': 'math-gauge.inference-release/v1', 'explicit_parent_release': True,
                        'case_ids': gates.EXPECTED_IDS, 'requested_model': 'gpt-6.1-terra',
                        'requested_effort': 'max', 'pretrial_freeze_sha256': gates.digest(self.root / 'pretrial-freeze.json'),
                        'suite_sha256': 'frozen-suite', 'released_utc': 'fixture', 'authorization': 'fixture'}
        flow = patch.object(gates, 'FLOW', self.root); flow.start(); self.addCleanup(flow.stop)
        frozen = patch.object(gates, 'verify_frozen_cases', return_value={}); frozen.start(); self.addCleanup(frozen.stop)

    def write(self, name, value):
        (self.root / name).write_text(json.dumps(value))

    def test_release_file_is_required(self):
        with self.assertRaises(FileNotFoundError):
            gates.verify_release()

    def test_wrong_freeze_hash_is_rejected(self):
        self.release['pretrial_freeze_sha256'] = 'wrong'
        self.write('inference-release.json', self.release)
        with self.assertRaisesRegex(RuntimeError, 'release'):
            gates.verify_release()

    def test_operator_policy_tampering_is_rejected(self):
        self.write('inference-release.json', self.release)
        (self.root / 'bound-policy.txt').write_text('changed')
        with self.assertRaisesRegex(RuntimeError, 'snapshot changed'):
            gates.verify_release()

    def test_wrong_effort_is_rejected(self):
        self.release['requested_effort'] = 'high'
        self.write('inference-release.json', self.release)
        with self.assertRaisesRegex(RuntimeError, 'release'):
            gates.verify_release()

if __name__ == '__main__':
    unittest.main()
