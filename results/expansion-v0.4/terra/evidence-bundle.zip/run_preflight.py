#!/usr/bin/env python3
"""Execute actual OS checks only; no model CLI is launched."""
from pathlib import Path
import datetime
import json
import subprocess
import sys

FLOW = Path(__file__).resolve().parent
run = FLOW / 'policy-preflight'
plan = json.loads((run / 'runtime/plan.json').read_text())
python = str(Path(sys.executable).resolve())
rows = []
for name, args in [
    ('open-probe', [python, '-B', str(run / 'runtime/probe.py'), '--manifest', str(run / 'runtime/probes.json'), '--out', str(run / 'runtime/open-probe.json')]),
    ('network-probe', [python, '-B', str(run / 'runtime/network-probe.py'), str(run / 'runtime/network-probe.json')]),
]:
    argv = plan['argv'][:3] + args
    result = subprocess.run(argv, cwd=run, capture_output=True, timeout=30)
    for channel in ('stdout', 'stderr'):
        (run / 'runtime' / (name + '.' + channel + '.txt')).write_bytes(getattr(result, channel))
    output = run / 'runtime' / (name + '.json')
    report = json.loads(output.read_text()) if output.exists() else None
    rows.append({'check': name, 'argv': argv, 'exit_code': result.returncode, 'passed': bool(report and report['passed'])})
summary = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'checks': rows, 'passed': all(row['passed'] for row in rows), 'model_requests': 0, 'model_cli_launched': False}
with (FLOW / 'preflight-report.json').open('x') as out:
    json.dump(summary, out, indent=2); out.write('\n')
print(json.dumps(summary))
raise SystemExit(0 if summary['passed'] else 1)
