"""Strict pre-request gates shared by the operator-side queue scripts."""
from pathlib import Path
import hashlib
import json
import sys

FLOW = Path(__file__).resolve().parent
ROOT = FLOW.parent
MIRROR = ROOT / 'integration'
EXPECTED_IDS = [f'MG-R{i:03d}' for i in range(11, 21)]

def load(path):
    return json.loads(Path(path).read_text())

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verify_frozen_cases():
    state = load(FLOW / 'integration-state.json')
    if state['pending_cases'] or set(state['frozen_cases']) != set(EXPECTED_IDS):
        raise RuntimeError('All ten expansion cases need an explicit owner freeze')
    for cid in EXPECTED_IDS:
        row = state['frozen_cases'][cid]
        path = FLOW / row['receipt']
        if digest(path) != row['receipt_sha256']:
            raise RuntimeError('Frozen handoff receipt changed: ' + cid)
        receipt = load(path); case = MIRROR / 'cases/public' / cid
        for name, expected in receipt['frozen_inputs'].items():
            if digest(case / name) != expected:
                raise RuntimeError('Frozen mathematical input changed: ' + cid + '/' + name)
        if digest(case / 'formal/manifest.json') != receipt['manifest_sha256']:
            raise RuntimeError('Formal manifest changed after owner freeze: ' + cid)
        for item in receipt['files']:
            if item['path'].endswith('.lean') or item['path'] == 'formal/COVERAGE.md':
                if digest(case / item['path']) != item['sha256']:
                    raise RuntimeError('Frozen formal source changed: ' + cid + '/' + item['path'])
    return state

def verify_release():
    verify_frozen_cases()
    freeze_path = FLOW / 'pretrial-freeze.json'
    freeze = load(freeze_path)
    release = load(FLOW / 'inference-release.json')
    if (release.get('schema') != 'math-gauge.inference-release/v1'
        or release.get('explicit_parent_release') is not True
        or release.get('case_ids') != EXPECTED_IDS
        or release.get('requested_model') != 'gpt-6.1-terra'
        or release.get('requested_effort') != 'max'
        or release.get('pretrial_freeze_sha256') != digest(freeze_path)
        or release.get('suite_sha256') != freeze['suite_sha256']
        or not release.get('released_utc') or not release.get('authorization')):
        raise RuntimeError('Explicit inference release is missing, incomplete or mismatched')
    for row in freeze['frozen_files'] + freeze['operator_files'] + freeze['prepared_files']:
        if digest(FLOW / row['path']) != row['sha256']:
            raise RuntimeError('Pretrial evaluation snapshot changed: ' + row['path'])
    sys.path.insert(0, str(MIRROR))
    from math_gauge.catalog import Suite
    from math_gauge.execution import runner_fingerprint
    if Suite.load(MIRROR / 'cases/public').sha256 != freeze['suite_sha256']:
        raise RuntimeError('Active suite changed after pretrial freeze')
    if runner_fingerprint() != freeze['runner_sha256']:
        raise RuntimeError('Runner changed after pretrial freeze')
    return freeze, release
