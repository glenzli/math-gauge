from pathlib import Path
import collections,ctypes,datetime,hashlib,json,subprocess,sys
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
lib=ctypes.CDLL('/usr/lib/libsandbox.dylib',use_errno=True);flags=1|ctypes.c_uint.in_dll(lib,'SANDBOX_CHECK_NO_REPORT').value;lib.sandbox_check.restype=ctypes.c_int;lib.sandbox_check.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int]
proc=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True);proc.proc_pidpath.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32];proc.proc_pidpath.restype=ctypes.c_int
records=[]
for cid in ('MG-R001','MG-R002'):
 run=R/'live-runs'/cid;e=json.loads((run/'runtime/execution.json').read_text());pid=e['parent_pid'];buf=ctypes.create_string_buffer(4096);assert proc.proc_pidpath(pid,buf,len(buf))>0
 executable=buf.value.decode();identity=json.loads((run/'runtime/cli-identity.json').read_text());assert executable==identity['resolved_binary']
 out=run/'runtime/worker-pid-check-live.json';cp=subprocess.run([str(Path(sys.executable).resolve()),'-B',str(run/'runtime/probe.py'),'--manifest',str(run/'runtime/probes.json'),'--pid',str(pid),'--role','worker','--out',str(out)],capture_output=True);assert cp.returncode==0
 checks=[]
 for path,allow in [('/Users/g4i/.codex/installation_id',True),('/Users/g4i/.codex/auth.json',False),('/Users/g4i/.codex/config.toml',False),('/Users/g4i/.codex/AGENTS.md',False)]:
  code=lib.sandbox_check(pid,b'file-write-data',flags,ctypes.c_char_p(path.encode()));checks.append({'path':path,'expected':'allowed' if allow else 'denied','result':code,'passed':code==0 if allow else code>0})
 report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'live-pid-write-policy-query','pid':pid,'actual_write_performed':False,'checks':checks,'passed':all(x['passed'] for x in checks)};(run/'runtime/write-pid-check-live.json').write_text(json.dumps(report,indent=2)+'\n');assert report['passed']
 types=collections.Counter()
 for l in (run/'output/events.ndjson').read_text().splitlines():
  try:d=json.loads(l)
  except ValueError:continue
  types[d.get('type')]+=1
 assert types['thread.started']==types['turn.started']==1
 records.append({'case':cid,'pid':pid,'actual_executable':executable,'actual_executable_sha256':hashlib.sha256(Path(executable).read_bytes()).hexdigest(),'worker_mode':'Same-process app-server, per binary startup architecture and continuous descendant process-tree polling.','live_worker_policy_passed':True,'live_write_policy_passed':report['passed'],'event_types_at_acceptance':dict(types),'backend_json_model_identity_echo':None})
(R/'live-runtime-acceptance.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'file_isolation_passed':True,'network_exception_verified':'Only localhost7897; 22/4000/7898 and IPv6 other ports denied.','mathematical_answers_read':False},indent=2)+'\n');print(json.dumps({'accepted_cases':[x['case'] for x in records]}))
