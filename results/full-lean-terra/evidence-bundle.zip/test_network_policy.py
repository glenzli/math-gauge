from pathlib import Path
import json,subprocess,sys
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow');D=R/'network-policy-tests';D.mkdir(exist_ok=False)
probe=R/'final-runs/MG-R001/runtime/network-probe.py';python=str(Path(sys.executable).resolve())
variants={'plain':'(version 1)\n(allow default)\n','tcp-exclude':'(version 1)\n(allow default)\n(deny network-outbound (require-all (remote ip "localhost:*") (require-not (remote tcp "localhost:7897"))))\n','ip-numeric-exclude':'(version 1)\n(allow default)\n(deny network-outbound (require-all (remote ip "localhost:*") (require-not (remote ip "127.0.0.1:7897"))))\n','tcp-numeric-exclude':'(version 1)\n(allow default)\n(deny network-outbound (require-all (remote ip "localhost:*") (require-not (remote tcp "127.0.0.1:7897"))))\n'}
results=[]
for name,profile in variants.items():
 sb=D/(name+'.sb');sb.write_text(profile);out=D/(name+'.json');argv=['/usr/bin/sandbox-exec','-f',str(sb),python,'-B',str(probe),str(out)];cp=subprocess.run(argv,capture_output=True,timeout=30);(D/(name+'.stderr.txt')).write_bytes(cp.stderr);d=json.loads(out.read_text()) if out.exists() else None;results.append({'variant':name,'exit_code':cp.returncode,'report':d});print(name,cp.returncode,d['checks'] if d else cp.stderr.decode(),flush=True)
(D/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
