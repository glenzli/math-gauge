from pathlib import Path
import datetime,hashlib,json,subprocess,sys
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow');script=R/'run_cases_live.py';out=R/'queue-live.stdout.txt';err=R/'queue-live.stderr.txt'
assert not (R/'queue-live-supervisor.json').exists()
with out.open('xb') as o,err.open('xb') as e:
 p=subprocess.Popen([str(Path(sys.executable).resolve()),'-B',str(script)],cwd=R,stdin=subprocess.DEVNULL,stdout=o,stderr=e,start_new_session=True)
d={'pid':p.pid,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':str(script),'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'stdout':str(out),'stderr':str(err),'max_parallel':2,'per_case_timeout_seconds':2700,'cases':['MG-R'+str(i).zfill(3) for i in range(1,11)],'fresh_run_root':str(R/'live-runs'),'halts_new_starts_if_startup_or_tool_mismatch':True,'no_automatic_model_retry':True}
(R/'queue-live-supervisor.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
