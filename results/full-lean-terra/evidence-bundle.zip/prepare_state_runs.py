from pathlib import Path
import datetime, hashlib, importlib.util, json, sys
sys.dont_write_bytecode=True
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
source=R/'tools/prepare.py';patched=R/'tools/prepare_state.py'
s=source.read_text();needle='"model_reasoning_effort": config["effort"], "approval_policy": "never",';replacement=needle+'\n            "sqlite_home": str(run_dir / "state/sqlite"),\n            "log_dir": str(run_dir / "state/log"),'
assert s.count(needle)==1
patched.write_text(s.replace(needle,replacement))
save(R/'state-runtime-extension.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_helper_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'extended_helper':'tools/prepare_state.py','extended_helper_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),'only_change':{'sqlite_home':'<new_run>/state/sqlite','log_dir':'<new_run>/state/log'},'official_source':'https://developers.openai.com/codex/config-reference/','reason':'Keep necessary SQLite state and logs inside fresh per-run state while preserving HOME and CODEX_HOME. No read denials or candidate inputs changed.','startup_recovery_authorization':'Parent explicitly authorized fresh-directory recovery before any answer existed.'})
spec=importlib.util.spec_from_file_location('state_helper',patched);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
(R/'sessions').mkdir(exist_ok=False)
(R/'configs-state').mkdir(exist_ok=False)
for config_path in sorted((R/'configs').glob('*.json')):
 cfg=json.loads(config_path.read_text());cfg['run_dir']=str(R/'sessions'/config_path.stem);save(R/'configs-state'/config_path.name,cfg);h.prepare(cfg)
print('prepared',len(list((R/'sessions').iterdir())))
