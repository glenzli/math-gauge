# 逐层记录的承载与相容性分类

采用 ZFC，固定 Grothendieck 宇宙 $\mathcal U\in\mathcal V$，且 $\mathbb N\in\mathcal U$。记 $\mathbf{Ab}_{\mathcal U}$ 为底集属于 $\mathcal U$ 的阿贝尔群及群同态组成的范畴。给定 $\mathbf{Ab}_{\mathcal U}$ 中有限秩自由阿贝尔群的逆向塔

$$P_0\xleftarrow{\rho_0}P_1\xleftarrow{\rho_1}P_2\xleftarrow{\rho_2}\cdots.$$

对 $m\ge n$，记 $\rho_{n,m}:P_m\to P_n$ 为过渡映射的复合，且 $\rho_{n,n}=I$。对每个 $A\in\mathbf{Ab}_{\mathcal U}$，定义

$$F_{\mathbf P}(A)=\varinjlim_{n\ge0}\operatorname{Hom}_{\mathbb Z}(P_n,A),$$

其中过渡为 $u\mapsto u\rho_n$。具体地，记录 $(n,u)$ 与 $(m,v)$ 相同，当且仅当存在 $r\ge n,m$ 使 $u\rho_{n,r}=v\rho_{m,r}$。记录在共同层相加；群同态通过后复合诱导记录之间的映射。

建立这类记录函子的分类理论。对于任意给定塔，给出一个由塔确定的充要判据，刻画何时存在 $P\in\mathbf{Ab}_{\mathcal U}$ 以及对所有 $A$ 自然的群同构

$$F_{\mathbf P}(A)\cong\operatorname{Hom}_{\mathbb Z}(P,A),$$

并在存在时构造全部表示对象，精确到同构。另给出充要判据，使对于每个对象集与箭头集均可数的 $\mathcal U$ 小范畴 $J$ 及每个图表 $D:J\to\mathbf{Ab}_{\mathcal U}$，典范比较映射

$$F_{\mathbf P}\!\left(\varprojlim_{j\in J}D(j)\right)
\longrightarrow\varprojlim_{j\in J}F_{\mathbf P}(D(j))$$

均为同构，并确定这两个判据之间的关系。最后，对任意两个这样的塔，描述它们的记录函子之间的全部自然变换、恒等变换和复合。请给出主定理、构造及完整论证。
