# 群作用下局部记录的下降分类

采用 ZFC，固定 Grothendieck 宇宙 $\mathcal U\in\mathcal V$，且 $\mathbb N\in\mathcal U$。令 $\operatorname{Prof}_{\mathcal U}$ 为底集属于 $\mathcal U$ 的紧、Hausdorff、全不连通空间及连续映射组成的范畴，覆盖为有限联合满射族，包括空空间的空覆盖。记 $\mathcal C$ 为其上的 $\mathbf{Set}_{\mathcal V}$ 值层范畴：局部元素若在两两纤维积上相等，就唯一地粘合成全局元素。对 $T\in\operatorname{Prof}_{\mathcal U}$，记 $h_T(U)=C(U,T)$。

给定底集属于 $\mathcal U$ 的群 $\Gamma$、一个 $T\in\operatorname{Prof}_{\mathcal U}$，以及群同态 $\Gamma\to\operatorname{Homeo}(T)$，记作用为 $\gamma t$。群 $\Gamma$ 赋离散拓扑。

一个 $T$ 上的等变记录对象，是层 $E\in\mathcal C$、态射 $\pi:E\to h_T$，以及满足群作用律的层自同构 $a_\gamma:E\to E$，使 $\pi a_\gamma=h_\gamma\pi$。对象之间的映射是与 $\pi$ 及全部 $a_\gamma$ 相容的层态射。

建立这些对象的下降分类。先构造层 $Q$ 及 $\Gamma$ 不变态射 $q:h_T\to Q$，使对每个 $Y\in\mathcal C$，与 $q$ 复合给出自然双射

$$\operatorname{Hom}_{\mathcal C}(Q,Y)
\cong\{b:h_T\to Y:\ b h_\gamma=b\text{ 对每个 }\gamma\in\Gamma\}.$$

称一个等变记录对象 $E$ 在 $Q$ 上可实现，是指存在 $p:D\to Q$ 和等变同构

$$E\cong h_T\times_Q D,$$

右侧的作用只改变 $h_T$ 坐标。给出不依赖预先选取 $D$ 的充要判据，分类哪些等变记录对象可实现，并描述全部实现及其间映射。

对于每个 $B\in\mathcal C$ 及态射 $B\to Q$，还要给出以 $h_T\times_Q B$ 为起点的相应分类，并确定实现的拉回如何对应于等变对象的拉回。请给出主定理、构造及完整论证。
