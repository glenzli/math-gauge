# 双重平均与迭代恢复

设 $E$ 为实 Banach 空间，$T,S:E\to E$ 为交换的有界线性算子。已知

$$K_T=\sup_{n\ge0}\|T^n\|<\infty,\qquad K_S=\sup_{m\ge0}\|S^m\|<\infty.$$

令

$$A_{N,M}=\frac1{NM}\sum_{i=0}^{N-1}\sum_{j=0}^{M-1}T^iS^j\qquad(N,M\ge1),$$

$$R=\frac14(I+T)(I+S).$$

状态 $x\in E$ 的记录是它在 Banach 商空间

$$Q=E/Y,\qquad Y=\overline{(I-T)E+(I-S)E}$$

中的像 $q(x)$，其中闭包取范数闭包。双重平均的极限按 $\min(N,M)\to\infty$ 理解，迭代的极限按 $n\to\infty$ 理解。

用单算子迭代 $R^n$ 建立与双重平均 $A_{N,M}$ 等价的记录恢复理论。目标是证明：对每个 $x\in E$，两种过程的范数收敛性等价，收敛时得到同一状态；并从 $T,S$ 和 $q$ 完整确定这个恢复映射的定义域、值域及其稳定性。请给出主定理、恢复映射及完整论证。
