from pathlib import Path
import datetime, hashlib, importlib.util, json, os, shutil, subprocess, sys
sys.dont_write_bytecode = True
REPO=Path('/Users/g4i/lab/math-gauge')
ROOT=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,d):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f: json.dump(d,f,ensure_ascii=False,indent=2); f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
TOOLS=ROOT/'tools'; TOOLS.mkdir(exist_ok=False)
for n in ('prepare.py','probe.py'):
 shutil.copyfile(REPO/'scripts/isolated_cli'/n,TOOLS/n)
save(ROOT/'tool-source-identity.json',{'recorded_utc':now(),'files':[{'source':str(REPO/'scripts/isolated_cli'/n),'copy':'tools/'+n,'sha256':sha(TOOLS/n)} for n in ('prepare.py','probe.py')]})
F=ROOT/'evaluator-freeze'; F.mkdir(exist_ok=False)
suite=json.loads((REPO/'cases/public/suite.json').read_text())
names=['suite.json','sources.json']
for m in suite['cases']:
 c=json.loads((REPO/'cases/public'/m).read_text()); assert c['version']=='0.3.0' and c['candidate_instruction']=='' and c['solver_files']==[]
 names += [m,c['task'],c['reference'],c['rubric']]+c.get('evaluator_files',[])+c.get('lean_checks',[])
entries=[]
for n in sorted(set(names)):
 src=REPO/'cases/public'/n; data=src.read_bytes(); dst=F/n; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(data)
 entries.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
sys.path.insert(0,str(REPO))
from math_gauge.catalog import Suite
from math_gauge.execution import runner_fingerprint
loaded=Suite.load(F)
freeze={'schema':'math-gauge.pre-run-freeze/v1','recorded_utc':now(),'source_root':str(REPO/'cases/public'),'suite_version':loaded.metadata['version'],'suite_sha256':loaded.sha256,'runner_sha256':runner_fingerprint(),'task_only':True,'selection_policy':'Exactly one mathematical stdin submission per case; do not retry or select based on answer quality. Startup attempts with zero submissions remain in ledger. Tool mismatch, failure, and timeout are retained. Any additional mathematical run requires pre-answer documented environment reason and parent authorization.','files':entries,'mathematical_assessment':None}
save(ROOT/'pre-run-freeze.json',freeze)
identdir=ROOT/'cli-inspection'
cp=subprocess.run([sys.executable,'-B',str(TOOLS/'prepare.py'),'inspect','--client','codex','--binary','/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex','--out',str(identdir)],capture_output=True)
(ROOT/'cli-inspection.stdout.json').write_bytes(cp.stdout); (ROOT/'cli-inspection.stderr.txt').write_bytes(cp.stderr)
assert cp.returncode==0,(cp.returncode,cp.stderr.decode())
cache=Path('/Users/g4i/.codex/models_cache.json'); d=json.loads(cache.read_text()); m=next(x for x in d['models'] if x.get('slug')=='gpt-6.1-terra')
selected={k:m[k] for k in ('slug','display_name','default_reasoning_level','supported_reasoning_levels','visibility','supported_in_api','context_window','max_context_window') if k in m}
metadata={'recorded_utc':now(),'source':str(cache),'source_file_sha256':sha(cache),'source_fetched_at':d.get('fetched_at'),'client_version':d.get('client_version'),'model':selected,'model_messages_included':False,'credential_content_read':False,'scope':'Current non-inference cached model inventory; runtime backend model and effort observations remain separate.'}
assert any(x['effort']=='max' for x in selected['supported_reasoning_levels'])
save(ROOT/'model-inventory.json',metadata)
identity=json.loads((identdir/'identity.json').read_text()); assert identity['version'].endswith(d['client_version'])
(RootRuns:=ROOT/'runs').mkdir(exist_ok=False)
history=next(Path('/Users/g4i/.codex/sessions').rglob('*.jsonl.zst'))
probes=[{'category':'reference','path':str(REPO/'cases/public/MG-R001/reference.md')},{'category':'history','path':str(history)},{'category':'prior_run','path':str(REPO/'results/recursive-operator-closure/terra61max-isolated-20261029/output/response.md')},{'category':'memory','path':'/Users/g4i/.codex/memories/MEMORY.md'},{'category':'global_config','path':'/Users/g4i/.codex/config.toml'},{'category':'global_rules','path':'/Users/g4i/.codex/AGENTS.md'},{'category':'temporary_reference','path':'/private/tmp/math-gauge-reference-20261029/Reference.lean'},{'category':'evaluator_freeze','path':str(F/'MG-R001/reference.md')},{'category':'other_workspace','path':'/Users/g4i/lab/oet-dev/AGENTS.md'},{'category':'global_state','path':'/Users/g4i/.codex/state_5.sqlite'},{'category':'data_volume_alias','path':'/System/Volumes/Data/Users/g4i/lab/math-gauge/cases/public/MG-R001/reference.md'}]
for probe in probes: assert Path(probe['path']).is_file(),probe
configs=ROOT/'configs'; configs.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('mg_isolated_prepare',TOOLS/'prepare.py'); helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
for cid,c in loaded.cases.items():
 cfg={'schema':'math-gauge.isolated-cli/v1','client':'codex','cli_identity':str(identdir/'identity.json'),'prompt':str(F/c['task']),'run_dir':str(RootRuns/cid),'model':'gpt-6.1-terra','effort':'max','deny_read_roots':['/Users/g4i','/System/Volumes/Data/Users/g4i','/private/tmp','/private/var/folders','/Volumes/Data'],'read_exceptions':[{'path':identity['resolved_binary'],'kind':'literal','purpose':'CLI executable installation identity'},{'path':'/Users/g4i/.codex/auth.json','kind':'literal','purpose':'Existing login only; contents are never copied or logged'}],'credential_links':[],'probes':probes}
 save(configs/(cid+'.json'),cfg)
 helper.prepare(cfg)
records=[{'id':'initial-help-observation','kind':'inspection','started_utc':freeze['recorded_utc'],'request_count':0,'status':'completed','reason':'Read CLI app-server help only, before preparation; no model invocation.','evidence':['cli-inspection/identity.json']},{'id':'selected-cli-inspection','kind':'inspection','started_utc':identity['recorded_utc'],'request_count':0,'status':'completed','reason':'Fresh selected executable version, help, and exec help; immutable binary hash.','evidence':['cli-inspection/identity.json','cli-inspection.stdout.json','cli-inspection.stderr.txt']},{'id':'model-cache-inventory','kind':'inventory','started_utc':metadata['recorded_utc'],'request_count':0,'status':'completed','reason':'Selected current non-inference model inventory metadata; max supported.','evidence':['model-inventory.json']}]
save(ROOT/'attempt-ledger.json',{'attempts':records,'tool_mismatch_decisions':[],'mathematical_requests':0})
print(json.dumps({'suite_sha256':loaded.sha256,'runner_sha256':freeze['runner_sha256'],'cases':list(loaded.cases),'identity':identity['version'],'metadata_fetched_at':metadata['source_fetched_at'],'freeze_files':len(entries)}))
