from pathlib import Path
import collections,datetime,json,os
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
def read(p):return json.loads(p.read_text())
rows=[]
for run in sorted((R/'live-runs').iterdir()):
 p=run/'runtime/execution.json';e=read(p) if p.exists() else {};types=collections.Counter();items=collections.Counter()
 events=run/'output/events.ndjson'
 if events.exists():
  for l in events.read_text().splitlines():
   try:d=json.loads(l)
   except ValueError:continue
   types[d.get('type')]+=1
   if isinstance(d.get('item'),dict):items[d['item'].get('type')]+=1
 pid=e.get('parent_pid');alive=False
 if pid:
  try:os.kill(pid,0);alive=True
  except ProcessLookupError:pass
  except PermissionError:alive=True
 rows.append({'case':run.name,'status':'not-started' if not e else 'running' if alive and e.get('finished_utc') is None else 'completed' if e.get('exit_code')==0 else 'failed','pid':pid,'worker_pids':e.get('worker_pids',[]),'stdin_submissions':e.get('request_count',0),'event_types':dict(types),'item_types':dict(items),'response_bytes':(run/'output/response.md').stat().st_size if (run/'output/response.md').exists() else None,'failure':e.get('failure')})
ledger=read(R/'attempt-ledger.json')
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'supervisor':read(R/'queue-live-supervisor.json'),'global_stdin_submissions':sum(a.get('request_count',0) for a in ledger['attempts']),'prior_zero_event_failures':sum(a.get('status')=='failed' for a in ledger['attempts']),'runs':rows,'mathematical_assessment':None},ensure_ascii=False,indent=2))
