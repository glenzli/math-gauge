from pathlib import Path
import datetime, json, subprocess, sys
ROOT=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
python=str(Path(sys.executable).resolve())
reports=[]
for run in sorted((ROOT/'runs').iterdir()):
 p=json.loads((run/'runtime/plan.json').read_text())
 argv=p['argv'][:3]+[python,'-B',str(run/'runtime/probe.py'),'--manifest',str(run/'runtime/probes.json'),'--out',str(run/'runtime/open-probe.json')]
 cp=subprocess.run(argv,capture_output=True,timeout=30)
 (run/'runtime/open-probe-host.stdout.txt').write_bytes(cp.stdout); (run/'runtime/open-probe-host.stderr.txt').write_bytes(cp.stderr)
 result=json.loads((run/'runtime/open-probe.json').read_text()) if (run/'runtime/open-probe.json').exists() else None
 reports.append({'case':run.name,'argv':argv,'exit_code':cp.returncode,'passed':bool(result and result['passed']),'negative_count':len(result['checks'])-1 if result else None})
 print(run.name,cp.returncode,reports[-1]['passed'],flush=True)
(ROOT/'open-probe-host-summary.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reports':reports},indent=2)+'\n')
raise SystemExit(0 if all(x['passed'] for x in reports) else 1)
