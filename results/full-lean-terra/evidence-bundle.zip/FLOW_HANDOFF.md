# Math Gauge isolated Terra queue handoff

Root: `/private/tmp/math-gauge-full-lean-20261029/flow`.

The durable supervisor is PID **20199**, launched with a new session and stdin closed. It runs `run_cases_live.py`, with two fresh independent candidate processes at a time. It continues independently of the Codex subagent. Candidate model is exactly `gpt-6.1-terra`, effort `max`. Candidate stdin is exactly the frozen `task.md` bytes, one write and no follow-up. Every subprocess has the complete immutable argv from its own `runtime/plan.json`. Per-case timeout is 2700 seconds. New starts halt on a startup failure before turn.started or on an unexpected tool event. No automatic retry based on an answer exists.

Read status without reading mathematical answer contents:

```sh
python3 -B /private/tmp/math-gauge-full-lean-20261029/flow/monitor_flow.py
```

Supervisor output: `queue-live.stdout.txt`; supervisor diagnostics: `queue-live.stderr.txt`; durable identity: `queue-live-supervisor.json`. The per-run root is `live-runs/MG-R001` through `MG-R010`. Each has `input/task.md`, raw `output/events.ndjson`, `output/stderr.txt`, CLI-written `output/response.md`, and `runtime/execution.json`. The queue writes `run-live-summary.partial.json` as cases finish, then `run-live-summary.json` at termination. These are engineering records with no mathematical scoring.

Before stdin, every parent process and same-process app-server worker is identified by actual executable path and SHA256, proven new relative to a prelaunch process snapshot, and checked through live-PID macOS policy queries. This CLI reports in-process app-server architecture; worker and parent share the same PID. The launcher continues scanning the descendant tree every 0.4 seconds and separately records/checks any additional codex worker. Initial live processes were MG-R001 PID 20225 and MG-R002 PID 20231; both reached thread.started and turn.started. Their normal before-submission parent and worker reports are preserved. A later optional extra live acceptance attempt ran after those PIDs had already exited; its assertion failed before generating a new report and does not invalidate the already saved PID checks.

Every live run passed twelve actual negative file-open probes, including reference, history, previous answer, memory, global config/rules/state, temporary reference, evaluator snapshot, other workspace, Data-volume alias and sibling attempt. Positive task reads matched SHA256. Real TCP probes prove only the authorized loopback proxy port 7897 connects while ports 22, 4000, 7898 and IPv6 7898 return EPERM/EACCES. All read-denial roots and tool-disable settings remain intact. Runtime SQLite/logs are redirected to each run's state directory. HOME and CODEX_HOME remain unchanged. The only existing user file with a required precise write-back exception is `.codex/installation_id`; its content SHA256 was checked unchanged after startup and is checked again after every run. Authentication and config writes remain denied. No credentials are copied.

Frozen evaluator snapshot is `evaluator-freeze/`, manifest `pre-run-freeze.json`. Frozen suite SHA256 is `59c8c5f1d8927a4514039061f32ebc1fd2e14f8dcef383f7369147af475283f4`; runner SHA256 is `61dc60ddf73292c5f517a23bedaeb10a5813cdf92eafccbf09530d7ee10055c7`. Source fixture snapshot contains 82 explicit files. Actual CLI is `0.165.0-alpha.1.2`, binary SHA256 `d84a54b031085f01e3ad915ea7c72ebea4dcf69e90f0d1e0e4a637e8280991d2`. Current model inventory is saved separately. The JSON event stream does not echo a server-signed backend model identity or effort, so observed_model/observed_effort remain null; exact requested strict-start settings and accepted runtime are separate evidence. No extra capability-canary model call was made. Effective tool events are audited.

All earlier failures are retained under `runs/`, `sessions/`, `final-runs/`, `accepted-runs/`, network policy experiments, preparation-attempt records and the global `attempt-ledger.json`. Five prior stdin submissions failed before any JSON model event or answer. Their exclusion/recovery decisions were made before any answer existed and were explicitly authorized by the parent. They must not be silently dropped or called successful mathematical samples.

After or while the queue runs, the finalizer can be invoked once. It waits for final queue summary, audits all ten runs, checks exact input and output hashes, counts events without mathematical scoring, scans the explicit archive whitelist for credential-like strings, and creates a ZIP from that whitelist only:

```sh
python3 -B /private/tmp/math-gauge-full-lean-20261029/flow/finalize_flow.py
```

Deliverables: `final-engineering-report.json`, `evidence-whitelist.json`, `credential-scan.json`, `evidence-bundle.zip`, `archive-identity.json`. No state directory, database, authentication file, credential link or installation_id content is archived. A credential-like match blocks ZIP creation and prints paths only; originals are never overwritten. This does not perform mathematical review or mark any human approval. Parent should inspect final report issues and model-identity limits before canonical promotion. No canonical files were changed, committed or pushed by this flow agent.
