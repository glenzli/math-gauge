"""Wait for queue termination, audit engineering evidence, build explicit non-state archive."""
from pathlib import Path
import collections,datetime,hashlib,importlib.util,json,re,sys,time,zipfile
sys.dont_write_bytecode=True
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):
 with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
summary=R/'run-live-summary.json'
while not summary.exists():time.sleep(5)
queue=read(summary)
spec=importlib.util.spec_from_file_location('helper',R/'tools/prepare_live.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
issues=[];case_reports=[]
for run in sorted((R/'live-runs').iterdir()):
 execution_path=run/'runtime/execution.json'
 if not execution_path.exists():issues.append(run.name+': not started');continue
 e=read(execution_path);a=h.audit(run);save(run/'runtime/local-audit.json',a)
 counts=collections.Counter();items=collections.Counter()
 ep=run/'output/events.ndjson'
 for l in ep.read_text().splitlines() if ep.exists() else []:
  try:d=json.loads(l)
  except ValueError:continue
  counts[d.get('type')]+=1
  if isinstance(d.get('item'),dict):items[d['item'].get('type')]+=1
 tools={k:v for k,v in items.items() if k not in ('agent_message','reasoning','error','todo_list')}
 if e.get('exit_code')!=0 or e.get('request_count')!=1:issues.append(run.name+': non-completion or non-single stdin')
 if counts['turn.completed']!=1:issues.append(run.name+': expected one completed turn')
 if not a['artifact_checks_passed'] or not a['runtime_reports_complete']:issues.append(run.name+': local audit failed/incomplete')
 if tools:issues.append(run.name+': unexpected tool events')
 if e.get('installation_id_content_unchanged') is not True:issues.append(run.name+': installation identity changed')
 if not read(run/'runtime/network-probe.json')['passed']:issues.append(run.name+': network probe failed')
 case_reports.append({'case':run.name,'stdin_submissions':e.get('request_count'),'exit_code':e.get('exit_code'),'elapsed_seconds':e.get('elapsed_seconds'),'parent_pid':e.get('parent_pid'),'worker_pids':e.get('worker_pids'),'worker_structure':e.get('worker_structure'),'requested_model':e.get('requested_model'),'requested_effort':e.get('requested_effort'),'observed_model':e.get('observed_model'),'observed_effort':e.get('observed_effort'),'backend_identity_limit':e.get('model_metadata_limit'),'local_audit_passed':a['artifact_checks_passed'],'file_probes_passed':read(run/'runtime/open-probe.json')['passed'],'network_probes_passed':read(run/'runtime/network-probe.json')['passed'],'event_types':dict(counts),'item_types':dict(items),'tool_events':tools,'response':e.get('artifact_hashes',{}).get('output/response.md'),'mathematical_review':None})
ledger=read(R/'attempt-ledger.json')
report={'utc':now(),'queue_summary':queue,'cases':case_reports,'engineering_checks_passed':not issues,'issues':issues,'suite_sha256':read(R/'pre-run-freeze.json')['suite_sha256'],'model':'gpt-6.1-terra','effort':'max','all_stdin_submissions_including_failed_startups':sum(a.get('request_count',0) for a in ledger['attempts']),'failed_attempts_preserved':[a['id'] for a in ledger['attempts'] if a.get('status')=='failed'],'all_answers_mathematically_unreviewed':True,'human_approval':False,'state_and_credentials_archived':False,'independent_supplier_model_identity':'Not separately reported by CLI JSON; exact selected strict-start argv, effective worker PID and current inventory are preserved. Do not label this server-signed identity.'}
save(R/'final-engineering-report.json',report)
# An explicit list is constructed from data-free known artifact names; no state tree is walked.
names=set()
root_names=['pre-run-freeze.json','tool-source-identity.json','cli-inspection.stdout.json','cli-inspection.stderr.txt','model-inventory.json','attempt-ledger.json','preparation-attempts.json','state-runtime-extension.json','final-policy-extension.json','accepted-policy-extension.json','live-policy-extension.json','installation-id-before.json','open-probe-summary.json','open-probe-host-summary.json','open-probe-state-summary.json','open-probe-final-summary.json','open-probe-accepted-summary.json','open-probe-live-summary.json','run-summary.json','run-state-summary.json','run-accepted-summary.json','run-live-summary.json','queue-supervisor.json','queue-live-supervisor.json','queue.stdout.txt','queue.stderr.txt','queue-live.stdout.txt','queue-live.stderr.txt','launch-batch-1.stdout.txt','launch-batch-1.stderr.txt','launch-state-batch-1.stdout.txt','launch-state-batch-1.stderr.txt','final-engineering-report.json','live-runtime-acceptance.json','FLOW_HANDOFF.md','prepare_all.py','resume_prepare.py','resume_prepare2.py','open_all.py','open_host.py','open_state.py','open_final.py','open_accepted.py','open_live.py','prepare_state_runs.py','prepare_final_runs.py','prepare_accepted_runs.py','prepare_live_runs.py','run_cases.py','run_cases_state.py','run_cases_final.py','run_cases_accepted.py','run_cases_live.py','start_queue.py','start_live_queue.py','monitor_flow.py','finalize_flow.py','test_network_policy.py','test_network_policy2.py','accept_live_runtime.py']
for n in root_names:
 if (R/n).is_file():names.add(n)
for n in ('prepare.py','probe.py','prepare_state.py','prepare_final.py','prepare_accepted.py','prepare_live.py'):names.add('tools/'+n)
for n in ('identity.json','0-stdout.txt','0-stderr.txt','1-stdout.txt','1-stderr.txt','2-stdout.txt','2-stderr.txt'):names.add('cli-inspection/'+n)
for item in read(R/'pre-run-freeze.json')['files']:names.add('evaluator-freeze/'+item['path'])
for directory in ('configs','configs-state','configs-final','configs-accepted','configs-live'):
 for i in range(1,11):
  n=directory+'/MG-R'+str(i).zfill(3)+'.json'
  if (R/n).is_file():names.add(n)
rt_names=['probe.py','cli-identity.json','outer.sb','codex-settings.json','probes.json','plan.json','attempt-ledger.json','execution.template.json','prepared-hashes.json','execution.json','open-probe.json','open-probe.stdout.txt','open-probe.stderr.txt','open-probe-host.stdout.txt','open-probe-host.stderr.txt','open-probe-state.stdout.txt','open-probe-state.stderr.txt','parent-pid-check.json','worker-pid-check.json','worker-pid-check-live.json','process-identity.json','process-identity-final.json','policy-exceptions.json','network-probe.py','network-probe.json','network-probe.stdout.txt','network-probe.stderr.txt','thread-metadata-live.json','local-audit.json','write-pid-check-live.json']
for stage in ('runs','sessions','final-runs','accepted-runs','live-runs'):
 for i in range(1,11):
  base=stage+'/MG-R'+str(i).zfill(3)
  for n in ['input/task.md','output/events.ndjson','output/stderr.txt','output/response.md']+['runtime/'+x for x in rt_names]:
   path=R/base/n
   if path.is_file():names.add(base+'/'+n)
  for path in (R/base/'runtime').glob('worker-pid-check-*.json'):
   names.add(path.relative_to(R).as_posix())
for testdir,variants in [('network-policy-tests',('plain','tcp-exclude','ip-numeric-exclude','tcp-numeric-exclude')),('network-policy-tests-2',('ip-wildcard-exclude','tcp-wildcard-exclude','allow-specific-after','allow-specific-ip-after'))]:
 for n in ['summary.json']+[v+ext for v in variants for ext in ('.sb','.json','.stderr.txt')]:
  if (R/testdir/n).is_file():names.add(testdir+'/'+n)
for pid in (14674,18989):
 for suffix in ('.json','.stderr.txt','-all.json','-all.stderr.txt'):
  n='sandbox-denials-'+str(pid)+suffix
  if (R/n).is_file():names.add(n)
patterns={'token-key':re.compile(rb'\bsk-[A-Za-z0-9_-]{20,}'),'bearer':re.compile(rb'(?i)\bBearer\s+[A-Za-z0-9._-]{16,}'),'credential-json':re.compile(rb'"(?:access_token|refresh_token|id_token)"\s*:\s*"[^"\s]{12,}"'),'private-key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')}
files=[];scan=[]
for n in sorted(names):
 p=R/n
 if p.is_symlink() or not p.resolve().is_relative_to(R) or not p.is_file():raise RuntimeError('Unsafe evidence path: '+n)
 if 'state' in p.relative_to(R).parts or p.suffix in ('.sqlite','.sqlite-shm','.sqlite-wal') or p.name in ('auth.json','installation_id'):raise RuntimeError('Forbidden evidence path: '+n)
 data=p.read_bytes()
 hits=[label for label,pattern in patterns.items() if pattern.search(data)]
 # This scanner's own source contains the pattern names, but no credential values.
 if hits:scan.append({'path':n,'patterns':hits})
 files.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
save(R/'credential-scan.json',{'utc':now(),'patterns':list(patterns),'hits':scan,'credential_values_printed':False,'rule':'Any candidate match blocks archival; originals are never rewritten.'})
save(R/'evidence-whitelist.json',{'utc':now(),'root':str(R),'files':files,'state_included':False,'credentials_included':False,'credential_scan_passed':not scan,'engineering_checks_passed':not issues,'mathematical_scoring_performed':False})
if scan:raise RuntimeError('Credential-like match blocks archive; see credential-scan.json for paths only')
archive=R/'evidence-bundle.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for file in files:z.write(R/file['path'],file['path'])
 z.write(R/'evidence-whitelist.json','evidence-whitelist.json');z.write(R/'credential-scan.json','credential-scan.json')
save(R/'archive-identity.json',{'utc':now(),'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'whitelist':'evidence-whitelist.json','engineering_checks_passed':not issues,'mathematical_review':None})
print(json.dumps({'archive':str(archive),'whitelist':str(R/'evidence-whitelist.json'),'report':str(R/'final-engineering-report.json'),'engineering_checks_passed':not issues,'issues':issues,'file_count':len(files)}),flush=True)
raise SystemExit(0 if not issues else 1)
