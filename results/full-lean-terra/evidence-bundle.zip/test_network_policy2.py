from pathlib import Path
import json,subprocess,sys
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow');D=R/'network-policy-tests-2';D.mkdir(exist_ok=False)
probe=R/'final-runs/MG-R001/runtime/network-probe.py';python=str(Path(sys.executable).resolve())
variants={
 'ip-wildcard-exclude':'(version 1)\n(allow default)\n(deny network-outbound (require-all (remote ip "localhost:*") (require-not (remote ip "*:7897"))))\n',
 'tcp-wildcard-exclude':'(version 1)\n(allow default)\n(deny network-outbound (require-all (remote ip "localhost:*") (require-not (remote tcp "*:7897"))))\n',
 'allow-specific-after':'(version 1)\n(allow default)\n(deny network-outbound (remote ip "localhost:*"))\n(allow network-outbound (remote tcp "localhost:7897"))\n',
 'allow-specific-ip-after':'(version 1)\n(allow default)\n(deny network-outbound (remote ip "localhost:*"))\n(allow network-outbound (remote ip "localhost:7897"))\n'}
results=[]
for name,profile in variants.items():
 sb=D/(name+'.sb');sb.write_text(profile);out=D/(name+'.json');argv=['/usr/bin/sandbox-exec','-f',str(sb),python,'-B',str(probe),str(out)];cp=subprocess.run(argv,capture_output=True,timeout=30);(D/(name+'.stderr.txt')).write_bytes(cp.stderr);d=json.loads(out.read_text()) if out.exists() else None;results.append({'variant':name,'exit_code':cp.returncode,'report':d});print(name,cp.returncode,d['checks'] if d else cp.stderr.decode(),flush=True)
(D/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
