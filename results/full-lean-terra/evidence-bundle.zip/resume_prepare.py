from pathlib import Path
import datetime, hashlib, importlib.util, json, os, shutil, subprocess, sys
sys.dont_write_bytecode=True
REPO=Path('/Users/g4i/lab/math-gauge')
ROOT=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
TOOLS=ROOT/'tools'; F=ROOT/'evaluator-freeze'; identdir=ROOT/'cli-inspection'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,d):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f: json.dump(d,f,ensure_ascii=False,indent=2); f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(REPO))
from math_gauge.catalog import Suite
loaded=Suite.load(F)
freeze=json.loads((ROOT/'pre-run-freeze.json').read_text())
identity=json.loads((identdir/'identity.json').read_text())
metadata=json.loads((ROOT/'model-inventory.json').read_text())
assert identity['version'].startswith('codex-cli '+metadata['client_version'])
(RootRuns:=ROOT/'runs').mkdir(exist_ok=False)
history=next(Path('/Users/g4i/.codex/sessions').rglob('*.jsonl.zst'))
probes=[{'category':'reference','path':str(REPO/'cases/public/MG-R001/reference.md')},{'category':'history','path':str(history)},{'category':'prior_run','path':str(REPO/'results/recursive-operator-closure/terra61max-isolated-20261029/output/response.md')},{'category':'memory','path':'/Users/g4i/.codex/memories/MEMORY.md'},{'category':'global_config','path':'/Users/g4i/.codex/config.toml'},{'category':'global_rules','path':'/Users/g4i/.codex/AGENTS.md'},{'category':'temporary_reference','path':'/private/tmp/math-gauge-reference-20261029/Reference.lean'},{'category':'evaluator_freeze','path':str(F/'MG-R001/reference.md')},{'category':'other_workspace','path':'/Users/g4i/lab/oet-dev/AGENTS.md'},{'category':'global_state','path':'/Users/g4i/.codex/state_5.sqlite'},{'category':'data_volume_alias','path':'/System/Volumes/Data/Users/g4i/lab/math-gauge/cases/public/MG-R001/reference.md'}]
for probe in probes: assert Path(probe['path']).is_file(),probe
configs=ROOT/'configs'; configs.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('mg_isolated_prepare',TOOLS/'prepare.py'); helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
for cid,c in loaded.cases.items():
 cfg={'schema':'math-gauge.isolated-cli/v1','client':'codex','cli_identity':str(identdir/'identity.json'),'prompt':str(F/c['task']),'run_dir':str(RootRuns/cid),'model':'gpt-6.1-terra','effort':'max','deny_read_roots':['/Users/g4i','/System/Volumes/Data/Users/g4i','/private/tmp','/private/var/folders','/Volumes/Data'],'read_exceptions':[{'path':identity['resolved_binary'],'kind':'literal','purpose':'CLI executable installation identity'},{'path':'/Users/g4i/.codex/auth.json','kind':'literal','purpose':'Existing login only; contents are never copied or logged'}],'credential_links':[],'probes':probes}
 save(configs/(cid+'.json'),cfg)
 helper.prepare(cfg)
records=[{'id':'initial-help-observation','kind':'inspection','started_utc':freeze['recorded_utc'],'request_count':0,'status':'completed','reason':'Read CLI app-server help only, before preparation; no model invocation.','evidence':['cli-inspection/identity.json']},{'id':'selected-cli-inspection','kind':'inspection','started_utc':identity['recorded_utc'],'request_count':0,'status':'completed','reason':'Fresh selected executable version, help, and exec help; immutable binary hash.','evidence':['cli-inspection/identity.json','cli-inspection.stdout.json','cli-inspection.stderr.txt']},{'id':'model-cache-inventory','kind':'inventory','started_utc':metadata['recorded_utc'],'request_count':0,'status':'completed','reason':'Selected current non-inference model inventory metadata; max supported.','evidence':['model-inventory.json']}]
save(ROOT/'attempt-ledger.json',{'attempts':records,'tool_mismatch_decisions':[],'mathematical_requests':0})
print(json.dumps({'suite_sha256':loaded.sha256,'runner_sha256':freeze['runner_sha256'],'cases':list(loaded.cases),'identity':identity['version'],'metadata_fetched_at':metadata['source_fetched_at'],'freeze_files':len(entries)}))
