from pathlib import Path
import datetime, hashlib, importlib.util, json, os, sys, urllib.parse
sys.dont_write_bytecode=True
R=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
source=R/'tools/prepare_state.py';patched=R/'tools/prepare_final.py'
s=source.read_text();needle='(deny network-outbound (remote ip "localhost:*"))';replacement='(deny network-outbound (require-all (remote ip "localhost:*") (require-not (remote ip "localhost:7897"))))';assert s.count(needle)==1;patched.write_text(s.replace(needle,replacement))
proxy=[]
for key in ('HTTPS_PROXY','HTTP_PROXY','ALL_PROXY','https_proxy','http_proxy','all_proxy'):
 if key in os.environ:
  v=urllib.parse.urlparse(os.environ[key]);proxy.append({'environment_key':key,'host':v.hostname,'port':v.port});assert v.hostname in ('127.0.0.1','localhost','::1') and v.port==7897
extension={'utc':now(),'original_helper':'tools/prepare_state.py','extended_helper':'tools/prepare_final.py','extended_helper_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),'startup_exceptions':[{'kind':'network','destination':'loopback:7897','purpose':'Existing model-service HTTP proxy; all other localhost ports remain denied.','sanitized_proxy_metadata':proxy},{'kind':'file-read-literal','path':'/Users/g4i/.codex/installation_id','purpose':'Non-history CLI installation identity required at startup; content is not copied or logged.'}],'unchanged_contracts':['HOME','CODEX_HOME','login location','model gpt-6.1-terra','effort max','all task bytes','all reference/history/memory/project deny roots','all tool-disable settings'],'authorization':'Parent explicitly approved these two precise exceptions before any answer existed.'}
save(R/'final-policy-extension.json',extension)
spec=importlib.util.spec_from_file_location('final_helper',patched);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
(R/'final-runs').mkdir(exist_ok=False);(R/'configs-final').mkdir(exist_ok=False)
network_code='''from pathlib import Path
import datetime,errno,json,socket,sys
checks=[]
for host,port,expected in [('127.0.0.1',7897,'allowed'),('127.0.0.1',22,'denied'),('127.0.0.1',7898,'denied'),('127.0.0.1',4000,'denied'),('::1',7898,'denied')]:
 s=socket.socket(socket.AF_INET6 if ':' in host else socket.AF_INET,socket.SOCK_STREAM);s.settimeout(3)
 try:
  s.connect((host,port)); outcome='CONNECTED';code=0
 except OSError as e:code=e.errno;outcome='DENIED' if code in (errno.EPERM,errno.EACCES) else 'OTHER_ERROR'
 finally:s.close()
 checks.append({'host':host,'port':port,'expected':expected,'outcome':outcome,'errno':code,'passed':outcome==('CONNECTED' if expected=='allowed' else 'DENIED')})
report={'kind':'actual-network-connect','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'data_sent':False,'checks':checks,'passed':all(c['passed'] for c in checks)}
with Path(sys.argv[1]).open('x') as f:json.dump(report,f,indent=2);f.write('\\n')
raise SystemExit(0 if report['passed'] else 1)
'''
for config_path in sorted((R/'configs-state').glob('*.json')):
 cfg=json.loads(config_path.read_text());cfg['run_dir']=str(R/'final-runs'/config_path.stem);cfg['read_exceptions'].append({'path':'/Users/g4i/.codex/installation_id','kind':'literal','purpose':'Required non-history CLI installation identity; exact file only'})
 cfg['probes'].append({'category':'sibling_attempt','path':str(R/'sessions/MG-R001/input/task.md')})
 save(R/'configs-final'/config_path.name,cfg);h.prepare(cfg);run=Path(cfg['run_dir']);save(run/'runtime/policy-exceptions.json',extension);(run/'runtime/network-probe.py').write_text(network_code)
p=R/'attempt-ledger.json';d=json.loads(p.read_text());d['tool_mismatch_decisions'].append({'decided_utc':now(),'classification':'startup-network-incompatibility','trigger':'Final zero-event failure under redirected state exposed blocked existing loopback model proxy.','answer_reviewed_at_decision':False,'selection_based_on_answer':False,'evidence':['sessions/MG-R001/output/stderr.txt','sandbox-denials-14674-all.json','final-policy-extension.json'],'next_step':'Fresh final-runs directories with parent-authorized exact loopback7897 and installation_id startup exceptions. All task bytes/model/effort/read denials retained. No automatic answer-based retry.'});save(p,d)
print('prepared final',len(list((R/'final-runs').iterdir())))
