"""Operator-only launcher. Candidate receives only exact frozen task bytes."""
from pathlib import Path
import collections, concurrent.futures, ctypes, datetime, hashlib, importlib.util, json, os, signal, subprocess, sys, threading, time
sys.dont_write_bytecode=True
ROOT=Path('/private/tmp/math-gauge-full-lean-20261029/flow')
PYTHON=str(Path(sys.executable).resolve())
spec=importlib.util.spec_from_file_location('mg_preparation',ROOT/'tools/prepare.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
lock=threading.Lock(); hash_cache={}; halt_new_starts=threading.Event()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,d):
 p=Path(p);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def ledger_add(run,record):
 with lock:
  for p in (ROOT/'attempt-ledger.json',run/'runtime/attempt-ledger.json'):
   d=read(p);d['attempts'].append(dict(record));d['mathematical_requests']=sum(x.get('request_count',0) for x in d['attempts']);save(p,d)
def ledger_update(run,attempt_id,**changes):
 with lock:
  for p in (ROOT/'attempt-ledger.json',run/'runtime/attempt-ledger.json'):
   d=read(p);matches=[x for x in d['attempts'] if x['id']==attempt_id];assert len(matches)==1;matches[0].update(changes);d['mathematical_requests']=sum(x.get('request_count',0) for x in d['attempts']);save(p,d)
def decision(run,evidence,event_type,item_type):
 record={'case':run.name,'decided_utc':now(),'trigger_event_type':event_type,'trigger_item_type':item_type,'answer_reviewed_at_decision':False,'selection_based_on_answer':False,'classification':'unexpected-tool-event','next_step':'terminate this attempt and retain diagnostics; no automatic retry','evidence':evidence}
 with lock:
  for p in (ROOT/'attempt-ledger.json',run/'runtime/attempt-ledger.json'):
   d=read(p);d['tool_mismatch_decisions'].append(record);save(p,d)
 return record
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
lib.proc_pidpath.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32];lib.proc_pidpath.restype=ctypes.c_int
def executable(pid):
 b=ctypes.create_string_buffer(4096);n=lib.proc_pidpath(pid,b,len(b));return b.value.decode(errors='replace') if n>0 else None
def process_snapshot():
 cp=subprocess.run(['/bin/ps','-axo','pid=,ppid=,comm='],capture_output=True,text=True,timeout=10)
 if cp.returncode:raise RuntimeError('Cannot inspect own process ancestry: '+cp.stderr[:300])
 rows={}
 for l in cp.stdout.splitlines():
  parts=l.strip().split(None,2)
  if len(parts)>=3:
   try:pid,ppid=map(int,parts[:2])
   except ValueError:continue
   rows[pid]={'pid':pid,'ppid':ppid,'comm':parts[2]}
 return rows
def descendants(rows,pid):
 result=[]; pending=[pid]
 while pending:
  parent=pending.pop()
  children=[x for x in rows.values() if x['ppid']==parent]
  result+=children;pending += [x['pid'] for x in children]
 return result
def proc_record(row,baseline):
 pid=row['pid'];path=executable(pid);info={**row,'executable':path,'new_since_prelaunch_snapshot':pid not in baseline,'recorded_utc':now()}
 if path and Path(path).is_file():
  with lock:
   if path not in hash_cache:hash_cache[path]=digest(Path(path).read_bytes())
   info['executable_sha256']=hash_cache[path]
 return info
def probe_pid(run,pid,role,out_name):
 argv=[PYTHON,'-B',str(run/'runtime/probe.py'),'--manifest',str(run/'runtime/probes.json'),'--pid',str(pid),'--role',role,'--out',str(run/'runtime'/out_name)]
 cp=subprocess.run(argv,capture_output=True,timeout=15)
 report=read(run/'runtime'/out_name) if (run/'runtime'/out_name).exists() else {'passed':False,'error':cp.stderr.decode(errors='replace')}
 return {'argv':argv,'exit_code':cp.returncode,'report':report}
def terminate_group(proc):
 if proc.poll() is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10)
def stream_events(run,proc,flags,metrics):
 with (run/'output/events.ndjson').open('xb') as out:
  for line in iter(proc.stdout.readline,b''):
   out.write(line);out.flush()
   try:d=json.loads(line)
   except ValueError:metrics['non_json_lines']+=1;continue
   event=d.get('type');metrics['event_types'][event]+=1
   if event=='thread.started':metrics['thread_id']=d.get('thread_id')
   item=d.get('item',{})
   if isinstance(item,dict):
    it=item.get('type')
    if it:metrics['item_types'][it]+=1
    if it and it not in {'agent_message','reasoning','error','todo_list'}:
     if not flags['mismatch']:
      flags['mismatch']=decision(run,'output/events.ndjson',event,it)
   # Record vendor metadata only when an explicit event reports it.
   for key in ('model','reasoning_effort','effort'):
    if isinstance(d.get(key),str):metrics['runtime_metadata'].append({'event_type':event,'field':key,'value':d[key],'utc':now()})
   if event=='turn.completed':metrics['usage']=d.get('usage')
def stream_stderr(run,proc):
 with (run/'output/stderr.txt').open('xb') as out:
  for block in iter(lambda:proc.stderr.read(8192),b''):
   out.write(block);out.flush()
def run_case(cid):
 if halt_new_starts.is_set():return {'case':cid,'status':'not-started-after-startup-failure','request_count':0}
 run=ROOT/'live-runs'/cid;p=read(run/'runtime/plan.json');identity=read(run/'runtime/cli-identity.json')
 execution=read(run/'runtime/execution.template.json');attempt_id=cid+'-math-live-1'
 execution.update(attempt_id=attempt_id,started_utc=now(),worker_pids=[],argv_equals_frozen_plan=True,cwd=p['cwd'],stdin_file=p['stdin_file'],stdin_sha256=p['stdin_sha256'],prompt_bytes=len(Path(p['stdin_file']).read_bytes()),candidate_files=['task.md'],extra_candidate_instruction=None,fresh_ephemeral_session=True,environment_keys=sorted(helper.environment(run)),home_preserved=helper.environment(run).get('HOME')==os.environ.get('HOME'),codex_home_preserved=helper.environment(run).get('CODEX_HOME')==os.environ.get('CODEX_HOME'),model_observation_evidence='../../model-inventory.json',tool_canary_evidence=None,tool_capability_limitation='No additional canary inference was authorized or made. Effective tool-use events are audited; settings explicitly disable context/tools. Do not infer a separate capability experiment.',observed_model=None,observed_effort=None)
 assert read(run/'runtime/open-probe.json')['passed']
 assert read(run/'runtime/network-probe.json')['passed']
 assert digest(Path(identity['selected_binary']).read_bytes())==identity['sha256']
 assert digest(Path(p['stdin_file']).read_bytes())==p['stdin_sha256']==p['prompt_sha256']
 assert {x.name for x in (run/'input').iterdir()}=={'task.md'}
 assert not (run/'runtime/execution.json').exists(),'No rerun in same directory'
 attempt={'id':attempt_id,'case':cid,'kind':'math','started_utc':execution['started_utc'],'request_count':0,'status':'starting','reason':'One preplanned independent task-only Terra 6.1 max submission; no follow-up or answer-based retry.','evidence':[str(run.relative_to(ROOT)/'runtime/execution.json'),str(run.relative_to(ROOT)/'output/events.ndjson'),str(run.relative_to(ROOT)/'output/stderr.txt')]}
 ledger_add(run,attempt);save(run/'runtime/execution.json',execution)
 baseline=process_snapshot();proc=None;start=time.monotonic();flags={'mismatch':None};metrics={'event_types':collections.Counter(),'item_types':collections.Counter(),'non_json_lines':0,'thread_id':None,'runtime_metadata':[]};workers={};ancestry=[];failure=None
 try:
  proc=subprocess.Popen(p['argv'],cwd=p['cwd'],env=helper.environment(run),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  execution['parent_pid']=proc.pid;execution['process_group_id']=os.getpgid(proc.pid)
  out_thread=threading.Thread(target=stream_events,args=(run,proc,flags,metrics),daemon=True);err_thread=threading.Thread(target=stream_stderr,args=(run,proc),daemon=True);out_thread.start();err_thread.start()
  time.sleep(0.15)
  if proc.poll() is not None:raise RuntimeError('CLI exited before stdin submission; exit='+str(proc.returncode))
  rows=process_snapshot();parent=proc_record(rows.get(proc.pid,{'pid':proc.pid,'ppid':os.getpid(),'comm':'unknown'}),baseline)
  if parent['executable']!=identity['resolved_binary']:raise RuntimeError('Actual parent executable does not match inspected CLI')
  if not parent['new_since_prelaunch_snapshot']:raise RuntimeError('Parent is not a new process')
  parent_query=probe_pid(run,proc.pid,'parent','parent-pid-check.json');execution['parent_policy_probe']=parent_query
  if parent_query['exit_code'] or not parent_query['report']['passed']:raise RuntimeError('Parent policy probe failed')
  ancestry.append(parent)
  same_query=probe_pid(run,proc.pid,'worker','worker-pid-check.json')
  if same_query['exit_code'] or not same_query['report']['passed']:raise RuntimeError('In-process worker policy query failed')
  workers[proc.pid]={'identity':parent,'policy_probe':same_query,'first_observed_before_submission':True,'role':'in-process app-server worker shares CLI process','basis':'Identical inspected CLI reported in-process app-server architecture on initial no-event failure; no separate worker exists in the pre-submission process tree. Full descendant polling continues.'}
  for row in descendants(rows,proc.pid):
   info=proc_record(row,baseline);ancestry.append(info)
   if info['executable']==identity['resolved_binary']:
    q=probe_pid(run,row['pid'],'worker','worker-pid-check.json' if not workers else 'worker-pid-check-'+str(len(workers)+1)+'.json');workers[row['pid']]={'identity':info,'policy_probe':q,'first_observed_before_submission':True}
    if q['exit_code'] or not q['report']['passed']:raise RuntimeError('Worker policy probe failed')
  execution.update(parent_identity=parent,worker_pids=sorted(workers),worker_structure='In-process app-server worker shares verified CLI PID; any additional descendant workers are separately recorded.' if workers else 'Worker not yet visible before stdin; parent policy proven and inherited by its new descendants.',pre_submission_policy_verified_utc=now(),inheritance_basis='macOS sandbox-exec applies the profile to its exec image and descendant processes; live parent is the inspected executable with all negative read checks denied. Newly observed workers are checked immediately.')
  execution['network_probe_evidence']='runtime/network-probe.json'
  execution['policy_exception_evidence']='runtime/policy-exceptions.json'
  save(run/'runtime/process-identity.json',{'before_submission':ancestry,'baseline_pid_count':len(baseline),'full_process_arguments_recorded':False})
  # No task bytes have been submitted before this checkpoint.
  execution['request_count']=1;execution['request_utc']=now();save(run/'runtime/execution.json',execution);ledger_update(run,attempt_id,request_count=1,request_utc=execution['request_utc'],status='submitted')
  prompt=Path(p['stdin_file']).read_bytes();written=proc.stdin.write(prompt);proc.stdin.flush();proc.stdin.close();execution['stdin_bytes_written']=written;execution['stdin_write_calls']=1;execution['stdin_closed']=True
  if written!=len(prompt):raise RuntimeError('Incomplete stdin write')
  print(json.dumps({'case':cid,'status':'submitted','parent_pid':proc.pid,'workers_before':sorted(workers),'utc':now()}),flush=True)
  last_scan=0
  while proc.poll() is None:
   if flags['mismatch']:raise RuntimeError('Unexpected tool event detected before answer review')
   if time.monotonic()-start>2700:execution['timeout']=True;raise TimeoutError('2700-second per-case limit')
   if time.monotonic()-last_scan>0.4:
    rows=process_snapshot();last_scan=time.monotonic()
    for row in descendants(rows,proc.pid):
     if row['pid'] in workers:continue
     info=proc_record(row,baseline)
     ancestry.append(info)
     if info['executable']==identity['resolved_binary']:
      q=probe_pid(run,row['pid'],'worker','worker-pid-check.json' if not workers else 'worker-pid-check-'+str(len(workers)+1)+'.json');workers[row['pid']]={'identity':info,'policy_probe':q,'first_observed_before_submission':False}
      if not info['new_since_prelaunch_snapshot'] or q['exit_code'] or not q['report']['passed']:raise RuntimeError('Actual new worker identity/policy check failed')
      execution['worker_pids']=sorted(workers);save(run/'runtime/execution.json',execution)
   time.sleep(0.1)
  out_thread.join(timeout=15);err_thread.join(timeout=15)
  if not workers:
   # Explicitly record when exec performs model work in its own verified process.
   same=probe_pid(run,proc.pid,'worker','worker-pid-check.json') if proc.poll() is None else None
   execution['worker_structure']='No separate model-worker descendant was observed during 0.4-second process-tree polling. Do not claim a separate PID was verified.'
   execution['same_process_worker_evidence']=same
  if flags['mismatch']:raise RuntimeError('Unexpected tool event retained')
  if proc.returncode:raise RuntimeError('CLI nonzero exit '+str(proc.returncode))
  if not (run/'output/response.md').is_file():raise RuntimeError('CLI final-message file missing')
 except BaseException as exc:
  failure={'type':type(exc).__name__,'message':str(exc),'utc':now()}
  if not metrics['event_types'].get('turn.started') or flags['mismatch']:halt_new_starts.set()
  if proc:terminate_group(proc)
  if proc:
   try:out_thread.join(timeout=5);err_thread.join(timeout=5)
   except UnboundLocalError:pass
 finally:
  execution['installation_id_before']=read(ROOT/'installation-id-before.json')
  execution['installation_id_after_sha256']=digest(Path('/Users/g4i/.codex/installation_id').read_bytes())
  execution['installation_id_content_unchanged']=execution['installation_id_after_sha256']==execution['installation_id_before']['sha256']
  if not execution['installation_id_content_unchanged']:halt_new_starts.set()
  execution.update(finished_utc=now(),exit_code=proc.returncode if proc else None,elapsed_seconds=round(time.monotonic()-start,3),failure=failure,worker_pids=sorted(workers),worker_records=list(workers.values()),events_summary={k:dict(v) if isinstance(v,collections.Counter) else v for k,v in metrics.items()},tool_mismatch=flags['mismatch'],answer_mathematically_reviewed=False)
  # Explicit metadata observations are never filled from operator labels.
  for obs in metrics['runtime_metadata']:
   if obs['field']=='model':execution['observed_model']=obs['value']
   if obs['field'] in {'effort','reasoning_effort'}:execution['observed_effort']=obs['value']
  if execution['observed_model'] is None or execution['observed_effort'] is None:execution['model_metadata_limit']='JSON event stream did not explicitly report backend model and/or effort; requested model/effort, current inventory and exact strict-start argv are recorded separately.'
  execution['artifact_hashes']={}
  for name in ('input/task.md','output/events.ndjson','output/stderr.txt','output/response.md'):
   file=run/name
   if file.is_file():execution['artifact_hashes'][name]={'sha256':digest(file.read_bytes()),'bytes':file.stat().st_size}
  save(run/'runtime/execution.json',execution)
  save(run/'runtime/process-identity-final.json',{'parent':execution.get('parent_identity'),'descendant_observations':ancestry,'worker_records':list(workers.values()),'full_process_arguments_recorded':False})
  ledger_update(run,attempt_id,status='completed' if failure is None else 'failed',finished_utc=execution['finished_utc'],exit_code=execution['exit_code'],request_count=execution['request_count'],failure=failure)
  report={'case':cid,'status':'completed' if failure is None else 'failed','request_count':execution['request_count'],'exit_code':execution['exit_code'],'elapsed_seconds':execution['elapsed_seconds'],'worker_pids':execution['worker_pids'],'response':execution['artifact_hashes'].get('output/response.md'),'failure':failure}
  print(json.dumps(report),flush=True)
  return report
if __name__=='__main__':
 ids=sys.argv[1:] or [p.name for p in sorted((ROOT/'live-runs').iterdir())]
 results=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  jobs={pool.submit(run_case,cid):cid for cid in ids}
  for future in concurrent.futures.as_completed(jobs):
   try:results.append(future.result())
   except BaseException as exc:
    results.append({'case':jobs[future],'status':'launcher-failed','type':type(exc).__name__,'message':str(exc)})
   save(ROOT/'run-live-summary.partial.json',{'utc':now(),'results':results})
 save(ROOT/'run-live-summary.json',{'utc':now(),'results':sorted(results,key=lambda x:x['case']),'mathematical_scoring_performed':False})
 raise SystemExit(0 if all(x['status']=='completed' for x in results) else 1)
