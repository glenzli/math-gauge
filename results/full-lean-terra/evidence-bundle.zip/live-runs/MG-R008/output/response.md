令
\[
P_n^\vee=\operatorname{Hom}_{\mathbb Z}(P_n,\mathbb Z),\qquad
M_{\mathbf P}=\varinjlim_n P_n^\vee,
\]
其中过渡映射为 \(\rho_n^\vee\)，并记 \(j_n:P_n^\vee\to M_{\mathbf P}\) 为典范映射。再令
\[
I_n=\bigcap_{m\ge n}\rho_{n,m}(P_m)\subseteq P_n.
\]

**主定理。** 下列条件等价：

1. \(F_{\mathbf P}\) 可由 \(\mathbf{Ab}_{\mathcal U}\) 中的一个群表示。
2. \(F_{\mathbf P}\) 保持题目中所有对象集和箭头集均可数的图表的极限。
3. 对单个可数积的比较映射
   \[
   F_{\mathbf P}(\mathbb Z^{\mathbb N})
   \longrightarrow F_{\mathbf P}(\mathbb Z)^{\mathbb N}
   \]
   是满射。
4. \(M_{\mathbf P}\) 有限生成。
5. 对每个 \(n\)，降链
   \[
   P_n\supseteq\operatorname{im}\rho_{n,n+1}
   \supseteq\operatorname{im}\rho_{n,n+2}\supseteq\cdots
   \]
   最终稳定，且这些稳定像 \(I_n\) 的秩一致有界。

条件 4 也有完全逐层的形式：
\[
\boxed{\quad
\exists n\ \forall m\ \exists r\ge n,m:\quad
\operatorname{im}\rho_{m,r}^{\vee}
\subseteq
\operatorname{im}\rho_{n,r}^{\vee}
\quad}
\tag{1}
\]
其中两个像都取在 \(P_r^\vee\) 中。

因此，题目所问的可表性与保可数极限的判据**完全相同**。一旦成立，\(F_{\mathbf P}\) 实际上保持所有 \(\mathcal U\)-小极限。

存在一个尤其具体的单图表检验。令
\[
L_{\mathbf P}=\varprojlim_n P_n,\qquad \pi_n:L_{\mathbf P}\to P_n
\]
为投影。记录
\[
c_n=[n,\operatorname{id}_{P_n}]\in F_{\mathbf P}(P_n)
\]
组成 \(\varprojlim_n F_{\mathbf P}(P_n)\) 的一个元素 \(c\)。上述条件还等价于：\(c\) 属于
\[
F_{\mathbf P}(L_{\mathbf P})
\longrightarrow \varprojlim_n F_{\mathbf P}(P_n)
\tag{2}
\]
的像。若条件不成立，原塔本身就给出一个比较映射非满的可数图表。

表示对象可以典范地取为 \(L_{\mathbf P}\)。具体地，对每个 \(A\)，自然同构为
\[
\Theta_A:F_{\mathbf P}(A)\longrightarrow
\operatorname{Hom}(L_{\mathbf P},A),\qquad
\Theta_A([n,u])=u\pi_n.
\tag{3}
\]
此时 \(M_{\mathbf P}\) 是有限秩自由阿贝尔群，且有典范同构
\[
L_{\mathbf P}\cong M_{\mathbf P}^{\vee}
=\operatorname{Hom}(M_{\mathbf P},\mathbb Z).
\tag{4}
\]
若其秩为 \(r\)，则全部表示对象恰好是与 \(\mathbb Z^r\) 同构的 \(\mathcal U\)-小阿贝尔群。更精确地，对任何群 \(R\)，表示同构
\(F_{\mathbf P}\cong\operatorname{Hom}(R,-)\) 与群同构
\(R\cong L_{\mathbf P}\) 一一对应。

还可直接写出 (3) 的逆。取 \(M_{\mathbf P}\) 的一组基 \(e_1,\ldots,e_r\)，将其对偶基 \(e_1^*,\ldots,e_r^*\) 视为 \(L_{\mathbf P}\) 的元素。取共同的一层 \(n\) 和 \(\lambda_i\in P_n^\vee\)，使 \(j_n(\lambda_i)=e_i\)。对 \(h:L_{\mathbf P}\to A\)，
\[
\Theta_A^{-1}(h)=
\left[n,\ x\longmapsto
\sum_{i=1}^r\lambda_i(x)\,h(e_i^*)\right].
\tag{5}
\]

下面证明这些断言，并给出任意两个塔之间的全部自然变换。

每个 \(P_n^\vee\) 都是有限秩自由群。直极限 \(M_{\mathbf P}\) 可数且无挠：例如，若整数 \(k\ne0\) 杀死一个记录 \([n,\lambda]\)，则在某个后续层
\(k\lambda\rho_{n,m}=0\)；由于 \(P_m^\vee\) 无挠，已有
\(\lambda\rho_{n,m}=0\)。

有限秩自由群的对偶给出对 \(n\) 和 \(A\) 都自然的同构
\[
P_n^\vee\otimes A\xrightarrow{\sim}\operatorname{Hom}(P_n,A),
\qquad
\lambda\otimes a\longmapsto(x\mapsto\lambda(x)a).
\]
取直极限得到
\[
F_{\mathbf P}(A)\cong M_{\mathbf P}\otimes A.
\tag{6}
\]
此外，有限秩自由群与其双对偶典范同构，故
\[
M_{\mathbf P}^\vee
\cong\varprojlim_n(P_n^\vee)^\vee
\cong\varprojlim_nP_n=L_{\mathbf P}.
\]
这里从右到左的配对具体是
\[
(x_n)_n\longmapsto
\bigl([n,\lambda]\longmapsto\lambda(x_n)\bigr).
\tag{7}
\]

先证明有限生成判据。各 \(j_n(P_n^\vee)\) 递增且并为 \(M_{\mathbf P}\)，所以 \(M_{\mathbf P}\) 有限生成，当且仅当某个 \(j_n\) 满射。这也等价于 (1)：若 \(j_n\) 满射，对固定的 \(m\)，只需为有限秩自由群 \(P_m^\vee\) 的每个基元素选取一个 \(P_n^\vee\) 中的原像，再取足够大的共同层 \(r\)。反过来，(1) 直接说明每个 \(j_m(P_m^\vee)\) 包含在 \(j_n(P_n^\vee)\) 中。

若 \(M_{\mathbf P}\) 有限生成，则它无挠，因而是有限秩自由群。由 (6) 和有限自由对偶，有自然同构
\[
M_{\mathbf P}\otimes A
\xrightarrow{\sim}\operatorname{Hom}(M_{\mathbf P}^\vee,A),
\quad
m\otimes a\longmapsto(f\mapsto f(m)a).
\]
结合 (7)，这正是 (3)，并得到 (5)。表示函子保持所有小极限，所以条件 4 蕴含条件 1、2 和 3。

反过来，假设条件 3 成立。列出可数群 \(M_{\mathbf P}\) 的全部元素 \(m_0,m_1,\ldots\)，允许重复。序列 \((m_i)_i\) 有一个原像 \([n,u]\)，其中
\(u:P_n\to\mathbb Z^{\mathbb N}\)。于是每个
\[
m_i=j_n(\operatorname{pr}_i u)
\]
都属于 \(j_n(P_n^\vee)\)，故 \(j_n\) 满射，\(M_{\mathbf P}\) 有限生成。这证明条件 1 至 4 等价。

现在证明单图表检验及稳定像判据。若 \(c\) 在 (2) 的像中，取其一个原像
\([k,u]\)，其中 \(u:P_k\to L_{\mathbf P}\)。对每个 \(n\)，记录相等意味着存在 \(r_n\ge k,n\)，使
\[
\pi_nu\rho_{k,r_n}=\rho_{n,r_n}.
\tag{8}
\]
将 (8) 与 \(\pi_{r_n}\) 复合，并对所有 \(n\) 比较坐标，得到
\[
u\pi_k=\operatorname{id}_{L_{\mathbf P}}.
\tag{9}
\]
因此，(3) 的逆可写成
\[
\operatorname{Hom}(L_{\mathbf P},A)\longrightarrow F_{\mathbf P}(A),
\qquad h\longmapsto[k,hu].
\]
由 (8) 和 (9) 可直接验证两次复合均为恒等。故 \(c\) 可提升时函子可表；反向则由保可数极限立即成立。

同样从 (8)、(9) 可得稳定像。对充分大的 \(m\)，
\[
\operatorname{im}\rho_{k,m}=\pi_k(L_{\mathbf P}):
\]
一边包含由 (8) 在 \(n=k\) 时得到，另一边由
\(\pi_k=\rho_{k,m}\pi_m\) 得到。再对任意 \(n\) 取充分大的 \(m\)，(8) 给出
\[
\operatorname{im}\rho_{n,m}
=\pi_nu\,\operatorname{im}\rho_{k,m}
=\pi_n(L_{\mathbf P}).
\]
所以像链稳定，且 \(I_n=\pi_n(L_{\mathbf P})\)。由 (9)，\(L_{\mathbf P}\) 是 \(P_k\) 的直和因子，因此所有 \(I_n\) 的秩至多为 \(\operatorname{rank}P_k\)。

反过来，假设条件 5。稳定像之间的限制映射
\[
\rho_n:I_{n+1}\longrightarrow I_n
\]
都是满射：取一层 \(m\) 同时实现第 \(n\) 层和第 \(n+1\) 层的稳定像即可。故 \(\operatorname{rank}I_n\) 不减；由一致有界性，它从某层 \(N\) 起不变。此后上述满射是同秩有限自由群之间的同构。于是
\[
\pi_N:L_{\mathbf P}\xrightarrow{\sim}I_N,
\qquad
\pi_n(L_{\mathbf P})=I_n\quad\text{对所有 }n.
\]

取 \(k\ge N\) 使 \(\rho_{N,k}(P_k)=I_N\)，并定义
\[
u:P_k\xrightarrow{\rho_{N,k}}I_N
\xrightarrow{\pi_N^{-1}}L_{\mathbf P}.
\]
对 \(n<N\)，在每个 \(r\ge k\) 层都有
\(\pi_nu\rho_{k,r}=\rho_{n,r}\)。对 \(n\ge N\)，取足够大的 \(r\)，使 \(\operatorname{im}\rho_{n,r}=I_n\)。这两个映射均取值于 \(I_n\)，且经同构
\(\rho_{N,n}|_{I_n}:I_n\to I_N\) 复合后相等，故它们本身相等。因此 \([k,u]\) 将 \(c\) 提升，完成条件 5 的证明。此时稳定像的最终秩也等于 \(r=\operatorname{rank}M_{\mathbf P}\)。

对于任意两个塔 \(\mathbf P,\mathbf Q\)，记 \(\mathbf Q\) 的过渡映射为 \(\sigma_n\)。**全部自然变换**有以下两种等价描述：
\[
\boxed{\quad
\operatorname{Nat}(F_{\mathbf P},F_{\mathbf Q})
\cong \operatorname{Hom}(M_{\mathbf P},M_{\mathbf Q})
\cong
\varprojlim_n\varinjlim_m
\operatorname{Hom}(Q_m,P_n).
\quad}
\tag{10}
\]
第一式将自然变换送到它在 \(\mathbb Z\) 处的分量。反向，对群同态 \(f:M_{\mathbf P}\to M_{\mathbf Q}\)，相应分量由
\[
m\otimes a\longmapsto f(m)\otimes a
\]
给出。它是全部自然变换：对每个 \(a\in A\)，使用映射
\(\mathbb Z\to A,\ 1\mapsto a\) 的自然性即可确定纯张量的像。

第二式可以逐层写成如下记录。对每个 \(n\) 选取
\[
f_n:Q_{m_n}\longrightarrow P_n,
\]
要求对每个 \(n\)，存在 \(s\ge m_n,m_{n+1}\) 使
\[
f_n\sigma_{m_n,s}
=\rho_n f_{n+1}\sigma_{m_{n+1},s}.
\tag{11}
\]
这样的族决定
\[
[n,u:P_n\to A]\longmapsto
[m_n,\,u f_n:Q_{m_n}\to A].
\tag{12}
\]
族之间按右侧直极限中的记录相等关系识别。(11) 恰好保证 (12) 与换层相容；反过来，将自然变换作用于每个
\([n,\operatorname{id}_{P_n}]\) 就恢复该族。它在 \(\mathbb Z\) 处对应的群同态为
\[
[n,\lambda]\longmapsto[m_n,\lambda f_n].
\]

恒等变换由 \(m_n=n,\ f_n=\operatorname{id}_{P_n}\) 表示。若另一自然变换
\(F_{\mathbf Q}\to F_{\mathbf R}\) 由
\(g_m:R_{\ell_m}\to Q_m\) 表示，则复合在第 \(n\) 层由
\[
R_{\ell_{m_n}}\xrightarrow{g_{m_n}}Q_{m_n}
\xrightarrow{f_n}P_n
\]
表示。在 (10) 的第一种描述下，恒等与复合就是普通群同态的恒等与复合。

因而两个记录函子自然同构，当且仅当它们的群
\(M_{\mathbf P}\) 与 \(M_{\mathbf Q}\) 同构。实际上，这给出了整个分类：每个可数无挠阿贝尔群 \(M\)，取递增的有限生成子群
\(M=\bigcup_n M_n\)，令 \(P_n=M_n^\vee\)，并将过渡映射取为包含 \(M_n\hookrightarrow M_{n+1}\) 的对偶，就得到
\(M_{\mathbf P}\cong M\)。所以这类记录函子及其自然变换构成的范畴，等价于可数无挠阿贝尔群及其群同态构成的范畴。

最后，条件 5 的两部分都不可省略。例如，恒为 \(\mathbb Z\)、过渡映射恒为乘 \(2\) 的塔有
\(M_{\mathbf P}=\mathbb Z[1/2]\)，像链不稳定；而取
\(P_n=\mathbb Z^n\)、过渡映射为删去最后一个坐标时，像链均稳定，但稳定像的秩无界，且
\(M_{\mathbf P}\cong\mathbb Z^{(\mathbb N)}\)。这两个函子均不保可数极限，也均不可表。