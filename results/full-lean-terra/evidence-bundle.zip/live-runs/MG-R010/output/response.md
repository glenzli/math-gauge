记 \(\kappa T\) 为 Hausdorff 空间 \(T\) 的**紧生成化**：它与 \(T\) 有相同底集，且
\[
W\subseteq T\text{ 在 }\kappa T\text{ 中开}
\quad\Longleftrightarrow\quad
W\cap K\text{ 在 }K\text{ 中开，对每个紧子集 }K\subseteq T.
\]
这里 \(K\) 带 \(T\) 的子空间拓扑。称函数 \(f:T\to Q\) **紧连续**，如果它在 \(T\) 的每个紧子集上的限制连续；等价地，\(f:\kappa T\to Q\) 连续。

所求空间的底集为
\[
|M(X,Y)|
=
\left\{f:X\to Y:
f|_K:K\to Y\text{ 连续，对每个紧子集 }K\subseteq X
\right\}.
\]
在这个集合上，先取由
\[
[K,U]=\{f:f(K)\subseteq U\},
\qquad K\subseteq X\text{ 紧},\quad U\subseteq Y\text{ 开},
\]
生成的拓扑，记所得空间为 \(M_0(X,Y)\)。然后定义
\[
\boxed{\quad M(X,Y)=\kappa M_0(X,Y).\quad}
\]
因此，\(M\) 的开集也可直接描述为：\(W\subseteq |M|\) 开，当且仅当对 \(M_0\) 的每个紧子集 \(L\)，交集 \(W\cap L\) 在 \(L\) 中开。

这个空间是 Hausdorff 的。确实，若 \(f\ne g\)，取 \(x\) 使 \(f(x)\ne g(x)\)，再取 \(Y\) 中分离这两个值的不交开集；相应的 \([\{x\},U]\) 分离 \(f,g\)。紧生成化只会加细拓扑，故仍为 Hausdorff。

对每个探针 \(T\)，求值由
\[
\operatorname{ev}_T(a,b)(t)=a(t)(b(t)),
\qquad a:T\to M(X,Y),\quad b:T\to X,
\]
给出。这些函数连续，且构成自然变换
\[
\operatorname{ev}:h_{M(X,Y)}\times h_X\longrightarrow h_Y.
\]
下面证明它具有题目要求的全部性质。

首先，紧生成化有两个基本性质。原空间 \(T\) 和 \(\kappa T\) 有完全相同的紧子集，且在每个这样的子集上诱导相同拓扑：定义直接给出从 \(\kappa T\) 诱导的拓扑不比原子空间拓扑细，而原拓扑包含于 \(\kappa T\) 的拓扑。反方向的紧性则来自连续恒等映射 \(\kappa T\to T\)。因此 \(\kappa T\) 本身是紧生成的。

此外，若 \(A\) 是紧 Hausdorff 空间，则函数 \(A\to T\) 连续，当且仅当同一函数 \(A\to\kappa T\) 连续。非平凡方向中，映像在 \(T\) 中紧，因而它在 \(T\) 和 \(\kappa T\) 中有相同的子空间拓扑。特别地，
\[
h_T\cong h_{\kappa T}.
\tag{1}
\]

接着说明探针检测到什么。每个底集属于 \(\mathcal U\) 的紧 Hausdorff 空间 \(K\)，都是某个 \(\mathcal U\)-小 profinite 空间的连续满射像。具体地，令 \(P\) 为底集 \(K\) 上所有超滤子的集合，赋予由
\[
\widehat A=\{\mathfrak u:A\in\mathfrak u\},
\qquad A\subseteq K,
\]
组成的开闭基。超滤子扩张原理表明 \(P\) 紧、Hausdorff 且全不连通。每个超滤子在紧 Hausdorff 空间 \(K\) 中有唯一极限，故得到满射
\[
\pi:P\longrightarrow K.
\]
它连续：若 \(\pi(\mathfrak u)\in O\) 且 \(O\) 开，由正则性可取开集 \(V\)，使
\(\pi(\mathfrak u)\in V\) 且 \(\overline V\subseteq O\)；于是 \(\widehat V\) 是 \(\mathfrak u\) 的邻域，并映入 \(O\)。连续满射 \(\pi\) 从紧空间到 Hausdorff 空间，故为商映射。宇宙的幂集和子集封闭性保证 \(P\in\mathcal U\)。

由此，对任意 Hausdorff 空间 \(T,Q\)，有自然双射
\[
\operatorname{Nat}(h_T,h_Q)
\cong
\{f:T\to Q:f\text{ 紧连续}\}.
\tag{2}
\]
证明如下。自然变换在单点探针上的分量确定一个函数 \(f:T\to Q\)；再对每个点映射 \(1\to S\) 使用自然性，可知它在 \(S\) 上必定将 \(p:S\to T\) 送到 \(f\circ p\)。若 \(K\subseteq T\) 紧，取上面的 profinite 商映射 \(\pi:P\to K\)，则
\(f|_K\circ\pi\) 连续，故 \(f|_K\) 连续。反过来，若 \(f\) 紧连续，每个探针映射 \(p:S\to T\) 的映像是紧子集，所以 \(f\circ p\) 连续，并给出所需自然变换。

证明泛性质还需要一个映射空间引理。任意函数
\[
a:Z\longrightarrow |M(X,Y)|
\]
定义函数
\[
F_a:Z\times X\longrightarrow Y,\qquad F_a(z,x)=a(z)(x).
\]
则
\[
a:Z\to M(X,Y)\text{ 紧连续}
\quad\Longleftrightarrow\quad
F_a:Z\times X\to Y\text{ 紧连续}.
\tag{3}
\]

为证明这一点，先注意 \(F_a\) 紧连续当且仅当对所有紧子集
\(A\subseteq Z\)、\(B\subseteq X\)，限制
\(F_a|_{A\times B}\) 连续。必要性显然；反之，\(Z\times X\) 的任意紧子集都包含在其两个紧投影的乘积中。

固定紧子集 \(A\subseteq Z\)。若 \(a|_A:A\to M_0(X,Y)\) 连续，则对每个紧 \(B\subseteq X\)，限制映射
\[
M_0(X,Y)\longrightarrow C(B,Y)_{\mathrm{co}},
\qquad f\longmapsto f|_B,
\]
连续。由于 \(B\) 紧 Hausdorff，通常的紧开拓扑求值
\(C(B,Y)_{\mathrm{co}}\times B\to Y\) 连续，故 \(F_a|_{A\times B}\) 连续。

反过来，若所有 \(F_a|_{A\times B}\) 连续，对任意子基开集 \([B,U]\)，管状邻域引理表明
\[
\{z\in A:a(z)(B)\subseteq U\}
\]
在 \(A\) 中开。因此 \(a|_A:A\to M_0(X,Y)\) 连续。最后，紧源 \(A\) 到 \(M_0\) 连续当且仅当到 \(\kappa M_0=M\) 连续，由此得到 (3)。紧 Hausdorff 空间上的紧开求值连续性也可直接看出：若 \(g(b)\in U\)，取 \(b\) 的开邻域 \(V\)，使紧集 \(\overline V\subseteq g^{-1}(U)\)，则 \([\overline V,U]\times V\) 映入 \(U\)。

特别地，在 (3) 中取 \(Z=M(X,Y)\) 和 \(a=I_M\)，可知通常的点值函数
\[
M(X,Y)\times X\longrightarrow Y,\qquad (f,x)\longmapsto f(x)
\]
紧连续。根据 (2)，它正好给出上面定义的求值自然变换。

现在令 \(Z\) 为任意 Hausdorff 参数空间。由 (2)、乘积关系
\(h_Z\times h_X\cong h_{Z\times X}\) 和 (3)，依次得到
\[
\begin{aligned}
\operatorname{Nat}(h_Z,h_M)
&\cong \{a:Z\to M:a\text{ 紧连续}\}\\
&\cong \{F:Z\times X\to Y:F\text{ 紧连续}\}\\
&\cong \operatorname{Nat}(h_Z\times h_X,h_Y).
\end{aligned}
\]
中间双射为 \(a\mapsto F_a\)，逆映射为 \(F\mapsto(z\mapsto F(z,-))\)；后者确实取值于 \(|M|\)，因为 \(F\) 紧连续。这一复合双射正是
\[
\alpha\longmapsto
\operatorname{ev}\circ(\alpha\times I_{h_X}).
\]
若 \(Z=S\) 本身是 profinite 空间，紧连续 \(S\to M\) 就是连续映射，因而得到要求的
\[
C(S,M(X,Y))\cong
\operatorname{Nat}(h_S\times h_X,h_Y).
\]
显式地，\(a:S\to M\) 对应的记录在探针 \(T\) 上为
\[
(p,q)\longmapsto
\bigl[t\longmapsto a(p(t))(q(t))\bigr].
\]
公式同时表明它对 \(S\) 中的预复合自然。

对连续映射 \(u:X'\to X\)、\(v:Y\to Y'\)，相容的映射由
\[
M(u,v):M(X,Y)\longrightarrow M(X',Y'),
\qquad f\longmapsto v\circ f\circ u
\]
给出。它先在紧开拓扑下连续，因为
\[
M(u,v)^{-1}[K',U']
=[u(K'),v^{-1}(U')],
\]
而 \(u(K')\) 紧；紧生成化后仍连续。点值恒等式
\[
\operatorname{ev}(M(u,v)(f),x')
=
v\bigl(\operatorname{ev}(f,u(x'))\bigr)
\]
给出 \(X,Y\) 中的相容性；参数空间中的相容性同样由点值公式给出。

所有构造都留在指定宇宙内：\(|M|\) 是 \(Y^X\) 的子集，故属于 \(\mathcal U\)；它的拓扑是其幂集的子集，也属于 \(\mathcal U\)。自然变换集合则是 \(\mathcal V\)-小的。

最后，题目的泛性质在所有 Hausdorff 拓扑中**不唯一确定拓扑**；它唯一确定其紧生成化。事实上，(2) 还给出
\[
\operatorname{Nat}(h_T,h_Q)\cong C(\kappa T,\kappa Q).
\]
因此任何其他实现空间 \(M'\) 都满足 \(\kappa M'\cong M(X,Y)\)，而上述构造是紧生成 Hausdorff 空间中的规范实现。

例如，取 \(\mathbb N\) 上的非主超滤子 \(\mathfrak p\)，令
\(Y=\mathbb N\sqcup\{\infty\}\)，使自然数点孤立，而 \(\infty\) 的邻域为含某个 \(\{\infty\}\cup A\)、\(A\in\mathfrak p\) 的集合。此 \(Y\) 是非离散 Hausdorff 空间，且其紧子集全为有限集：若紧集含 \(\infty\) 和无穷集合 \(E\subseteq\mathbb N\)，将 \(E\) 分成两个无穷部分，至少一个部分 \(E_0\) 不属于 \(\mathfrak p\)；用 \(\{\infty\}\cup(\mathbb N\setminus E_0)\) 和 \(E_0\) 中各单点构成开覆盖，便没有有限子覆盖。故 \(\kappa Y\) 是离散空间。对 \(X=1\)，空间 \(Y\) 和 \(\kappa Y\) 均实现题目的泛性质，却并不同胚。