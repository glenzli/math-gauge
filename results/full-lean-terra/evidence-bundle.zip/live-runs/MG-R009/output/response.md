设 \(1=h_{\{*\}}\)。下面的商始终指**层商**，即先取逐项轨道商，再层化；它不要求由某个拓扑空间表示。

先记一个用于全文的事实。若层 \(F\) 带有 \(\Gamma\)-作用，令
\[
F/\Gamma:=a\bigl(U\longmapsto F(U)/\Gamma\bigr),
\qquad
\rho_F:F\longrightarrow F/\Gamma,
\]
其中 \(a\) 是层化。则：

- \(F/\Gamma\) 的每个局部截面在一个有限覆盖上来自 \(F\) 的截面。
- 对 \(x,y\in F(U)\)，有 \(\rho_F(x)=\rho_F(y)\)，当且仅当存在有限覆盖 \(\{U_i\to U\}\) 和 \(\gamma_i\in\Gamma\)，使得
  \[
  y|_{U_i}=a_{\gamma_i}(x|_{U_i})\quad\text{对每个 }i.
  \tag{1}
  \]
- \(\rho_F\) 对 \(\Gamma\)-不变态射具有商的泛性质。

这些性质来自层化的局部描述：预层的两个截面在层化中相等，当且仅当它们在某个覆盖上相等；层化的截面局部来自预层。这里覆盖及其复合都可取有限族。站点在 \(\mathcal V\) 中是小的，因此上述层化是 \(\mathbf{Set}_{\mathcal V}\) 值的。表示预层也是层：有限覆盖的源的有限不交并到目标是紧 Hausdorff 空间间的满射，因而是商映射；这也包括空空间的空覆盖。

取
\[
Q:=h_T/\Gamma,\qquad q:=\rho_{h_T}:h_T\longrightarrow Q.
\]
泛性质立即给出题目要求的、关于 \(Y\) 自然的双射
\[
\operatorname{Hom}_{\mathcal C}(Q,Y)
\cong
\{b:h_T\to Y\mid b h_\gamma=b\text{ 对所有 }\gamma\in\Gamma\}.
\]

这个构造也可描述其局部截面：\(Q(U)\) 的元素可由有限覆盖 \(\{U_i\to U\}\) 和映射 \(t_i:U_i\to T\) 表示，其中每个重叠 \(U_i\times_U U_j\) 都可再有限覆盖，使两侧的 \(t_i,t_j\) 在每块上相差一个群元素。两个这样的局部族代表同一元素，当且仅当它们在所有混合重叠上满足同样的局部轨道条件。

令
\[
R:=h_T\times_Q h_T.
\]
它有如下具体描述。对 \(t_0,t_1:U\to T\)，有
\[
(t_0,t_1)\in R(U)
\quad\Longleftrightarrow\quad
U=\bigcup_{i=1}^{n}\{u\in U:t_1(u)=\gamma_i t_0(u)\}
\quad\text{对某些 }\gamma_1,\ldots,\gamma_n\in\Gamma.
\tag{2}
\]
空 \(U\) 时允许 \(n=0\)。右侧各集合是 \(U\) 的闭子空间，故仍在站点中。事实上，由 (1) 得到的有限覆盖的像包含于这些闭集合；反过来，这些闭子空间本身构成有限覆盖。

若 \(\underline\Gamma=\coprod_{\gamma\in\Gamma}1\)，则
\(\underline\Gamma(U)\) 是从 \(U\) 到离散群 \(\Gamma\) 的连续映射集，其像必有限。公式 (2) 表明作用图映射
\[
\underline\Gamma\times h_T\longrightarrow R,\qquad
(\gamma,t)\longmapsto(t,\gamma t)
\tag{3}
\]
是满射层态射：每个 \(R\) 的截面在有限覆盖上落在某个常数 \(\gamma\) 的作用图中。

由此还得到一个后面反复使用的性质。对任意 \(B\to Q\)，设
\[
X_B:=h_T\times_Q B,\qquad r_B:X_B\to B,
\]
并让 \(\Gamma\) 只作用于 \(h_T\) 坐标。则 \(r_B\) 局部满射；两个 \(X_B\) 的截面若在 \(B\) 中相等，就局部相差一个群元素。因此
\[
X_B/\Gamma\ \xrightarrow{\ \sim\ }\ B.
\tag{4}
\]
例如，局部满射来自 \(q\) 的局部满射；同纤维中的两个截面有相同的 \(B\) 坐标，其 \(T\) 坐标则由 (2) 局部相差一个群元素。再用 (1) 可验证 (4) 的单射性和满射性。

对 \(\gamma\in\Gamma\)，记
\[
T^\gamma:=\{t\in T:\gamma t=t\}.
\]
它是 \(T\) 的闭子空间，因而是站点中的对象。给定题目中的等变记录对象 \((E,\pi,a)\)，考虑条件
\[
\boxed{\quad
a_\gamma\text{ 在 }E\times_{h_T}h_{T^\gamma}\text{ 上恒等，
对每个 }\gamma\in\Gamma.
\quad}
\tag{5}
\]
等价地，对每个 \(U\)、每个 \(e\in E(U)\)，只要 \(\gamma\pi(e)=\pi(e)\)，就要求 \(a_\gamma(e)=e\)。

**主定理是：等变记录对象 \(E\) 在 \(Q\) 上可实现，当且仅当它满足 (5)。** 在此情形，规范实现为
\[
D_E:=E/\Gamma\longrightarrow Q,
\tag{6}
\]
其中到 \(Q\) 的映射由 \(\Gamma\)-不变映射 \(q\pi:E\to Q\) 诱导。规范等变映射
\[
\eta_E:E\longrightarrow h_T\times_Q D_E,\qquad
e\longmapsto\bigl(\pi(e),\rho_E(e)\bigr)
\tag{7}
\]
恰好在 (5) 成立时是同构。

事实上，(7) 对任意 \(E\) 都局部满射。给定目标的一个局部截面 \((t,d)\)，先局部取 \(e\) 使 \(\rho_E(e)=d\)。由于
\(q(t)=q(\pi e)\)，再由 (1) 局部取 \(\gamma\) 使
\(t=\gamma\pi(e)\)；这时 \(a_\gamma(e)\) 是所需原像。

若 (5) 成立，并且两个截面 \(e,e'\) 在 (7) 下像相等，则
\(\pi(e)=\pi(e')\)，且由 (1)，局部有 \(e'=a_\gamma(e)\)。于是局部
\(\gamma\pi(e)=\pi(e)\)，由 (5) 得 \(e'=e\)。所以 (7) 是单射层态射，从而是同构。反过来，若 (7) 是单射，而 \(\gamma\pi(e)=\pi(e)\)，则 \(e\) 和 \(a_\gamma(e)\) 在 (7) 下像相等，故二者相等，得到 (5)。

令 \(\mathsf{Eq}_0(T,\Gamma)\) 为满足 (5) 的等变记录对象构成的满子范畴。上述构造给出范畴等价
\[
\mathcal C/Q\ \simeq\ \mathsf{Eq}_0(T,\Gamma),
\qquad
(D\to Q)\longmapsto h_T\times_Q D,
\qquad
E\longmapsto E/\Gamma.
\tag{8}
\]
其中一个方向的规范同构是 (7)，另一个方向的规范同构是 (4)，取 \(B=D\)。

这也描述了全部实现和映射。若已指定一个实现
\(\varphi:E\xrightarrow{\sim}h_T\times_Q D\)，则它在取商后给出唯一同构
\[
\bar\varphi:D_E\xrightarrow{\sim}D
\]
使得 \(\varphi=(\mathrm{id}_{h_T}\times_Q\bar\varphi)\eta_E\)。因此，连同与 \(E\) 的指定等变同构一起计算时，实现存在则唯一到唯一同构。对两个满足 (5) 的对象 \(E,E'\)，等变映射恰好对应于其规范实现之间的 \(Q\)-上映射：
\[
\operatorname{Hom}_{\mathsf{Eq}}(E,E')
\cong
\operatorname{Hom}_{\mathcal C/Q}(E/\Gamma,E'/\Gamma).
\tag{9}
\]
对应关系由取商给出；反向映射通过 (7) 拉回。

这一定理也可直接表述为通常的下降资料分类。记 \(p_0,p_1:R\rightrightarrows h_T\)。一个 \(R\)-下降资料是 \(E\to h_T\) 及 \(R\) 上的同构
\[
\theta:p_0^*E\xrightarrow{\sim}p_1^*E,
\]
它在对角线上为恒等，并在三重纤维积上满足
\(\theta_{12}\theta_{01}=\theta_{02}\)。把 \(\theta\) 沿各作用图
\(t\mapsto(t,\gamma t)\) 拉回，就得到 \(\Gamma\)-作用；对角线条件给出 (5)，余循环条件给出群作用律。

反过来，若给定作用满足 (5)，由 (7) 将 \(E\) 写成
\(h_T\times_Q D_E\)，再令 \(\theta\) 保持 \(D_E\) 坐标、把 \(t_0\) 换成 \(t_1\)。这满足下降公理，并在每个 \(\gamma\) 的作用图上给出 \(a_\gamma\)。由 (3) 的局部满射性，这样的 \(\theta\) 唯一。因此 (8) 同时证明了这些核对下降资料是有效的。

现在对任意 \(B\to Q\) 作相同分类。给 \(X_B=h_T\times_QB\) 上的等变对象
\[
\pi_B:E\to X_B
\]
以覆盖 \(X_B\) 上作用的 \(\Gamma\)-作用。其固定子判据是
\[
a_\gamma\text{ 在 }
E\times_{X_B}X_B^\gamma\text{ 上恒等，对每个 }\gamma,
\qquad
X_B^\gamma\cong h_{T^\gamma}\times_Q B.
\tag{10}
\]
等价地，若 \(e\in E(U)\) 的 \(X_B\) 坐标是 \((t,b)\)，则只要
\(\gamma t=t\)，就要求 \(a_\gamma e=e\)。

利用 (4)，与上面相同的证明给出
\[
\mathcal C/B\ \simeq\
\left\{
\begin{array}{c}
X_B\text{ 上满足 }(10)\text{ 的}\\
\Gamma\text{-等变对象}
\end{array}
\right\},
\qquad
D\longmapsto X_B\times_B D,
\qquad
E\longmapsto E/\Gamma.
\tag{11}
\]
其规范映射为
\[
E\longrightarrow X_B\times_B(E/\Gamma),
\qquad e\longmapsto(\pi_B(e),\rho_E(e)),
\tag{12}
\]
它总是局部满射，且恰在 (10) 成立时为同构。

对于 \(Q\) 上的任意映射 \(f:B'\to B\)，有
\(X_{B'}\cong X_B\times_BB'\)。等变对象的拉回是
\[
E':=E\times_{X_B}X_{B'}\cong E\times_BB',
\]
其中 \(\Gamma\) 作用于 \(E\) 坐标。规范地，
\[
(E')/\Gamma\ \cong\ (E/\Gamma)\times_BB'.
\tag{13}
\]
这可由局部截面直接验证：右侧截面局部提升到 \(E\)，而两个提升给出同一商截面时，局部相差一个群元素。于是 (11) 下的实现拉回与等变对象拉回对应：
\[
\bigl(X_B\times_BD\bigr)\times_{X_B}X_{B'}
\ \cong\
X_{B'}\times_{B'}(D\times_BB').
\tag{14}
\]
这些同构与复合拉回相容。

特别地，对原来的 \(E\to h_T\)，拉回到 \(B\) 后
\[
E_B:=E\times_{h_T}X_B\cong E\times_QB,\qquad
E_B/\Gamma\cong(E/\Gamma)\times_QB,
\]
且 \(\eta_{E_B}\) 正是 \(\eta_E\) 沿 \(B\to Q\) 的拉回。因此可实现性在拉回后保持；若 \(B\to Q\) 是满射层态射，也可在这个拉回上检验可实现性。

最后，两个例子说明判据中的“有限覆盖”和“整个层”都不能省略。

- 令 \(T=\mathbb Z\cup\{\infty\}\) 为离散空间 \(\mathbb Z\) 的单点紧化，令 \(\mathbb Z\) 平移整数并固定 \(\infty\)。取 \(U=T\)，令 \(t(n)=n\)、\(t'(n)=2n\)，且二者都把 \(\infty\) 送到 \(\infty\)。逐点看 \(t(u)\) 与 \(t'(u)\) 总在同一轨道，但所需平移量在整数 \(n\) 处是 \(n\)，不能由有限多个平移量覆盖。因此由 (2)，\(q(t)\ne q(t')\)。
- (5) 不能只在一点空间的截面上检查。取 \(T=1\)、\(\Gamma=\mathbb Z/2\)，令 \(H(U)=C(U,\mathbb R)\)，令 \(L(U)\) 为局部常值实函数，并令 \(E\) 为商层 \(H/L\)；非平凡群元素以取负作用。\(E(1)\) 只有零元，但在 Cantor 空间上的一个连续嵌入 \(f:2^{\mathbb N}\to\mathbb R\) 的类满足 \([f]\ne-[f]\)：否则 \(2f\) 在有限覆盖上局部常值，便会有有限像。故该作用在所有一点截面上看似平凡，却不满足 (5)，也不可实现。