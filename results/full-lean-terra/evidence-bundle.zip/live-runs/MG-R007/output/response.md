这样的相容分裂总是存在。关键是：虽然给定的分裂 \(u_n\) 未必相容，但从足够高的层传到固定层的分裂构成一列递减的有限维仿射空间，因而最终稳定。

记
\[
\mathscr S_n=\{u\in\operatorname{Hom}_G(C,B_n):q_nu=I_C\}.
\]
它非空，并且是有限维仿射空间；其平移空间为
\[
i_n\operatorname{Hom}_G(C,A_n).
\]
确实，两个分裂之差的像落在 \(\ker q_n=\operatorname{im}i_n\)，而 \(i_n\) 在其像上的逆也是 \(G\) 等变的。

对 \(m\ge n\)，令
\[
F_{n,m}:\mathscr S_m\longrightarrow\mathscr S_n,\qquad
F_{n,m}(u)=\beta_n\beta_{n+1}\cdots\beta_{m-1}u,
\]
其中 \(F_{n,n}\) 是恒等映射。这些映射良定义，因为
\(q_n\beta_n\cdots\beta_{m-1}=q_m\)。对固定的 \(n\)，非空仿射子空间
\[
\mathscr S_n^{(m)}:=F_{n,m}(\mathscr S_m),\qquad m\ge n,
\]
随 \(m\) 增大而递减。由于它们位于有限维仿射空间 \(\mathscr S_n\) 中，这列仿射子空间最终稳定。记稳定值为
\[
\mathscr S_n^*=\bigcap_{m\ge n}\mathscr S_n^{(m)}.
\]
特别地，\(\mathscr S_n^*\) 非空。

由复合关系，对每个 \(m\ge n+1\) 有
\[
F_{n,n+1}\bigl(\mathscr S_{n+1}^{(m)}\bigr)
=\mathscr S_n^{(m)}.
\]
取 \(m\) 足够大，使两侧均已稳定，得到满射
\[
F_{n,n+1}:\mathscr S_{n+1}^*\twoheadrightarrow\mathscr S_n^*.
\]
因此可先任取 \(s_1\in\mathscr S_1^*\)，再递归选取
\(s_{n+1}\in\mathscr S_{n+1}^*\)，使
\[
\beta_ns_{n+1}=s_n.
\]
每个 \(s_n\) 都是 \(G\) 等变分裂，所以这就构造了所求的相容族。

令
\[
s_\infty:C\longrightarrow B_\infty,\qquad
s_\infty(c)=(s_n(c))_{n\ge1}.
\]
它是 \(G\) 等变线性映射，且 \(q_\infty s_\infty=I_C\)。现在定义
\[
\Theta_s:A_\infty\oplus C\longrightarrow B_\infty,\qquad
\Theta_s\bigl((a_n),c\bigr)=(i_n(a_n)+s_n(c))_{n\ge1}.
\]
相容性保证右侧属于 \(B_\infty\)。其逆映射为
\[
(b_n)_{n\ge1}\longmapsto
\left(
\left(i_n^{-1}\!\left(b_n-s_n(q_1b_1)\right)\right)_{n\ge1},
\ q_1b_1
\right).
\]
这里 \(q_n(b_n)=q_1(b_1)\)，因此括号中 \(i_n^{-1}\) 所作用的元素属于 \(\operatorname{im}i_n\)；所得的 \(A_n\) 元素也由塔的交换关系构成相容族。于是 \(\Theta_s\) 是 \(G\) 表示同构，并且
\[
\Theta_s(a,0)=i_\infty(a),\qquad
q_\infty\Theta_s(a,c)=c.
\]

所有相容分裂的自由度恰好由
\[
V:=\operatorname{Hom}_G(C,A_\infty)
\cong\varprojlim_n\operatorname{Hom}_G(C,A_n)
\]
给出。上式右侧的过渡映射是与 \(\alpha_n\) 的复合；同构由逐坐标取值给出。具体地，若 \(s=(s_n)\) 是一个相容分裂，而
\(t:C\to A_\infty\) 的坐标为 \(t_n:C\to A_n\)，则
\[
(s+t)_n=s_n+i_nt_n
\]
仍是相容分裂。反过来，任意两个相容分裂之差唯一地具有这种形式。因此，相容分裂集合是向量空间 \(V\) 的一个仿射空间。相应的两个直和同构满足
\[
\Theta_{s+t}(a,c)=\Theta_s(a+t(c),c).
\]

对于塔的交换图同构，设另一座塔的数据加撇号，并设 \(G\) 等变同构
\[
\phi_n:A_n\to A_n',\qquad
\psi_n:B_n\to B_n',\qquad
\gamma:C\to C'
\]
与所有包含、商映射和层间映射交换。则分裂 \(s\) 被送到
\[
s_n^{\mathrm{tr}}=\psi_ns_n\gamma^{-1}.
\]
若原分裂增加 \(t\in\operatorname{Hom}_G(C,A_\infty)\)，其像增加
\[
\phi_\infty t\gamma^{-1}
\in\operatorname{Hom}_G(C',A_\infty'),
\qquad
\phi_\infty((a_n))=(\phi_n(a_n)).
\]
所以塔同构在分裂的仿射空间之间给出仿射同构，其线性部分正是 \(t\mapsto\phi_\infty t\gamma^{-1}\)。

更具体地，若两座塔分别选定相容分裂 \(s,s'\)，则在这些分裂给出的坐标下，每个 \(\psi_n\) 的形式为
\[
\begin{pmatrix}
\phi_n & h_n\\
0 & \gamma
\end{pmatrix},
\qquad
i_n'h_n=\psi_ns_n-s_n'\gamma,
\]
其中 \(h_n:C\to A_n'\) 为 \(G\) 等变映射，并满足
\[
\alpha_n'h_{n+1}=h_n.
\]
反过来，任意相容的 \((h_n)\)，连同相容的 \((\phi_n)\) 和 \(\gamma\)，都以此矩阵给出塔的交换图同构。特别地，固定整座 \(A\) 塔和 \(C\) 的塔自同构，恰好通过这些平移自由且传递地作用在所有相容分裂上。

整个论证没有对域的特征作限制，也不需要对群作用取平均。