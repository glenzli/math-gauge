令
\[
F=\{f\in E:Tf=f,\ Sf=f\},\qquad C=K_TK_S,\qquad
Z=q(F)\subset Q.
\]

**主定理。** 两个过程具有相同的恢复理论：

1. \(R\) 的不动点和关系子空间分别是
   \[
   \ker(I-R)=F,\qquad \overline{(I-R)E}=Y.
   \]
   因而，由 \(R\) 构造的商空间与题中的 \(Q\) 相同。

2. 限制映射 \(q|_F:F\to Z\) 是有界线性双射，且 \(Z\) 是 \(Q\) 的闭子空间。恢复映射为
   \[
   \boxed{\ \mathcal H=(q|_F)^{-1}:Z\longrightarrow F\ }.
   \]
   它把一条可恢复记录送到具有该记录的唯一共同不动点，并满足
   \[
   \|r\|_Q\le \|\mathcal H r\|\le C\|r\|_Q
   \qquad(r\in Z).
   \]

3. 对每个 \(x\in E\)，以下条件等价：
   \[
   \begin{aligned}
   &A_{N,M}x\quad\text{按 }\min(N,M)\to\infty\text{ 范数收敛};\\
   &R^nx\quad\text{按 }n\to\infty\text{ 范数收敛};\\
   &q(x)\in Z;\\
   &x\in F+Y.
   \end{aligned}
   \]
   收敛时，两个极限均为 \(\mathcal H(q(x))\)。

4. 状态上的收敛域
   \[
   D=q^{-1}(Z)=F\oplus Y
   \]
   是 \(E\) 的闭子空间。极限映射
   \[
   P=\mathcal H q|_D:D\longrightarrow F
   \]
   是有界投影，其值域为 \(F\)、核为 \(Y\)，并且
   \[
   PT=TP=PS=SP=P\quad\text{在 }D\text{ 上}.
   \]
   对 \(x,x'\in D\)，有稳定界
   \[
   \|Px-Px'\|
   \le C\|q(x-x')\|_Q
   \le C\|x-x'\|.
   \]
   实际的最佳常数由 \(T,S,q\) 完全确定：
   \[
   \|\mathcal H\|=\|P\|
   =\sup_{\substack{f\in F\\ f\ne0}}
     \frac{\|f\|}{\operatorname{dist}(f,Y)}
   \le C,
   \]
   若 \(F=\{0\}\)，该范数取 \(0\)。

特别地，两个过程对**所有**状态都收敛，当且仅当
\[
Z=Q\quad\Longleftrightarrow\quad E=F\oplus Y.
\]

**证明。** 记
\[
U=\frac{I+T}{2},\qquad V=\frac{I+S}{2},\qquad
p_{n,k}=2^{-n}\binom nk,\qquad b_n=\max_{0\le k\le n}p_{n,k}.
\]
因为 \(T,S\) 交换，\(R=UV\) 且 \(R^n=U^nV^n\)。二项式展开和幂有界性给出
\[
\|U^n\|\le K_T,\qquad \|V^n\|\le K_S,
\qquad
\|R^n\|\le C,\qquad \|A_{N,M}\|\le C.
\]

系数 \(p_{n,k}\) 先递增后递减。令超出 \(0\le k\le n\) 的系数为零，则
\[
(I-T)U^n
=\sum_{k=0}^{n+1}(p_{n,k}-p_{n,k-1})T^k,
\qquad
\sum_{k=0}^{n+1}|p_{n,k}-p_{n,k-1}|=2b_n.
\]
因此
\[
\|(I-T)R^n\|\le 2Cb_n,\qquad
\|(I-S)R^n\|\le 2Cb_n. \tag{1}
\]
这里 \(b_n\to0\)，事实上 \(b_n\le\sqrt{2/(n+1)}\)。例如，对 \(n=2m\)，
\[
b_{2m}
=\prod_{j=1}^{m}\left(1-\frac1{2j}\right)
\le \exp\!\left(-\frac12\sum_{j=1}^{m}\frac1j\right)
\le\frac1{\sqrt{m+1}},
\]
而 \(b_{2m+1}\le b_{2m}\)。

双重平均的边界项同样给出
\[
\|(I-T)A_{N,M}\|\le \frac{2C}{N},\qquad
\|(I-S)A_{N,M}\|\le \frac{2C}{M}. \tag{2}
\]
例如，第一式来自
\[
(I-T)A_{N,M}
=\frac{I-T^N}{N}\,
  \frac1M\sum_{j=0}^{M-1}S^j.
\]

这些算子均与 \(T,S\) 交换。由 (1)、(2)，两个过程在 \((I-T)E+(I-S)E\) 上都逐点趋于零；再利用一致界 \(C\) 和闭包，得到
\[
A_{N,M}y\longrightarrow0,\qquad R^ny\longrightarrow0
\quad(y\in Y). \tag{3}
\]
另一方面，两个过程在 \(F\) 上都是恒等映射。

现在证明 \(R\) 的两个结构恒等式。显然 \(F\subset\ker(I-R)\)。若 \(Rx=x\)，则 \(R^nx=x\)；由 (1) 可得 \((I-T)x=(I-S)x=0\)，故 \(x\in F\)。

又因为
\[
I-R=\frac14\bigl((I-T)(I+S)+2(I-S)\bigr),
\]
所以 \((I-R)E\subset Y\)。反过来，对任意 \(y\in Y\)，由 (3) 和望远镜求和，
\[
(I-R)\sum_{k=0}^{n-1}R^ky=y-R^ny\longrightarrow y.
\]
于是 \(\overline{(I-R)E}=Y\)。

由 \(qT=qS=q\)，所有有限平均和迭代都保持记录：
\[
q(A_{N,M}x)=q(x)=q(R^nx). \tag{4}
\]
如果其中任一过程范数收敛到 \(f\)，由 (1) 或 (2) 可知 \(f\in F\)，由 (4) 可知 \(q(f)=q(x)\)，即 \(x-f\in Y\)。反之，若 \(x=f+y\)，其中 \(f\in F,\ y\in Y\)，则 (3) 表明两个过程都收敛到 \(f\)。这证明了收敛条件及共同极限。

还需证明恢复的唯一性和稳定性。对 \(f\in F,\ y\in Y\)，有 \(A_{N,M}(f+y)\to f\)，因此
\[
\|f\|\le C\|f+y\|.
\]
对 \(y\in Y\) 取下确界，得到
\[
\|q(f)\|_Q\le\|f\|\le C\|q(f)\|_Q. \tag{5}
\]
这说明 \(F\cap Y=\{0\}\)，所以共同不动点代表唯一。若 \(q(f_j)\) 在 \(Q\) 中是 Cauchy 列，(5) 使 \(f_j\) 在闭空间 \(F\) 中也是 Cauchy 列，故 \(Z=q(F)\) 闭，且 \(\mathcal H\) 有上述界。由 \(D=q^{-1}(Z)\) 得 \(D=F\oplus Y\) 且 \(D\) 闭；其余投影性质由定义直接得到。

最后，\(\|P\|\le\|\mathcal H\|\)。反向不等式成立，是因为 \(r\in Z\) 的每个代表 \(x\in E\) 都属于 \(D\)，故
\[
\|\mathcal H r\|=\|Px\|\le\|P\|\|x\|;
\]
对所有代表取下确界即得 \(\|\mathcal H\|\le\|P\|\)。最佳常数公式由 \(r=q(f)\) 得出。

记录也可用守恒线性泛函描述。令
\[
\mathcal I=\{\phi\in E^*:T^*\phi=\phi,\ S^*\phi=\phi\}.
\]
由 Hahn–Banach 定理，\(\mathcal I=Y^\perp\)，并且
\[
\|q(x)\|_Q
=\sup_{\substack{\phi\in\mathcal I\\ \|\phi\|\le1}}|\phi(x)|.
\]
因此，可恢复记录的输出是满足
\[
Tf=Sf=f,\qquad \phi(f)=\phi(x)\quad(\phi\in\mathcal I)
\]
的唯一 \(f\)。此外，
\[
\operatorname{dist}_Q(q(x),Z)=\operatorname{dist}_E(x,D).
\]
所以可恢复记录的极限仍可恢复；但若 \(Z\ne Q\)，一条可恢复记录可以受到任意小的扰动而离开 \(Z\)。

上述稳定界并不保证在整个单位球上一致收敛。例如，在 \(E=\ell^1(\mathbb N)\) 上取 \(T\) 为右移、\(S=I\)。此时
\[
F=\{0\},\qquad Y=\left\{x:\sum_{k=1}^{\infty}x_k=0\right\},
\]
所以只有零记录可恢复。取
\[
h_n=\frac12(e_1-e_{n+2})\in Y.
\]
则 \(\|h_n\|_1=1\)，而 \(P h_n=0\)，同时由于两部分的支集不相交，
\[
\|R^nh_n\|_1=\|A_{n,n}h_n\|_1=1.
\]
因此，一般只能断言定理中的逐点范数收敛，不能断言在 \(D\) 的单位球上一致收敛。