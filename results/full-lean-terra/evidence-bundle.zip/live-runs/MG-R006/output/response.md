所要求的短正合列在现有条件下**不一定成立**：每个有限层段都能兼容提升，仍可能不存在兼容的无限提升。

例如取
\[
A_n=2^n\mathbb Z,\qquad B_n=\mathbb Z,\qquad
C_n=\mathbb Z/2^n\mathbb Z,
\]
其中 \(\iota_n\) 是包含映射，\(\pi_n\) 是模 \(2^n\) 的商映射；转移映射分别取包含映射、恒等映射和自然约化映射。所有题设条件都满足。

令 \(c_n\in C_n\) 是 \(3\) 模 \(2^n\) 的逆元。这些元素构成一个整体记录。若它有兼容提升 \((b_n)\)，由于 \(\beta_n=\mathrm{id}_{\mathbb Z}\)，所有 \(b_n\) 必须等于同一个整数 \(b\)。于是
\[
3b\equiv1\pmod{2^n}\qquad\text{对所有 }n,
\]
这迫使 \(3b-1=0\)，矛盾。因此不存在这样的整体提升。事实上，此例中
\[
\varprojlim B_n=\mathbb Z,\qquad
\varprojlim C_n=\mathbb Z_2,
\]
而前者到后者的自然映射不是满射。

不过，可以用以下自然阻碍完整描述何时存在整体提升及其自由度。定义
\[
D:\prod_{n\ge1}A_n\longrightarrow\prod_{n\ge1}A_n,
\qquad
D((t_n))=(t_n-\alpha_n(t_{n+1}))_{n\ge1},
\]
并记
\[
\varprojlim\nolimits^{1} A_n:=\operatorname{coker}D.
\]
它的核 \(\ker D\) 正是 \(\varprojlim A_n\)。

对于 \(c=(c_n)\in\varprojlim C_n\)，任取逐层提升 \(b_n\in B_n\)。因为 \(c\) 兼容，
\[
\pi_n\bigl(b_n-\beta_n(b_{n+1})\bigr)=0,
\]
所以存在唯一的 \(a_n\in A_n\) 满足
\[
\iota_n(a_n)=b_n-\beta_n(b_{n+1}).
\]
定义阻碍
\[
\delta(c):=[(a_n)]\in\varprojlim\nolimits^{1}A_n.
\]
这个定义与逐层提升的选择无关：若把 \(b_n\) 换成 \(b_n+\iota_n(t_n)\)，则 \((a_n)\) 改变 \(D((t_n))\)。

而且，**\(c\) 有整体提升当且仅当 \(\delta(c)=0\)**。确实，若 \((a_n)=D((t_n))\)，则
\[
b_n^*=b_n-\iota_n(t_n)
\]
仍提升 \(c_n\)，并满足 \(\beta_n(b_{n+1}^*)=b_n^*\)。反过来，兼容提升本身给出的阻碍为零。

如果存在一个整体提升 \(b^*\)，那么所有整体提升恰好是
\[
b^*+\iota_*(x),\qquad x\in\varprojlim A_n.
\]
因此解集要么为空，要么是 \(\varprojlim A_n\) 的一个挠集；这给出了整体解的全部自由度。

这些构造给出自然正合列
\[
0\longrightarrow\varprojlim A_n
\longrightarrow\varprojlim B_n
\longrightarrow\varprojlim C_n
\xrightarrow{\ \delta\ }
\varprojlim\nolimits^{1}A_n
\longrightarrow0.
\]
其中左端及 \(\varprojlim B_n\) 处的正合性逐层由原短正合列得到；\(\varprojlim C_n\) 处的正合性就是上述提升判据。最后的满射性使用 \(\beta_n\) 满射：给定任意 \((a_n)\)，取 \(b_1=0\)，递归选择 \(b_{n+1}\) 使
\[
\beta_n(b_{n+1})=b_n-\iota_n(a_n).
\]
所得 \(c_n=\pi_n(b_n)\) 构成整体记录，且 \(\delta(c)=[(a_n)]\)。

自然性也直接来自构造：层与层之间的同态若与原图表和转移映射交换，就与 \(D\) 交换；把局部提升逐层映过去，会把上述 \((a_n)\) 映到目标系统中对应的阻碍。因此整个正合列对系统的态射自然。

所以，在题设的 \(\beta_n\) 满射条件下，所要求的短正合列成立的充要条件是
\[
\varprojlim\nolimits^{1}A_n=0.
\]
例如，若进一步假设每个 \(\alpha_n\) 都满射，就可递归求解 \(D((t_n))=(a_n)\)，从而满足这一条件。