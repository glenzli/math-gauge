所求函数是把每个有限观测记录下半连续化后，再拉回 \(E\) 取逐点上确界。

对非负扩展实值函数 \(h\)，记其下半连续化为

\[
(\operatorname{cl}h)(u)
=\sup_{U\ni u}\inf_{v\in U}h(v),
\]

其中 \(U\) 遍历定义空间中 \(u\) 的开邻域。对线性映射 \(\pi\)，记其沿纤维的下确界为

\[
(\pi_\#h)(y)=\inf_{\pi(z)=y}h(z).
\]

令 \(\bar g_F=\operatorname{cl}g_F\)。那么

\[
\boxed{\displaystyle
G(x)=\sup_{F\subset E',\ \dim F<\infty}\bar g_F(q_F(x)).
}
\tag{1}
\]

这个 \(G\) 是非负、下半连续、凸的，满足 \(G\le f\)，并且任何满足 \(h\le f\) 的下半连续凸函数都满足 \(h\le G\)。

记录随观测空间扩大的关系是：若 \(F\subset K\)，则

\[
\boxed{\displaystyle
g_F=(r_{KF})_\#g_K,
\qquad
\bar g_F(r_{KF}z)\le \bar g_K(z),
\qquad
\bar g_F=\operatorname{cl}\bigl((r_{KF})_\#\bar g_K\bigr).
}
\tag{2}
\]

因此式 (1) 中的值随 \(F\) 扩大而单调增加；有限维子空间按包含关系构成有向集，所以上确界也是相应有向网的极限。

整族记录还给出通常的共轭表示。对 \(\varphi\in E'\)，选任一包含 \(\varphi\) 的有限维 \(F\)，令

\[
a(\varphi)
=\sup_{y\in F^*}\bigl(y(\varphi)-g_F(y)\bigr).
\]

这个值与 \(F\) 的选择无关，且等于 \(f^*(\varphi)\)。于是

\[
\boxed{\displaystyle
\bar g_F(y)=\sup_{\varphi\in F}\bigl(y(\varphi)-a(\varphi)\bigr),
\qquad
G(x)=\sup_{\varphi\in E'}\bigl(\varphi(x)-a(\varphi)\bigr)=f^{**}(x).
}
\tag{3}
\]

特别地，为计算 \(G\)，所有一维观测子空间的记录已经足够。

上图集也有直接的投影描述：

\[
\boxed{\displaystyle
\operatorname{epi}G
=\overline{\operatorname{epi}f}^{\,E\times\mathbb R}
=\bigcap_F(q_F\times\mathrm{id})^{-1}
 \left(\overline{\operatorname{epi}g_F}^{\,F^*\times\mathbb R}\right).
}
\tag{4}
\]

此外，恢复后的 \(G\) 与各记录满足

\[
\boxed{\displaystyle
\bar g_F\le (q_F)_\#G\le g_F,
\qquad
\operatorname{cl}\bigl((q_F)_\#G\bigr)=\bar g_F.
}
\tag{5}
\]

下面证明这些结论。

首先，\(q_F\) 连续且满射。连续性由 \(F\) 的有限基直接得到。若取基 \(\varphi_1,\ldots,\varphi_n\)，而映射
\(x\mapsto(\varphi_1(x),\ldots,\varphi_n(x))\) 的像是 \(\mathbb R^n\) 的真子空间，则存在不全为零的系数 \(a_i\)，使
\(\sum_i a_i\varphi_i=0\)，与基的线性无关性矛盾。又由于 \(f\) 在某点有限，\(g_F\) 在某点有限；通过对纤维中的近似极小点应用 \(f\) 的凸性，可知 \(g_F\) 也是非负凸函数。

当 \(F\subset K\) 时，\(q_F=r_{KF}q_K\)，并且

\[
q_F^{-1}(y)=\bigcup_{r_{KF}z=y}q_K^{-1}(z).
\]

对这个并集取 \(f\) 的下确界，便得到式 (2) 的第一个等式；其中不需要下确界被达到。

接下来用一个一般事实。设 \(X\) 是实 Hausdorff 局部凸空间，\(p:X\to[0,+\infty]\) 凸且在某点有限。上述邻域公式给出的 \(\operatorname{cl}p\) 满足

\[
\operatorname{epi}(\operatorname{cl}p)
=\overline{\operatorname{epi}p}.
\tag{6}
\]

事实上，若 \((x,t)\) 属于右边，则对任意 \(x\) 的邻域 \(U\) 和 \(\varepsilon>0\)，存在 \(z\in U\) 使 \(p(z)<t+\varepsilon\)，故 \((\operatorname{cl}p)(x)\le t\)。反过来，若 \((\operatorname{cl}p)(x)\le t\)，则对每个 \(U,\varepsilon\) 都能取 \(z\in U\) 使 \(p(z)<t+\varepsilon\)，从而 \((x,t)\) 属于上图集的闭包。

由式 (6)，\(\operatorname{cl}p\) 是下半连续凸函数且不超过 \(p\)。若 \(h\) 是任意下半连续函数并满足 \(h\le p\)，则
\(\operatorname{epi}p\subset\operatorname{epi}h\)；右边闭，故
\(\operatorname{epi}(\operatorname{cl}p)\subset\operatorname{epi}h\)，即 \(h\le\operatorname{cl}p\)。所以 \(\operatorname{cl}p\) 是 \(p\) 的最大下半连续 minorant。

这个函数也等于 \(p^{**}\)。为完整起见，证明如下。令

\[
p^*(\lambda)=\sup_{z\in X}\bigl(\lambda(z)-p(z)\bigr),
\qquad
p^{**}(x)=\sup_{\lambda\in X'}\bigl(\lambda(x)-p^*(\lambda)\bigr).
\]

因为 \(p\ge0\) 且在某点有限，\(p^*(0)=-\inf p\) 是有限数。\(p^{**}\) 是连续仿射函数族的上确界，所以下半连续、凸，且 \(p^{**}\le p\)。因此
\(\overline{\operatorname{epi}p}\subset\operatorname{epi}p^{**}\)。

反向包含使用局部凸空间中的分离定理。若
\((x,t)\notin C:=\overline{\operatorname{epi}p}\)，则存在 \(\lambda\in X'\) 和 \(a\in\mathbb R\)，使

\[
\lambda(x)+at>
\sup_{(z,s)\in C}\bigl(\lambda(z)+as\bigr).
\]

由于上图集向上无界，必有 \(a\le0\)。

若 \(a=-c<0\)，右边等于 \(c\,p^*(\lambda/c)\)，于是

\[
t<(\lambda/c)(x)-p^*(\lambda/c)\le p^{**}(x).
\]

若 \(a=0\)，令 \(M=\sup_{p(z)<\infty}\lambda(z)\)，则
\(M<\lambda(x)\)。由 \(p\ge0\)，对每个正整数 \(n\) 有
\(p^*(n\lambda)\le nM\)，因此

\[
p^{**}(x)\ge n\bigl(\lambda(x)-M\bigr)\longrightarrow+\infty.
\]

两种情形都表明 \((x,t)\notin\operatorname{epi}p^{**}\)，故

\[
\operatorname{cl}p=p^{**}.
\tag{7}
\]

现在回到记录。由 \(g_F(r_{KF}z)\le g_K(z)\)，有
\(\bar g_F(r_{KF}z)\le g_K(z)\)。左边作为 \(z\) 的函数是下半连续凸函数，因此由刚证明的最大性，

\[
\bar g_F(r_{KF}z)\le\bar g_K(z).
\]

设 \(p=(r_{KF})_\#\bar g_K\)。取纤维下确界并使用
\(\bar g_K\le g_K\)，得到

\[
\bar g_F\le p\le g_F.
\]

对中间函数取下半连续化，两边由最大性夹住它，便得
\(\operatorname{cl}p=\bar g_F\)。这证明了式 (2)。等价地，

\[
\operatorname{epi}\bar g_F
=
\overline{(r_{KF}\times\mathrm{id})(\operatorname{epi}\bar g_K)}.
\tag{8}
\]

这里的闭包一般不能省略：沿纤维取下确界时，极小值未必达到，投影也未必保持闭性。

对 \(\varphi\in F\)，利用记录的定义，

\[
\begin{aligned}
\sup_{y\in F^*}\bigl(y(\varphi)-g_F(y)\bigr)
&=\sup_{x\in E}\bigl(\varphi(x)-f(x)\bigr)\\
&=f^*(\varphi).
\end{aligned}
\]

将 \(F\) 视为有限维空间 \(F^*\) 的连续对偶，对 \(g_F\) 应用式 (7)，便得到式 (3) 中 \(\bar g_F\) 的公式。每个 \(\varphi\in E'\) 都属于某个有限维 \(F\)，故式 (1) 等于 \(f^{**}\)。再对 \(f\) 应用式 (7)，得到

\[
G=f^{**}=\operatorname{cl}f.
\]

这同时证明 \(G\) 的下半连续性、凸性、\(G\le f\) 及其最大性。式 (4) 的第一个等式由式 (6) 得到；第二个等式则由式 (1) 和
\(\operatorname{epi}\bar g_F=\overline{\operatorname{epi}g_F}\) 得到。

最后，由
\(\bar g_F(q_Fx)\le G(x)\le f(x)\)，沿 \(q_F\) 的纤维取下确界，得式 (5) 的两个不等式；再取下半连续化，便得其中的等式。

邻域公式还说明了有限观测恢复的含义：

\[
G(x)
=\sup_{\substack{F,\ U\subset F^*\text{ 开}\\q_F(x)\in U}}
\inf_{\{z:\,q_F(z)\in U\}}f(z)
=\liminf_{z\to x\text{ 于 }\sigma(E,E')} f(z).
\]

因为这些 \(q_F^{-1}(U)\) 构成弱拓扑 \(\sigma(E,E')\) 的邻域基，整族记录确定的正是这个弱下极限；对这里的凸 \(f\)，它也等于原局部凸拓扑下的下半连续包。

从投影系统看，相容族 \((y_F)_F\) 自然对应 \(E'\) 的代数对偶中的线性函数：令 \(\ell(\varphi)=y_F(\varphi)\)，其中 \(F\ni\varphi\)。一般的相容族未必由某个 \(x\in E\) 实现；式 (1) 只需在实际观测族 \((q_F(x))_F\) 上求值。

以下两个例子说明闭包不可省略：

- 在 \(E=\mathbb R\) 上令 \(f(t)=0\)（\(t>0\)）、\(f(0)=1\)、\(f(t)=+\infty\)（\(t<0\)）。完整的一维记录在 \(0\) 处给出 \(1\)，但 \(G(0)=0\)。因此直接取 \(\sup_F g_F(q_Fx)\) 一般不能得到 \(G\)。
- 在 \(E=\mathbb R^2\) 上，令 \(f\) 为闭凸集 \(\{(u,v):u\ge e^v\}\) 的指标函数，即在该集合上取 \(0\)、其余处取 \(+\infty\)。取 \(F\) 只观测 \(u\)，\(K=E'\)。此时 \(\bar g_F(0)=0\)，但
  \[
  \inf_v\bar g_K(0,v)=+\infty.
  \]
  所以式 (2) 和式 (5) 中的下半连续化一般都是必要的。