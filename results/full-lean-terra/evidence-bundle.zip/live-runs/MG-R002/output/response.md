题设条件不足以保证所要求的恢复映射存在。兼容且一致有界的记录族自然对应于 **\(E''\)** 中的元素；它能由 \(E\) 中的点实现，当且仅当对应的 \(E''\) 元素属于 \(E\) 在 \(E''\) 中的典范像。

因此，对所有这样的记录族都能恢复 \(E\) 中的点，当且仅当 \(E\) 自反。对可实现的记录，恢复映射是等距的，并且与题设的算子变换相容。

先把一个记录族拼成整体泛函。定义

\[
\Lambda_\lambda(\varphi)
=\lambda_{\mathbb R\varphi}(\varphi),
\qquad \varphi\in E'.
\]

兼容性说明，只要有限维空间 \(F\) 包含 \(\varphi\)，就有
\(\Lambda_\lambda(\varphi)=\lambda_F(\varphi)\)。对任意 \(\varphi,\psi\in E'\)，在
\(\operatorname{span}\{\varphi,\psi\}\) 上使用线性性，便知
\(\Lambda_\lambda\) 是线性泛函；题设界给出

\[
|\Lambda_\lambda(\varphi)|\le C\|\varphi\|.
\]

所以 \(\Lambda_\lambda\in E''\)，且 \(\|\Lambda_\lambda\|\le C\)。

反过来，任意 \(\Lambda\in E''\) 都通过
\(\lambda_F=\Lambda|_F\) 给出一个兼容有界记录族。这两个构造互逆，并且

\[
d(\lambda,\mu)
=\|\Lambda_\lambda-\Lambda_\mu\|_{E''}.
\]

题设的算子变换对应于二次对偶算子：若
\(T''\Lambda=\Lambda\circ T'\)，则

\[
\Lambda_{\lambda^T}=T''\Lambda_\lambda.
\]

特别地，\(\lambda^T\) 的有界常数可以取 \(C\|T\|\)，并且对任意两个记录族，

\[
d(\lambda^T,\mu^T)\le \|T\|\,d(\lambda,\mu).
\]

令 \(J:E\to E''\) 为典范映射：

\[
Jx(\varphi)=\varphi(x).
\]

由 Hahn–Banach 定理，\(J\) 是线性等距嵌入。因此，一个记录族能由 \(x\in E\) 实现，当且仅当

\[
\Lambda_\lambda\in J(E).
\]

此时实现点唯一。事实上，若两个点给出相同记录，则所有连续线性泛函都在这两点上取相同值；\(E'\) 分离 \(E\) 中的点，所以它们相等。

这个条件也有一个内在表述：**\(\lambda\) 可实现，当且仅当 \(\Lambda_\lambda:E'\to\mathbb R\) 对弱-* 拓扑 \(\sigma(E',E)\) 连续。** 一方面，若 \(\Lambda_\lambda=Jx\)，它就是求值映射 \(\varphi\mapsto\varphi(x)\)，按弱-* 拓扑的定义连续。

另一方面，若 \(\Lambda_\lambda\) 弱-* 连续，则存在 \(x_1,\ldots,x_n\in E\) 和 \(\delta>0\)，使得

\[
\max_{1\le i\le n}|\varphi(x_i)|<\delta
\quad\Longrightarrow\quad
|\Lambda_\lambda(\varphi)|<1.
\]

若 \(\varphi(x_i)=0\) 对所有 \(i\) 成立，对 \(t\varphi\) 任意缩放可得 \(\Lambda_\lambda(\varphi)=0\)。于是 \(\Lambda_\lambda\) 经由映射

\[
\varphi\longmapsto
\bigl(\varphi(x_1),\ldots,\varphi(x_n)\bigr)
\]

分解。把所得线性泛函从其像延拓到 \(\mathbb R^n\)，可取 \(a_1,\ldots,a_n\in\mathbb R\)，使

\[
\Lambda_\lambda(\varphi)
=\sum_{i=1}^n a_i\varphi(x_i)
=\varphi\!\left(\sum_{i=1}^n a_i x_i\right).
\]

所以它确实由 \(E\) 中的点实现。

对于所有可实现的记录，所求恢复映射就是

\[
R(\lambda)=J^{-1}\Lambda_\lambda.
\]

它满足全部要求。首先，

\[
\varphi(R(\lambda))=\lambda_F(\varphi)
\quad(\varphi\in F),\qquad
\|R(\lambda)\|=\|\Lambda_\lambda\|\le C.
\]

其次，对可实现的 \(\lambda,\mu\)，等距性给出精确的稳定关系

\[
\|R(\lambda)-R(\mu)\|=d(\lambda,\mu).
\]

最后，由 \(T''J=JT\) 得

\[
R(\lambda^T)=T\,R(\lambda),
\qquad
d(\lambda^T,\mu^T)
=\|T(R(\lambda)-R(\mu))\|
\le\|T\|\,d(\lambda,\mu).
\]

如果 \(E\) 自反，则 \(J(E)=E''\)，上述 \(R\) 对每个题设记录族都有定义。反之，如果对某个固定的 \(C>0\)，每个界为 \(C\) 的记录族都可实现，那么把任意非零 \(\Lambda\in E''\) 缩放到范数 \(C\) 以内即可推出 \(\Lambda\in J(E)\)，故 \(E\) 必须自反。若 \(C=0\)，则只有零记录，它在任何 \(E\) 中都由 \(0\) 实现。

一个具体反例是 \(E=c_0\)。此时 \(E'=\ell^1\)：写

\[
\varphi_a(x)=\sum_{n=1}^{\infty}a_nx_n
\quad(a\in\ell^1),
\]

定义

\[
\Lambda(\varphi_a)=\sum_{n=1}^{\infty}a_n,
\qquad
\lambda_F=\Lambda|_F.
\]

这给出兼容记录族，且 \(\|\Lambda\|=1\)。如果存在 \(x\in c_0\) 实现它，对每个坐标泛函 \(x\mapsto x_n\) 取值便得到 \(x_n=1\) 对所有 \(n\) 成立；但常数序列 \((1,1,\ldots)\) 不属于 \(c_0\)。所以在一般 Banach 空间中，不存在满足题目要求的全域恢复映射。