"""Non-inference OS access probes for each already prepared case."""
from pathlib import Path
import datetime, json, subprocess, sys
ROOT = Path(__file__).resolve().parent
def save(path, obj):
    path.write_text(json.dumps(obj, indent=2) + '\n')
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
summaries = []
for run in sorted((ROOT / 'runs').iterdir()):
    plan = json.loads((run / 'runtime/plan.json').read_text())
    prefix = [plan['argv'][0], '-f', str(run / 'runtime/outer.sb'), str(Path(sys.executable).resolve()), '-B']
    commands = {
        'open': prefix + [str(run / 'runtime/probe.py'), '--manifest', str(run / 'runtime/probes.json'), '--out', str(run / 'runtime/open-probe.json')],
        'network': prefix + [str(run / 'runtime/network-probe.py'), str(run / 'runtime/network-probe.json')],
    }
    item = {'case': run.name, 'utc': now(), 'request_count': 0, 'checks': []}
    for name, argv in commands.items():
        proc = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True, timeout=30)
        (run / 'runtime' / (name + '-probe.stdout.txt')).write_bytes(proc.stdout)
        (run / 'runtime' / (name + '-probe.stderr.txt')).write_bytes(proc.stderr)
        item['checks'].append({'kind': name, 'argv': argv, 'exit_code': proc.returncode})
    item['passed'] = all(x['exit_code'] == 0 for x in item['checks'])
    summaries.append(item)
    print(run.name, 'passed' if item['passed'] else 'FAILED', flush=True)
save(ROOT / 'open-probe-summary.json', {'utc': now(), 'cases': summaries, 'passed': all(x['passed'] for x in summaries)})
ledger = json.loads((ROOT / 'attempt-ledger.json').read_text())
ledger['attempts'] += [
    {'id': 'restricted-parent-probe', 'kind': 'startup', 'started_utc': now(), 'request_count': 0, 'status': 'failed', 'reason': 'Outer tool environment disallowed nested sandbox_apply; no CLI process or model request was started.', 'evidence': ['preflight-local-error.json']},
    {'id': 'six-real-open-and-network-probes', 'kind': 'startup', 'started_utc': now(), 'request_count': 0, 'status': 'completed' if all(x['passed'] for x in summaries) else 'failed', 'reason': 'Real policy-bound opens and network connects; no inference.', 'evidence': ['open-probe-summary.json']},
]
save(ROOT / 'preflight-local-error.json', {'exit_code': 71, 'stderr': 'sandbox-exec: sandbox_apply: Operation not permitted', 'runtime_file_created': False, 'model_requests': 0})
save(ROOT / 'attempt-ledger.json', ledger)
raise SystemExit(0 if all(x['passed'] for x in summaries) else 1)
