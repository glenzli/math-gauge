"""Audit completed external CLI evidence and archive an explicit non-state whitelist."""
from pathlib import Path
import collections, datetime, hashlib, importlib.util, json, re, sys, zipfile
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
HELPER = Path('/Users/g4i/lab/math-gauge/scripts/isolated_cli/prepare.py')
spec = importlib.util.spec_from_file_location('mg_prepare', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

queue = read(ROOT / 'run-summary.json')
issues, rows = [], []
freeze_checks = []
for entry in read(ROOT / 'pre-run-freeze.json')['files']:
    frozen_path = ROOT / 'evaluator-freeze' / entry['path']
    good = (frozen_path.is_file() and not frozen_path.is_symlink()
            and frozen_path.stat().st_size == entry['bytes']
            and sha(frozen_path) == entry['sha256'])
    freeze_checks.append({'path': entry['path'], 'matches_frozen_size_and_sha256': good})
    if not good: issues.append('Frozen evaluator artifact changed: ' + entry['path'])
save(ROOT / 'frozen-evaluator-check.json', {'utc': now(), 'checks': freeze_checks, 'passed': not issues})
for run in sorted((ROOT / 'runs').iterdir()):
    e = read(run / 'runtime/execution.json')
    a = helper.audit(run)
    save(run / 'runtime/local-audit.json', a)
    events, items = collections.Counter(), collections.Counter()
    for line in (run / 'output/events.ndjson').read_text().splitlines():
        d = json.loads(line)
        events[d.get('type')] += 1
        if isinstance(d.get('item'), dict): items[d['item'].get('type')] += 1
    tool_events = {k: v for k, v in items.items() if k not in ('agent_message', 'reasoning', 'error', 'todo_list')}
    checks = {
        'completed_once': e['exit_code'] == 0 and e['request_count'] == 1 and events['turn.completed'] == 1,
        'single_write': e.get('stdin_write_calls') == 1 and e.get('stdin_bytes_written') == e['prompt_bytes'],
        'exact_plan': e['argv'] == read(run / 'runtime/plan.json')['argv'],
        'artifacts': a['artifact_checks_passed'], 'all_pid_reports': a['runtime_reports_complete'],
        'file_opens': read(run / 'runtime/open-probe.json')['passed'],
        'network': read(run / 'runtime/network-probe.json')['passed'],
        'no_tool_events': not tool_events,
        'installation_identity': e.get('installation_id_content_unchanged') is True,
        'response_hash': sha(run / 'output/response.md') == e['artifact_hashes']['output/response.md']['sha256'],
        'task_hash': sha(run / 'input/task.md') == read(ROOT / 'pre-run-freeze.json')['cases'][run.name]['task.md'],
        'fresh_worker_identity': all(w['identity']['new_since_prelaunch_snapshot'] and w['policy_probe']['report']['passed'] for w in e['worker_records']),
    }
    issues += [run.name + ': ' + k for k, v in checks.items() if not v]
    rows.append({
        'case': run.name, 'checks': checks, 'elapsed_seconds': e['elapsed_seconds'],
        'requested_model': e['requested_model'], 'requested_effort': e['requested_effort'],
        'observed_model': e['observed_model'], 'observed_effort': e['observed_effort'],
        'parent_pid': e['parent_pid'], 'worker_pids': e['worker_pids'],
        'worker_structure': e['worker_structure'], 'event_types': dict(events),
        'item_types': dict(items), 'tool_events': tool_events,
        'response': e['artifact_hashes']['output/response.md'], 'mathematical_review': None,
    })
ledger = read(ROOT / 'attempt-ledger.json')
report = {
    'utc': now(), 'engineering_checks_passed': not issues, 'issues': issues,
    'suite_sha256': read(ROOT / 'pre-run-freeze.json')['suite_sha256'], 'cases': rows,
    'frozen_evaluator_files_verified': len(freeze_checks),
    'frozen_evaluator_check': 'frozen-evaluator-check.json',
    'all_stdin_submissions': sum(x.get('request_count', 0) for x in ledger['attempts']),
    'failed_attempts_preserved': [x['id'] for x in ledger['attempts'] if x['status'] == 'failed'],
    'human_approval': False, 'mathematical_scoring_performed': False,
    'identity_limit': 'Requested model and max effort accepted by strict CLI startup; backend model/effort only recorded if explicitly echoed by raw events.',
    'capability_limit': 'No separate capability-canary inference; explicit disabled tools, OS policy probes and raw tool-event audit are separate evidence.',
    'state_or_credentials_archived': False,
}
save(ROOT / 'final-engineering-report.json', report)
root_names = [
    'prepare_six.py', 'open_six.py', 'run_six.py', 'audit_six.py', 'network-probe.py',
    'model-inventory.json', 'installation-id-before.json', 'attempt-ledger.json',
    'policy-exceptions.json', 'historical-policy.json', 'preflight-local-error.json',
    'open-probe-summary.json', 'formal-evidence-reuse.json', 'candidate-projection.json',
    'qualification-gate.json', 'pre-run-freeze.json', 'run-summary.json',
    'run-summary.partial.json', 'final-engineering-report.json', 'tool-source-identity.json',
    'frozen-evaluator-check.json', 'audit_six-before-freeze-check.py',
    'tool-source-identity-before-audit-fix.json', 'audit-fix.json',
]
names = set(root_names)
names.update('cli-inspection/' + n for n in ('identity.json', '0-stdout.txt', '0-stderr.txt', '1-stdout.txt', '1-stderr.txt', '2-stdout.txt', '2-stderr.txt'))
names.update('evaluator-freeze/' + x['path'] for x in read(ROOT / 'pre-run-freeze.json')['files'])
runtime_names = [
    'probe.py', 'cli-identity.json', 'outer.sb', 'codex-settings.json', 'probes.json', 'plan.json',
    'attempt-ledger.json', 'execution.template.json', 'prepared-hashes.json', 'execution.json',
    'open-probe.json', 'open-probe.stdout.txt', 'open-probe.stderr.txt', 'parent-pid-check.json',
    'worker-pid-check.json', 'process-identity.json', 'process-identity-final.json',
    'policy-exceptions.json', 'network-probe.py', 'network-probe.json', 'network-probe.stdout.txt',
    'network-probe.stderr.txt', 'local-audit.json',
]
for row in rows:
    cid = row['case']
    names.add('configs/' + cid + '.json')
    prefix = 'runs/' + cid + '/'
    names.update(prefix + n for n in ('input/task.md', 'output/events.ndjson', 'output/stderr.txt', 'output/response.md'))
    names.update(prefix + 'runtime/' + n for n in runtime_names)
    names.update(prefix + 'runtime/base-preparation/' + n for n in ('prepared-hashes.json', 'outer.sb', 'codex-settings.json', 'plan.json', 'execution.template.json'))
    for path in (ROOT / prefix / 'runtime').glob('worker-pid-check-*.json'):
        names.add(path.relative_to(ROOT).as_posix())
patterns = {
    'token-key': re.compile(rb'\bsk-[A-Za-z0-9_-]{20,}'),
    'bearer': re.compile(rb'(?i)\bBearer\s+[A-Za-z0-9._-]{16,}'),
    'credential-json': re.compile(rb'"(?:access_token|refresh_token|id_token)"\s*:\s*"[^"\s]{12,}"'),
    'private-key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
}
files, hits = [], []
for name in sorted(names):
    p = ROOT / name
    assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT), name
    assert 'state' not in p.relative_to(ROOT).parts and p.name not in ('auth.json', 'installation_id'), name
    data = p.read_bytes()
    matches = [k for k, v in patterns.items() if v.search(data)]
    if matches: hits.append({'path': name, 'patterns': matches})
    files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
save(ROOT / 'credential-scan.json', {'utc': now(), 'hits': hits, 'patterns': list(patterns), 'credential_values_printed': False})
save(ROOT / 'evidence-whitelist.json', {'files': files, 'state_included': False, 'credential_scan_passed': not hits})
assert not hits, 'Credential-like matches block archive; originals preserved'
with zipfile.ZipFile(ROOT / 'evidence-bundle.zip', 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for entry in files: z.write(ROOT / entry['path'], entry['path'])
    for n in ('credential-scan.json', 'evidence-whitelist.json'): z.write(ROOT / n, n)
save(ROOT / 'archive-identity.json', {'sha256': sha(ROOT / 'evidence-bundle.zip'), 'bytes': (ROOT / 'evidence-bundle.zip').stat().st_size, 'file_count': len(files)})
print(json.dumps({'engineering_passed': not issues, 'issues': issues, 'archived_files': len(files), 'model_requests': report['all_stdin_submissions']}))
raise SystemExit(0 if not issues else 1)
