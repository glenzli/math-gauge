# 稠密观测与完成域上的整族恢复

在 ZFC 中，设 $X,Y$ 为度量空间，$Y$ 完备，$D\subset X$ 稠密。设 $I$ 为集合，$\mathcal F$ 是 $I$ 上的真滤子，$K\in\mathbb R_{\geq0}$，且给定映射族 $f_i:X\to Y$ 满足
\[
d_Y(f_i(x),f_i(x'))\leq Kd_X(x,x')
\qquad(i\in I,\ x,x'\in X).
\]
对每个 $d\in D$，假设推前滤子 $(i\mapsto f_i(d))_*\mathcal F$ 在 $Y$ 中是 Cauchy 滤子。记 $\iota:X\to\widehat X$ 为度量完备化映射。

研究这些观测能否唯一确定一个 $K$-Lipschitz 映射 $F:\widehat X\to Y$，满足
\[
f_i(d)\longrightarrow F(\iota d)\quad\text{沿 }\mathcal F
\qquad(d\in D).
\]
同时构造每个 $f_i$ 到 $\widehat X$ 的唯一 $K$-Lipschitz 延拓 $\widehat f_i$，并证明它们对每个紧集 $C\subset\widehat X$ 沿 $\mathcal F$ 一致趋于 $F|_C$。

还要确定同步改变输入时的结论：对于任意 $u:I\to\widehat X$ 和 $a\in\widehat X$，若 $u\to a$ 沿 $\mathcal F$，是否有
\[
\widehat f_i(u(i))\longrightarrow F(a)\quad\text{沿 }\mathcal F?
\]
