"""Operator preparation only; no model request is submitted."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, shutil, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/g4i/lab/math-gauge')
SUITE = REPO / 'drafts/true-goal-six-20261029'
HELPER = REPO / 'scripts/isolated_cli/prepare.py'
spec = importlib.util.spec_from_file_location('mg_prepare', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
def save(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

old = json.loads(Path('/private/tmp/math-gauge-six-prior-engineering/MG-R001.json').read_text())
history = Path(next(x['path'] for x in old['probes'] if x['category'] == 'history'))
assert history.is_file()
roots = [Path(x) for x in old['deny_read_roots']]
assert all(x.is_dir() for x in roots)
(ROOT / 'runs').mkdir()
(ROOT / 'configs').mkdir()
exception = {
    'utc': now(),
    'shared_prepare': str(HELPER), 'shared_prepare_sha256': sha(HELPER),
    'historical_mechanism': 'results/full-lean-terra/runtime/live-policy-extension.json',
    'reason': 'Current CLI binary equals prior tested binary. Reapply narrow startup requirements, then verify real opens, network connects and actual process policies afresh.',
    'changes': {
        'sqlite_home': 'fresh per-case state/sqlite', 'log_dir': 'fresh per-case state/log',
        'network': 'existing model-service proxy localhost:7897 only; other loopback ports denied',
        'installation_id': 'allow exact existing non-history installation identifier writeback; verify content hash before and after',
    },
    'credential_content_read_or_copied': False,
    'model_requests_at_preparation': 0,
}
save(ROOT / 'policy-exceptions.json', exception)
for n in range(101, 107):
    cid = f'MG-R{n}'
    run = ROOT / 'runs' / cid
    probes = [
        {'category': 'reference', 'path': str(SUITE / cid / 'reference.md')},
        {'category': 'history', 'path': str(history)},
        {'category': 'prior_run', 'path': str(REPO / 'results/full-lean-terra/answers/MG-R001.md')},
        {'category': 'memory', 'path': '/Users/g4i/.codex/memories/MEMORY.md'},
        {'category': 'global_config', 'path': '/Users/g4i/.codex/config.toml'},
        {'category': 'global_rules', 'path': '/Users/g4i/.codex/AGENTS.md'},
        {'category': 'global_state', 'path': '/Users/g4i/.codex/state_5.sqlite'},
        {'category': 'temporary_reference', 'path': '/private/tmp/math-gauge-six-blind-qualification-20261029/MG-R101.md'},
        {'category': 'author_lean', 'path': str(next(p for p in (SUITE / cid / 'formal').glob('*.lean') if p.name != 'CurrentAudit.lean'))},
        {'category': 'other_workspace', 'path': '/Users/g4i/lab/oet-dev/the-operator-evolution-theory/formal-oet/lake-manifest.json'},
        {'category': 'data_volume_alias', 'path': '/System/Volumes/Data' + str(SUITE / cid / 'reference.md')},
    ]
    cfg = {
        'schema': 'math-gauge.isolated-cli/v1', 'client': 'codex',
        'cli_identity': str(ROOT / 'cli-inspection/identity.json'),
        'prompt': str(SUITE / cid / 'task.md'), 'run_dir': str(run),
        'model': 'gpt-6.1-terra', 'effort': 'max',
        'deny_read_roots': list(map(str, roots)),
        'read_exceptions': old['read_exceptions'], 'credential_links': [], 'probes': probes,
    }
    save(ROOT / 'configs' / (cid + '.json'), cfg)
    plan = helper.prepare(cfg)
    original_names = json.loads((run / 'runtime/prepared-hashes.json').read_text())
    original = run / 'runtime/base-preparation'
    original.mkdir()
    for name in ('prepared-hashes.json', 'outer.sb', 'codex-settings.json', 'plan.json', 'execution.template.json'):
        shutil.copyfile(run / 'runtime' / name, original / name)
    policy = run / 'runtime/outer.sb'
    policy.write_text(policy.read_text() + '\n(allow file-write* (literal "/Users/g4i/.codex/installation_id"))\n(allow network-outbound (remote tcp "localhost:7897"))\n')
    settings = json.loads((run / 'runtime/codex-settings.json').read_text())
    settings.update(sqlite_home=str(run / 'state/sqlite'), log_dir=str(run / 'state/log'))
    save(run / 'runtime/codex-settings.json', settings)
    additions = []
    for key in ('sqlite_home', 'log_dir'):
        additions += ['--config', key + '=' + helper.toml(settings[key])]
    assert plan['argv'][-1] == '-'
    plan['argv'][-1:-1] = additions
    plan['runtime_extension'] = 'runtime/policy-exceptions.json'
    save(run / 'runtime/plan.json', plan)
    template = json.loads((run / 'runtime/execution.template.json').read_text())
    template['argv'] = plan['argv']
    save(run / 'runtime/execution.template.json', template)
    save(run / 'runtime/policy-exceptions.json', exception)
    shutil.copyfile(ROOT / 'network-probe.py', run / 'runtime/network-probe.py')
    save(run / 'runtime/prepared-hashes.json', {name: sha(run / name) for name in original_names})
    print(cid, 'prepared', plan['prompt_sha256'])
