from pathlib import Path
import datetime,errno,json,socket,sys
checks=[]
for host,port,expected in [('127.0.0.1',7897,'allowed'),('127.0.0.1',22,'denied'),('127.0.0.1',7898,'denied'),('127.0.0.1',4000,'denied'),('::1',7898,'denied')]:
 s=socket.socket(socket.AF_INET6 if ':' in host else socket.AF_INET,socket.SOCK_STREAM);s.settimeout(3)
 try:
  s.connect((host,port));outcome='CONNECTED';code=0
 except OSError as e:code=e.errno;outcome='DENIED' if code in (errno.EPERM,errno.EACCES) else 'OTHER_ERROR'
 finally:s.close()
 checks.append({'host':host,'port':port,'expected':expected,'outcome':outcome,'errno':code,'passed':outcome==('CONNECTED' if expected=='allowed' else 'DENIED')})
report={'kind':'actual-network-connect','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'data_sent':False,'checks':checks,'passed':all(c['passed'] for c in checks)}
with Path(sys.argv[1]).open('x') as f:json.dump(report,f,indent=2);f.write('\n')
raise SystemExit(0 if report['passed'] else 1)
