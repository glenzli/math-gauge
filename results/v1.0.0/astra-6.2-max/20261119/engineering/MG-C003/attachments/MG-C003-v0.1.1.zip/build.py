"""Compile Main and its source imports using the supplied offline Lean environment."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CONFIG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "environment.json"
BACKGROUND = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else CONFIG.parent
OUTPUT = ROOT / ".build" / "lean"
LEAN_REV = "f72c35b3f637c8c6571d353742168ab66cc22c00"
MATHLIB_REV = "5e932f97dd25535344f80f9dd8da3aab83df0fe6"

def main():
    config = json.loads(CONFIG.read_text())
    lean = config["compiler"]
    version = subprocess.check_output([lean, "--version"], text=True)
    if "version 4.29.1," not in version or LEAN_REV not in version:
        raise ValueError(version)
    packages = config["public_packages"]
    mathlib = next(package for package in packages if package["name"] == "mathlib")
    if mathlib["revision"] != MATHLIB_REV:
        raise ValueError(mathlib["revision"])
    paths = [str(OUTPUT), *(package["olean_root"] for package in packages)]
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(paths))
    done = set()

    def build(module):
        if module in done:
            return
        relative = Path(*module.split(".")).with_suffix(".lean")
        root = BACKGROUND if module.startswith("formal_oet.") else ROOT
        source = (root / relative).read_text()
        for dep in re.findall(r"^import ([\w.]+)$", source, re.MULTILINE):
            if dep.startswith(("Ch3.", "formal_oet.")):
                build(dep)
        output = (OUTPUT / relative).with_suffix(".olean")
        output.parent.mkdir(parents=True, exist_ok=True)
        print(module, flush=True)
        subprocess.run([lean, "-o", str(output), str(relative)], cwd=root, env=env, check=True)
        done.add(module)

    build("Main")

if __name__ == "__main__":
    main()
