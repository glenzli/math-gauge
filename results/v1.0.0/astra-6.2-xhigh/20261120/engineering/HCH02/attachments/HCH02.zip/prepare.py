"""Connect the project to the pinned local Lake package cache."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
entries = json.loads((root / "lake-manifest.json").read_text())["packages"]
if len(sys.argv) > 1:
    cache = Path(sys.argv[1]).resolve()
    paths = {e["name"]: cache / e["name"] for e in entries}
else:
    packages = json.loads((root / "environment.json").read_text())["public_packages"]
    paths = {p["name"]: Path(p["path"]).resolve() for p in packages}

def revision(path):
    head = path / ".git" / "HEAD"
    if head.is_file():
        value = head.read_text().strip()
        if not value.startswith("ref:"):
            return value
    return subprocess.check_output(
        ["git", "-C", str(path), "rev-parse", "HEAD"], text=True
    ).strip()

pin = "5e932f97dd25535344f80f9dd8da3aab83df0fe6"
if revision(paths["mathlib"]) != pin:
    raise SystemExit("mathlib revision differs from " + pin)
lock = json.loads((paths["mathlib"] / "lake-manifest.json").read_text())
pins = {p["name"]: p["rev"] for p in lock["packages"]}
pins["mathlib"] = pin
for entry in entries:
    name = entry["name"]
    src = paths[name].resolve()
    if revision(src) != pins[name]:
        raise SystemExit("revision mismatch for " + name)
    dst = root / entry["dir"]
    if dst.resolve() != src:
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.symlink_to(src, target_is_directory=True)
