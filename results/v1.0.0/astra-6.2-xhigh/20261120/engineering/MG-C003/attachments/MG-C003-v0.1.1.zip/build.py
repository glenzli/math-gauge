"""Build against the public package caches listed in the supplied environment.json."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LEAN_COMMIT = "f72c35b3f637c8c6571d353742168ab66cc22c00"
MATHLIB_COMMIT = "5e932f97dd25535344f80f9dd8da3aab83df0fe6"


def main():
    config = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "environment.json"
    env = json.loads(config.read_text())
    compiler = env["compiler"]
    version = subprocess.check_output([compiler, "--version"], text=True)
    if LEAN_COMMIT not in version or "4.29.1" not in version:
        raise ValueError(version)
    packages = env["public_packages"]
    mathlib = next(pkg for pkg in packages if pkg["name"] == "mathlib")
    if mathlib["revision"] != MATHLIB_COMMIT:
        raise ValueError(mathlib["revision"])

    output = ROOT / ".lake/build/lib/lean"
    search = [str(output), *(pkg["olean_root"] for pkg in packages)]
    child_env = dict(os.environ, LEAN_PATH=os.pathsep.join(search))
    built = set()

    def build(module):
        if module in built:
            return
        rel = Path(*module.split("."))
        source = ROOT / rel.with_suffix(".lean")
        for line in source.read_text().splitlines():
            if line.startswith("import "):
                dep = line.split()[1]
                if not dep.startswith("Mathlib"):
                    build(dep)
        target = output / rel.with_suffix(".olean")
        target.parent.mkdir(parents=True, exist_ok=True)
        print(module, flush=True)
        subprocess.run([compiler, "-o", target, source], cwd=ROOT, env=child_env, check=True)
        built.add(module)

    build("Main")


if __name__ == "__main__":
    main()
